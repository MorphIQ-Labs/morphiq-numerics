#!/bin/bash
set -euo pipefail
mkdir -p pr240/source pr240/results
tar -xzf source.tar.gz -C pr240/source
cp revision.txt pr240/results/
cd pr240/source
out="$PWD/../results"
if [ ! -x "$HOME/.cargo/bin/rustup" ]; then
  curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs -o ../rustup-init.sh
  sh ../rustup-init.sh -y --profile minimal --default-toolchain none > "$out/rustup.log" 2>&1
fi
export PATH="$HOME/.cargo/bin:$PATH"
rustup toolchain install 1.97.1 --profile minimal >> "$out/rustup.log" 2>&1
env RUSTFLAGS= CARGO_ENCODED_RUSTFLAGS= RUSTC_WRAPPER= RUSTC_WORKSPACE_WRAPPER= \
  cargo +1.97.1 build --locked --release -p morphiq-numerics-reference \
    --features simd,std --bin bench-fast-primitives > "$out/build.log" 2>&1
cp target/release/bench-fast-primitives "$out/benchmark"
rustc +1.97.1 -vV > "$out/rustc.txt"
lscpu > "$out/cpu.txt"
uname -a > "$out/kernel.txt"
cat /etc/os-release > "$out/os.txt"
cat /proc/cpuinfo > "$out/cpuinfo.txt"
dpkg-query -W > "$out/packages.txt"
sha256sum "$out/benchmark" > "$out/binary.sha256"
sha256sum "$HOME/source.tar.gz" > "$out/source.sha256"
sudo systemctl stop apt-daily.timer apt-daily-upgrade.timer
sudo systemctl mask --runtime apt-daily.service apt-daily-upgrade.service
python3 - "$out" <<'PY'
import csv, json, pathlib, statistics, subprocess, sys, time
out = pathlib.Path(sys.argv[1])
rows = []
for run in range(11):
    if run == 6:
        time.sleep(30)
    before = pathlib.Path('/proc/stat').read_text()
    started = time.time()
    p = subprocess.run(['taskset','-c','0',str(out/'benchmark')], capture_output=True, text=True, check=True)
    name = 'warmup' if run == 0 else f'run-{run}'
    (out/f'{name}.csv').write_text(p.stdout)
    (out/f'{name}.stderr').write_text(p.stderr)
    (out/f'{name}-conditions.json').write_text(json.dumps(dict(start=started,end=time.time(),proc_stat_before=before,proc_stat_after=pathlib.Path('/proc/stat').read_text(),load=pathlib.Path('/proc/loadavg').read_text())))
    if run:
        cells = {}
        for primitive,mode,ns in csv.reader(p.stdout.splitlines()):
            cells.setdefault((primitive,int(mode)),[]).append(float(ns))
        assert len(cells) == 12 and all(len(v)==4 for v in cells.values())
        for (primitive,mode),samples in cells.items():
            rows.append(dict(run=run,primitive=primitive,mode=mode,median_ns=statistics.median(samples),min_ns=min(samples),max_ns=max(samples)))
    print(name+' complete',flush=True)
(out/'process-medians.json').write_text(json.dumps(rows,indent=2))
summary = []
for primitive in ['exp','erfcx','cdf']:
    for mode in range(4):
        selected = [r for r in rows if r['primitive']==primitive and r['mode']==mode]
        medians = [r['median_ns'] for r in selected]
        first = statistics.median(medians[:5]); second = statistics.median(medians[5:])
        drift = abs(second/first-1)
        spread = (max(medians)-min(medians))/statistics.median(medians)
        summary.append(dict(primitive=primitive,mode=mode,median_ns_per_52_value_call=statistics.median(medians),process_range_fraction=spread,block_drift_fraction=drift,stability_pass=drift<=.03 and spread<=.03))
(out/'stability-summary.json').write_text(json.dumps(summary,indent=2))
print(json.dumps(summary,indent=2),flush=True)
PY
# Independent observations and profiling are outside the timing phase.
tar -xzf docs/fast-evidence/qdfp-20261027/observations.tar.gz -C "$out"
taskset -c 0 "$out/benchmark" "$out/observations/fast-reference-inputs.txt" > "$out/observed.csv"
python3 -I "$out/observations/analyze.py" "$out/observations/fast-reference-expected.json" \
  "$out/observed.csv" "$out/error-summary.json" > "$out/error-analysis.log"
python3 - "$out/error-summary.json" <<'PY'
import json, sys
summary=json.load(open(sys.argv[1]))
assert all(not v['failures'] for v in summary.values()), summary
PY
sudo perf stat -e cycles,instructions,task-clock,context-switches,cpu-migrations \
  taskset -c 0 "$out/benchmark" > "$out/profile-observations.csv" 2> "$out/perf-stat.txt" || true
# Export evidence only, never build products or the benchmark executable.
tar -czf "$HOME/results.tar.gz" -C "$out" --exclude=benchmark --exclude=observations .
