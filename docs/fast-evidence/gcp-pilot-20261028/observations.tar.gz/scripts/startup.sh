#!/bin/bash
set -euo pipefail
export DEBIAN_FRONTEND=noninteractive
apt-get update
apt-get install -y --no-install-recommends build-essential pkg-config curl ca-certificates python3 git linux-perf
touch /var/lib/morphiq-bench-ready
