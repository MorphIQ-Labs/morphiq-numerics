"""Capture and verify immutable inputs before launching a source-bound campaign."""
import datetime,hashlib,json,pathlib,subprocess,sys
P=pathlib.Path(__file__).resolve().parent
SOURCE=pathlib.Path('/Users/stephen/Development/MorphIQ-Labs/worktrees/morphiq-numerics-arm-194')
EXPECTED='460315a087351e4b26b4844ddd873e1555d86558'
def git(*args):return subprocess.check_output(['git','-C',str(SOURCE),*args],text=True).strip()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert git('rev-parse','HEAD')==EXPECTED,'Source revision changed: prepare a new source-bound run'
assert not git('status','--porcelain'),'Source worktree is not clean'
assert not (P/'qualified').exists() and not (P/'host').exists(),'Existing campaign outputs: preserve them'
prod=P/'bin/libproduction_bench_wrapper.dylib'
linked=P/'build/release/deps/libproduction_bench_wrapper.dylib'
assert sha(prod)==sha(linked),'Actual native composition dependency differs from the frozen wrapper'
previous=P.parent/'integrated-c9-qualification'
for f in ['cells.json','timed-input-bits.csv','groups.json','native.c','qualify-cell.py','run-qualified.py','summarize.py']:
 assert sha(P/f)==sha(previous/f),f+' protocol changed'
banks=json.loads((P/'banks.json').read_text());old=json.loads((previous/'banks.json').read_text())
assert all(banks[k]==v for k,v in old.items() if k!='exp-boundary')
assert len(banks['exp-boundary'])==12353
assert not (P/'qualified').exists()
for c in json.loads((P/'bank-accuracy-summary.json').read_text()):
 assert not c['failures'] and not c['scalar_slice_mismatches']
for c in json.loads((P/'arm-accuracy-summary.json').read_text())['cells']:
 assert not c['accuracy_failures'] and not c['scalar_slice_mismatches']
d=json.loads((P/'diagnostics.json').read_text())
assert all(r['allocations']==0 and r['output_matches_uninstrumented'] for r in d['allocations'])
assert all(r['equal'] for r in d['fallback_identity'])
assert all(r['bound_pass'] and r['bit_identical_to_public_fused'] for r in d['composition'])
assert all(not r['production_failures'] for r in d['latency_oracle'])
files=[f for f in P.iterdir() if f.is_file() and f.name!='source.json']+list((P/'bin').glob('*.dylib'))
m=dict(commit=EXPECTED,status='',manifest_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),rust_flags='cleared; simd,std; release; thin LTO; codegen-units=1',hashes={str(f.relative_to(P)):sha(f) for f in sorted(files) if not f.is_symlink()},native_composition_dependency=dict(path=str(linked),sha256=sha(linked)),allocation_binary_sha256=sha(P/'allocation-build/release/liballocation_observation_wrapper.dylib'),same_source_x86_comparison='pending matching-source observations',qualification_state='frozen combined cubic candidate 460315a; full163-cell ARM qualification; later source changes not included')
(P/'source.json').write_text(json.dumps(m,indent=2)+'\n')
print('Source, actual linked production library, exact banks and numerical prerequisites verified:',EXPECTED)
