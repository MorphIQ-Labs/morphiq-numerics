import csv,datetime,json,math,os,sys
import matrix as M
P=M.P;cell=M.CELLS[int(sys.argv[1])];phase=sys.argv[2];base=P/'qualified'/cell['id'];out=base/phase;out.mkdir(parents=True)
meta=dict(cell=cell,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),pid=os.getpid(),load_before=os.getloadavg(),qos='QOS_CLASS_USER_INITIATED',qos_result=M.E.QOS_RESULT,affinity='macOS unbound')
if phase=='calibration':
 counts={};rows=[]
 floors=json.loads((P/'calibration-floors.json').read_text())[cell['id']]
 for name in cell['pair']:
  floor=floors[name];pilot_count=max(1,math.ceil(floor/6))
  warm=M.measure(cell,name,max(1,pilot_count//2))
  pilots=[M.measure(cell,name,pilot_count) for _ in range(3)]
  count=max(floor,math.ceil(pilot_count*600000000/min(pilots)))
  # Calibration may only increase the frozen iteration count; contention cannot shrink it.
  confirm=M.measure(cell,name,count)
  counts[name]=max(count,math.ceil(count*600000000/confirm))
  rows.append(dict(name=name,historical_floor=floor,pilot_count=pilot_count,warmup_ns=warm,pilot_ns=pilots,confirmation_count=count,confirmation_ns=confirm,frozen_count=counts[name]))
 (base/'counts.json').write_text(json.dumps(counts,indent=2)+'\n');(out/'samples.json').write_text(json.dumps(rows,indent=2)+'\n')
else:
 process=int(phase);counts=json.loads((base/'counts.json').read_text())
 with (out/'samples.csv').open('w',buffering=1) as f:
  w=csv.DictWriter(f,fieldnames=['cell','process','round','name','kind','iterations','elapsed_ns','ns_per_call']);w.writeheader()
  for rep in range(2):
   pair=cell['pair'] if (process+rep)%2==0 else cell['pair'][::-1]
   for name in pair:
    for kind,count in [('warmup',max(1,counts[name]//2)),('timed',counts[name])]:
     elapsed=M.measure(cell,name,count);w.writerow(dict(cell=cell['id'],process=process,round=rep,name=name,kind=kind,iterations=count,elapsed_ns=elapsed,ns_per_call=elapsed/count))
meta['load_after']=os.getloadavg();meta['end_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();(out/'metadata.json').write_text(json.dumps(meta,indent=2)+'\n')
