import csv,json,math,subprocess,sys,pathlib,datetime,os
import matrix as M
P=M.P
if len(sys.argv)==1:
 for i in range(3):subprocess.run([sys.executable,__file__,str(i)],check=True)
else:
 process=int(sys.argv[1]);rows=[]
 for key in (['014','015','016'] if process%2==0 else ['016','015','014']):
  c=M.CELLS[int(key)]
  for rep in range(2):
   for name in (c['pair'] if (process+rep)%2==0 else c['pair'][::-1]):
    count=100000;elapsed=M.measure(c,name,count);count=max(1,math.ceil(count*350000000/elapsed));warm=M.measure(c,name,count//2);elapsed=M.measure(c,name,count)
    rows.append(dict(cell=key,process=process,round=rep,name=name,count=count,elapsed_ns=elapsed,ns_per_call=elapsed/count,warmup_ns=warm))
 (P/('short-diagnostic-'+str(process)+'.json')).write_text(json.dumps(dict(scope='Retained diagnostic follow-up to isolated short-screen loss; not an acceptance retry or replacement',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),load=os.getloadavg(),rows=rows),indent=2)+'\n')
