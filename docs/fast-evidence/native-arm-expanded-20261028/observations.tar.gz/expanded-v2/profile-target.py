import sys,time
import matrix as M
cell=M.CELLS[int(sys.argv[1])];start=time.monotonic()
while time.monotonic()-start<9:M.measure(cell,cell['pair'][0],1000000)
