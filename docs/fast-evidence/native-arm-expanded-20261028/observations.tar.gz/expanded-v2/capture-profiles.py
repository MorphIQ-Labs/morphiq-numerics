import pathlib,subprocess,sys,json
P=pathlib.Path(__file__).resolve().parent
records=[]
for cell in ['033','157']:
 with (P/'logs'/('profile-target-'+cell+'.log')).open('w') as log:
  child=subprocess.Popen([sys.executable,str(P/'profile-target.py'),cell],stdout=log,stderr=subprocess.STDOUT)
  sample=subprocess.run(['sample',str(child.pid),'5','1','-file',str(P/('profile-'+cell+'.txt'))],text=True,capture_output=True)
  status=child.wait(timeout=60)
  records.append(dict(cell=cell,pid=child.pid,sample_status=sample.returncode,stdout=sample.stdout,stderr=sample.stderr,child_status=status))
(P/'profile-status.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(records,indent=2))
