import csv,json,math,time,sys,ctypes as C
from pathlib import Path
import matrix as M
P=M.P
if len(sys.argv)>2:
 lib=C.CDLL(str(Path(sys.argv[2]).resolve()))
 for name,e in M.E.entries.items():
  if name.startswith('prod_'):e['ptr']=C.cast(getattr(lib,name),C.c_void_p).value
with (P/(sys.argv[1] if len(sys.argv)>1 else 'screen.csv')).open('x',buffering=1) as f:
 w=csv.DictWriter(f,fieldnames=['cell','name','round','iterations','elapsed_ns','ns_per_call']);w.writeheader()
 for cell in M.CELLS:
  for name in cell['pair']:
   initial_count=max(1,math.ceil(10000/max(1,cell["length"])));initial=M.measure(cell,name,initial_count);count=max(1,math.ceil(10000000/(initial/initial_count)))
   for rep in range(2):
    elapsed=M.measure(cell,name,count);w.writerow(dict(cell=cell['id'],name=name,round=rep,iterations=count,elapsed_ns=elapsed,ns_per_call=elapsed/count))
print('Exploratory screen retained; not qualification')
