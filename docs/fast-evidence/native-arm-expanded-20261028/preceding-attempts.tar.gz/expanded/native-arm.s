	.build_version macos, 27, 0	sdk_version 27, 0
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_bench_set_qos                  ; -- Begin function bench_set_qos
	.p2align	2
_bench_set_qos:                         ; @bench_set_qos
	.cfi_startproc
; %bb.0:
	mov	w0, #25                         ; =0x19
	mov	w1, #0                          ; =0x0
	b	_pthread_set_qos_class_self_np
	.cfi_endproc
                                        ; -- End function
	.globl	_measure1                       ; -- Begin function measure1
	.p2align	2
_measure1:                              ; @measure1
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #112
	stp	x28, x27, [sp, #16]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #32]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #48]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #64]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	add	x29, sp, #96
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x19, x4
	mov	x22, x3
	mov	x20, x2
	mov	x21, x1
	mov	x23, x0
	cbz	x3, LBB1_5
; %bb.1:
	mov	x24, #0                         ; =0x0
LBB1_2:                                 ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB1_3 Depth 2
	mov	x25, #0                         ; =0x0
LBB1_3:                                 ;   Parent Loop BB1_2 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	d0, [x21, x25, lsl #3]
	blr	x23
	str	d0, [x20, x25, lsl #3]
	add	x25, x25, #1
	cmp	x22, x25
	b.ne	LBB1_3
; %bb.4:                                ;   in Loop: Header=BB1_2 Depth=1
	; InlineAsm Start
	; InlineAsm End
	add	x24, x24, #1
	cmp	x24, #100
	b.ne	LBB1_2
	b	LBB1_7
LBB1_5:
	mov	w8, #100                        ; =0x64
LBB1_6:                                 ; =>This Inner Loop Header: Depth=1
	; InlineAsm Start
	; InlineAsm End
	subs	x8, x8, #1
	b.ne	LBB1_6
LBB1_7:
	mov	x1, sp
	mov	w0, #6                          ; =0x6
	bl	_clock_gettime
	ldp	x25, x24, [sp]
	cbz	x19, LBB1_14
; %bb.8:
	cbz	x22, LBB1_13
; %bb.9:
	mov	x26, #0                         ; =0x0
LBB1_10:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB1_11 Depth 2
	mov	x27, #0                         ; =0x0
	; InlineAsm Start
	; InlineAsm End
LBB1_11:                                ;   Parent Loop BB1_10 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	d0, [x21, x27, lsl #3]
	blr	x23
	str	d0, [x20, x27, lsl #3]
	add	x27, x27, #1
	cmp	x22, x27
	b.ne	LBB1_11
; %bb.12:                               ;   in Loop: Header=BB1_10 Depth=1
	; InlineAsm Start
	; InlineAsm End
	add	x26, x26, #1
	cmp	x26, x19
	b.ne	LBB1_10
	b	LBB1_14
LBB1_13:                                ; =>This Inner Loop Header: Depth=1
	; InlineAsm Start
	; InlineAsm End
	; InlineAsm Start
	; InlineAsm End
	subs	x19, x19, #1
	b.ne	LBB1_13
LBB1_14:
	mov	x1, sp
	mov	w0, #6                          ; =0x6
	bl	_clock_gettime
	ldp	x8, x9, [sp]
	sub	x8, x8, x25
	mov	w10, #51712                     ; =0xca00
	movk	w10, #15258, lsl #16
	sub	x9, x9, x24
	madd	x0, x8, x10, x9
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #32]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #112
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_measure2                       ; -- Begin function measure2
	.p2align	2
_measure2:                              ; @measure2
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #112
	stp	x28, x27, [sp, #16]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #32]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #48]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #64]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	add	x29, sp, #96
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x19, x4
	mov	x22, x3
	mov	x20, x2
	mov	x21, x1
	mov	x23, x0
	cbz	x3, LBB2_5
; %bb.1:
	mov	x24, #0                         ; =0x0
LBB2_2:                                 ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB2_3 Depth 2
	mov	x25, #0                         ; =0x0
LBB2_3:                                 ;   Parent Loop BB2_2 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	d0, [x21, x25, lsl #3]
	mov	w0, #1                          ; =0x1
	blr	x23
	str	d0, [x20, x25, lsl #3]
	add	x25, x25, #1
	cmp	x22, x25
	b.ne	LBB2_3
; %bb.4:                                ;   in Loop: Header=BB2_2 Depth=1
	; InlineAsm Start
	; InlineAsm End
	add	x24, x24, #1
	cmp	x24, #100
	b.ne	LBB2_2
	b	LBB2_7
LBB2_5:
	mov	w8, #100                        ; =0x64
LBB2_6:                                 ; =>This Inner Loop Header: Depth=1
	; InlineAsm Start
	; InlineAsm End
	subs	x8, x8, #1
	b.ne	LBB2_6
LBB2_7:
	mov	x1, sp
	mov	w0, #6                          ; =0x6
	bl	_clock_gettime
	ldp	x25, x24, [sp]
	cbz	x19, LBB2_14
; %bb.8:
	cbz	x22, LBB2_13
; %bb.9:
	mov	x26, #0                         ; =0x0
LBB2_10:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB2_11 Depth 2
	mov	x27, #0                         ; =0x0
	; InlineAsm Start
	; InlineAsm End
LBB2_11:                                ;   Parent Loop BB2_10 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	d0, [x21, x27, lsl #3]
	mov	w0, #1                          ; =0x1
	blr	x23
	str	d0, [x20, x27, lsl #3]
	add	x27, x27, #1
	cmp	x22, x27
	b.ne	LBB2_11
; %bb.12:                               ;   in Loop: Header=BB2_10 Depth=1
	; InlineAsm Start
	; InlineAsm End
	add	x26, x26, #1
	cmp	x26, x19
	b.ne	LBB2_10
	b	LBB2_14
LBB2_13:                                ; =>This Inner Loop Header: Depth=1
	; InlineAsm Start
	; InlineAsm End
	; InlineAsm Start
	; InlineAsm End
	subs	x19, x19, #1
	b.ne	LBB2_13
LBB2_14:
	mov	x1, sp
	mov	w0, #6                          ; =0x6
	bl	_clock_gettime
	ldp	x8, x9, [sp]
	sub	x8, x8, x25
	mov	w10, #51712                     ; =0xca00
	movk	w10, #15258, lsl #16
	sub	x9, x9, x24
	madd	x0, x8, x10, x9
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #32]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #112
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_measure_packet                 ; -- Begin function measure_packet
	.p2align	2
_measure_packet:                        ; @measure_packet
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #96
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	mov	x19, x4
	mov	x20, x3
	mov	x21, x2
	mov	x22, x1
	mov	x23, x0
	mov	w24, #100                       ; =0x64
LBB3_1:                                 ; =>This Inner Loop Header: Depth=1
	mov	x0, x22
	mov	x1, x21
	mov	x2, x20
	blr	x23
	; InlineAsm Start
	; InlineAsm End
	subs	x24, x24, #1
	b.ne	LBB3_1
; %bb.2:
	mov	x1, sp
	mov	w0, #6                          ; =0x6
	bl	_clock_gettime
	ldp	x25, x24, [sp]
	cbz	x19, LBB3_4
LBB3_3:                                 ; =>This Inner Loop Header: Depth=1
	; InlineAsm Start
	; InlineAsm End
	mov	x0, x22
	mov	x1, x21
	mov	x2, x20
	blr	x23
	; InlineAsm Start
	; InlineAsm End
	subs	x19, x19, #1
	b.ne	LBB3_3
LBB3_4:
	mov	x1, sp
	mov	w0, #6                          ; =0x6
	bl	_clock_gettime
	ldp	x8, x9, [sp]
	sub	x8, x8, x25
	mov	w10, #51712                     ; =0xca00
	movk	w10, #15258, lsl #16
	sub	x9, x9, x24
	madd	x0, x8, x10, x9
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_sleef_cdf_scalar               ; -- Begin function sleef_cdf_scalar
	.p2align	2
_sleef_cdf_scalar:                      ; @sleef_cdf_scalar
	.cfi_startproc
; %bb.0:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x8, #15309                      ; =0x3bcd
	movk	x8, #26239, lsl #16
	movk	x8, #41118, lsl #32
	movk	x8, #49126, lsl #48
	fmov	d1, x8
	fmul	d0, d0, d1
	bl	_Sleef_erfcd1_u15purecfma
	fmov	d1, #0.50000000
	fmul	d0, d0, d1
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_sleef_exp_neon                 ; -- Begin function sleef_exp_neon
	.p2align	2
_sleef_exp_neon:                        ; @sleef_exp_neon
	.cfi_startproc
; %bb.0:
	stp	x24, x23, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x21, x2
	mov	x20, x1
	mov	x19, x0
	cmp	x2, #2
	b.hs	LBB5_2
; %bb.1:
	mov	x8, #0                          ; =0x0
	b	LBB5_4
LBB5_2:
	mov	x24, #0                         ; =0x0
	mov	x22, x20
	mov	x23, x19
LBB5_3:                                 ; =>This Inner Loop Header: Depth=1
	ldr	q0, [x23], #16
	bl	_Sleef_expd2_u10advsimd
	str	q0, [x22], #16
	add	x8, x24, #2
	add	x9, x24, #4
	mov	x24, x8
	cmp	x9, x21
	b.ls	LBB5_3
LBB5_4:
	subs	x21, x21, x8
	b.ls	LBB5_7
; %bb.5:
	lsl	x8, x8, #3
	add	x20, x20, x8
	add	x19, x19, x8
LBB5_6:                                 ; =>This Inner Loop Header: Depth=1
	ldr	d0, [x19], #8
	bl	_Sleef_expd1_u10purecfma
	str	d0, [x20], #8
	subs	x21, x21, #1
	b.ne	LBB5_6
LBB5_7:
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_sleef_cdf_neon                 ; -- Begin function sleef_cdf_neon
	.p2align	2
_sleef_cdf_neon:                        ; @sleef_cdf_neon
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #112
	stp	d9, d8, [sp, #32]               ; 16-byte Folded Spill
	stp	x24, x23, [sp, #48]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #64]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	add	x29, sp, #96
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset b8, -72
	.cfi_offset b9, -80
	mov	x21, x2
	mov	x20, x1
	mov	x19, x0
	cmp	x2, #2
	b.hs	LBB6_2
; %bb.1:
	mov	x8, #0                          ; =0x0
	b	LBB6_4
LBB6_2:
	mov	x22, #0                         ; =0x0
	mov	x8, #15309                      ; =0x3bcd
	movk	x8, #26239, lsl #16
	movk	x8, #41118, lsl #32
	movk	x8, #49126, lsl #48
	dup.2d	v1, x8
	fmov.2d	v0, #0.50000000
	stp	q0, q1, [sp]                    ; 32-byte Folded Spill
	mov	x23, x20
	mov	x24, x19
LBB6_3:                                 ; =>This Inner Loop Header: Depth=1
	ldr	q0, [x24], #16
	ldr	q1, [sp, #16]                   ; 16-byte Folded Reload
	fmul.2d	v0, v0, v1
	bl	_Sleef_erfcd2_u15advsimd
	ldr	q1, [sp]                        ; 16-byte Folded Reload
	fmul.2d	v0, v0, v1
	str	q0, [x23], #16
	add	x8, x22, #2
	add	x9, x22, #4
	mov	x22, x8
	cmp	x9, x21
	b.ls	LBB6_3
LBB6_4:
	subs	x21, x21, x8
	b.ls	LBB6_7
; %bb.5:
	lsl	x8, x8, #3
	add	x20, x20, x8
	add	x19, x19, x8
	mov	x8, #15309                      ; =0x3bcd
	movk	x8, #26239, lsl #16
	movk	x8, #41118, lsl #32
	movk	x8, #49126, lsl #48
	fmov	d8, x8
	fmov	d9, #0.50000000
LBB6_6:                                 ; =>This Inner Loop Header: Depth=1
	ldr	d0, [x19], #8
	fmul	d0, d0, d8
	bl	_Sleef_erfcd1_u15purecfma
	fmul	d0, d0, d9
	str	d0, [x20], #8
	subs	x21, x21, #1
	b.ne	LBB6_6
LBB6_7:
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #32]               ; 16-byte Folded Reload
	add	sp, sp, #112
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_measure_chain1                 ; -- Begin function measure_chain1
	.p2align	2
_measure_chain1:                        ; @measure_chain1
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #128
	stp	d9, d8, [sp, #16]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #32]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #48]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #64]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #80]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #96]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #112]            ; 16-byte Folded Spill
	add	x29, sp, #112
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	.cfi_offset b8, -104
	.cfi_offset b9, -112
	mov	x20, x4
	mov	x22, x3
	mov	x19, x2
	mov	x21, x1
	mov	x23, x0
	mov	x1, sp
	mov	w0, #6                          ; =0x6
	bl	_clock_gettime
	ldp	x25, x24, [sp]
	movi.2d	v0, #0000000000000000
	cbz	x20, LBB7_7
; %bb.1:
	cbz	x22, LBB7_6
; %bb.2:
	mov	x26, #0                         ; =0x0
	mov	x8, #4584664420663164928        ; =0x3fa0000000000000
	fmov	d8, x8
LBB7_3:                                 ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB7_4 Depth 2
	mov	x27, #0                         ; =0x0
LBB7_4:                                 ;   Parent Loop BB7_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	d1, [x21, x27, lsl #3]
	fmul	d0, d0, d8
	fadd	d0, d0, d1
	blr	x23
	add	x27, x27, #1
	cmp	x22, x27
	b.ne	LBB7_4
; %bb.5:                                ;   in Loop: Header=BB7_3 Depth=1
	; InlineAsm Start
	; InlineAsm End
	add	x26, x26, #1
	cmp	x26, x20
	b.ne	LBB7_3
	b	LBB7_7
LBB7_6:                                 ; =>This Inner Loop Header: Depth=1
	; InlineAsm Start
	; InlineAsm End
	subs	x20, x20, #1
	b.ne	LBB7_6
LBB7_7:
	str	d0, [x19]
	mov	x1, sp
	mov	w0, #6                          ; =0x6
	bl	_clock_gettime
	ldp	x8, x9, [sp]
	sub	x8, x8, x25
	mov	w10, #51712                     ; =0xca00
	movk	w10, #15258, lsl #16
	sub	x9, x9, x24
	madd	x0, x8, x10, x9
	ldp	x29, x30, [sp, #112]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #96]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #80]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #64]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #48]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #32]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #16]               ; 16-byte Folded Reload
	add	sp, sp, #128
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_measure_chain2                 ; -- Begin function measure_chain2
	.p2align	2
_measure_chain2:                        ; @measure_chain2
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #128
	stp	d9, d8, [sp, #16]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #32]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #48]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #64]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #80]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #96]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #112]            ; 16-byte Folded Spill
	add	x29, sp, #112
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	.cfi_offset b8, -104
	.cfi_offset b9, -112
	mov	x20, x4
	mov	x22, x3
	mov	x19, x2
	mov	x21, x1
	mov	x23, x0
	mov	x1, sp
	mov	w0, #6                          ; =0x6
	bl	_clock_gettime
	ldp	x25, x24, [sp]
	movi.2d	v0, #0000000000000000
	cbz	x20, LBB8_7
; %bb.1:
	cbz	x22, LBB8_6
; %bb.2:
	mov	x26, #0                         ; =0x0
	mov	x8, #4584664420663164928        ; =0x3fa0000000000000
	fmov	d8, x8
LBB8_3:                                 ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB8_4 Depth 2
	mov	x27, #0                         ; =0x0
LBB8_4:                                 ;   Parent Loop BB8_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	d1, [x21, x27, lsl #3]
	fmul	d0, d0, d8
	fadd	d0, d0, d1
	mov	w0, #1                          ; =0x1
	blr	x23
	add	x27, x27, #1
	cmp	x22, x27
	b.ne	LBB8_4
; %bb.5:                                ;   in Loop: Header=BB8_3 Depth=1
	; InlineAsm Start
	; InlineAsm End
	add	x26, x26, #1
	cmp	x26, x20
	b.ne	LBB8_3
	b	LBB8_7
LBB8_6:                                 ; =>This Inner Loop Header: Depth=1
	; InlineAsm Start
	; InlineAsm End
	subs	x20, x20, #1
	b.ne	LBB8_6
LBB8_7:
	str	d0, [x19]
	mov	x1, sp
	mov	w0, #6                          ; =0x6
	bl	_clock_gettime
	ldp	x8, x9, [sp]
	sub	x8, x8, x25
	mov	w10, #51712                     ; =0xca00
	movk	w10, #15258, lsl #16
	sub	x9, x9, x24
	madd	x0, x8, x10, x9
	ldp	x29, x30, [sp, #112]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #96]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #80]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #64]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #48]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #32]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #16]               ; 16-byte Folded Reload
	add	sp, sp, #128
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_measure_cache_packet           ; -- Begin function measure_cache_packet
	.p2align	2
_measure_cache_packet:                  ; @measure_cache_packet
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #128
	stp	d9, d8, [sp, #16]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #32]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #48]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #64]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #80]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #96]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #112]            ; 16-byte Folded Spill
	add	x29, sp, #112
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	.cfi_offset b8, -104
	.cfi_offset b9, -112
	mov	x25, x6
	mov	x19, x5
	mov	x20, x4
	mov	x21, x3
	mov	x22, x2
	mov	x23, x1
	mov	x24, x0
	mov	x1, sp
	mov	w0, #6                          ; =0x6
	bl	_clock_gettime
	ldp	x27, x26, [sp]
	cbz	x20, LBB9_6
; %bb.1:
	cbz	x25, LBB9_7
; %bb.2:
	mov	x28, #0                         ; =0x0
	movi.2d	v8, #0000000000000000
LBB9_3:                                 ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB9_4 Depth 2
	mov	x8, #0                          ; =0x0
LBB9_4:                                 ;   Parent Loop BB9_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	d0, [x19, x8, lsl #3]
	fadd	d8, d8, d0
	add	x8, x8, #8
	cmp	x8, x25
	b.lo	LBB9_4
; %bb.5:                                ;   in Loop: Header=BB9_3 Depth=1
	; InlineAsm Start
	; InlineAsm End
	; InlineAsm Start
	; InlineAsm End
	mov	x0, x23
	mov	x1, x22
	mov	x2, x21
	blr	x24
	; InlineAsm Start
	; InlineAsm End
	add	x28, x28, #1
	cmp	x28, x20
	b.ne	LBB9_3
	b	LBB9_9
LBB9_6:
	movi.2d	v8, #0000000000000000
	b	LBB9_9
LBB9_7:
	movi.2d	v8, #0000000000000000
LBB9_8:                                 ; =>This Inner Loop Header: Depth=1
	; InlineAsm Start
	; InlineAsm End
	; InlineAsm Start
	; InlineAsm End
	mov	x0, x23
	mov	x1, x22
	mov	x2, x21
	blr	x24
	; InlineAsm Start
	; InlineAsm End
	subs	x20, x20, #1
	b.ne	LBB9_8
LBB9_9:
	str	d8, [x19]
	mov	x1, sp
	mov	w0, #6                          ; =0x6
	bl	_clock_gettime
	ldp	x8, x9, [sp]
	sub	x8, x8, x27
	mov	w10, #51712                     ; =0xca00
	movk	w10, #15258, lsl #16
	sub	x9, x9, x26
	madd	x0, x8, x10, x9
	ldp	x29, x30, [sp, #112]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #96]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #80]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #64]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #48]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #32]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #16]               ; 16-byte Folded Reload
	add	sp, sp, #128
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_measure_cache1                 ; -- Begin function measure_cache1
	.p2align	2
_measure_cache1:                        ; @measure_cache1
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #144
	stp	d9, d8, [sp, #32]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #48]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #64]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #80]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #96]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #112]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #128]            ; 16-byte Folded Spill
	add	x29, sp, #128
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	.cfi_offset b8, -104
	.cfi_offset b9, -112
	mov	x23, x6
	mov	x19, x5
	mov	x20, x4
	mov	x24, x3
	mov	x21, x2
	mov	x22, x1
	mov	x25, x0
	add	x1, sp, #16
	mov	w0, #6                          ; =0x6
	bl	_clock_gettime
	ldp	x8, x27, [sp, #16]
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	cbz	x20, LBB10_9
; %bb.1:
	cbz	x24, LBB10_10
; %bb.2:
	cbz	x23, LBB10_15
; %bb.3:
	mov	x28, #0                         ; =0x0
	movi.2d	v8, #0000000000000000
LBB10_4:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB10_5 Depth 2
                                        ;     Child Loop BB10_7 Depth 2
	mov	x8, #0                          ; =0x0
LBB10_5:                                ;   Parent Loop BB10_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	d0, [x19, x8, lsl #3]
	fadd	d8, d8, d0
	add	x8, x8, #8
	cmp	x8, x23
	b.lo	LBB10_5
; %bb.6:                                ;   in Loop: Header=BB10_4 Depth=1
	mov	x26, #0                         ; =0x0
	; InlineAsm Start
	; InlineAsm End
	; InlineAsm Start
	; InlineAsm End
LBB10_7:                                ;   Parent Loop BB10_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	d0, [x22, x26, lsl #3]
	blr	x25
	str	d0, [x21, x26, lsl #3]
	add	x26, x26, #1
	cmp	x24, x26
	b.ne	LBB10_7
; %bb.8:                                ;   in Loop: Header=BB10_4 Depth=1
	; InlineAsm Start
	; InlineAsm End
	add	x28, x28, #1
	cmp	x28, x20
	b.ne	LBB10_4
	b	LBB10_21
LBB10_9:
	movi.2d	v8, #0000000000000000
	b	LBB10_21
LBB10_10:
	cbz	x23, LBB10_19
; %bb.11:
	mov	x8, #0                          ; =0x0
	movi.2d	v8, #0000000000000000
LBB10_12:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB10_13 Depth 2
	mov	x9, #0                          ; =0x0
LBB10_13:                               ;   Parent Loop BB10_12 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	d0, [x19, x9, lsl #3]
	fadd	d8, d8, d0
	add	x9, x9, #8
	cmp	x9, x23
	b.lo	LBB10_13
; %bb.14:                               ;   in Loop: Header=BB10_12 Depth=1
	; InlineAsm Start
	; InlineAsm End
	; InlineAsm Start
	; InlineAsm End
	; InlineAsm Start
	; InlineAsm End
	add	x8, x8, #1
	cmp	x8, x20
	b.ne	LBB10_12
	b	LBB10_21
LBB10_15:
	movi.2d	v8, #0000000000000000
LBB10_16:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB10_17 Depth 2
	mov	x28, #0                         ; =0x0
	; InlineAsm Start
	; InlineAsm End
	; InlineAsm Start
	; InlineAsm End
LBB10_17:                               ;   Parent Loop BB10_16 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	d0, [x22, x28, lsl #3]
	blr	x25
	str	d0, [x21, x28, lsl #3]
	add	x28, x28, #1
	cmp	x24, x28
	b.ne	LBB10_17
; %bb.18:                               ;   in Loop: Header=BB10_16 Depth=1
	; InlineAsm Start
	; InlineAsm End
	add	x23, x23, #1
	cmp	x23, x20
	b.ne	LBB10_16
	b	LBB10_21
LBB10_19:
	movi.2d	v8, #0000000000000000
LBB10_20:                               ; =>This Inner Loop Header: Depth=1
	; InlineAsm Start
	; InlineAsm End
	; InlineAsm Start
	; InlineAsm End
	; InlineAsm Start
	; InlineAsm End
	subs	x20, x20, #1
	b.ne	LBB10_20
LBB10_21:
	str	d8, [x19]
	add	x1, sp, #16
	mov	w0, #6                          ; =0x6
	bl	_clock_gettime
	ldp	x8, x9, [sp, #16]
	ldr	x10, [sp, #8]                   ; 8-byte Folded Reload
	sub	x8, x8, x10
	mov	w10, #51712                     ; =0xca00
	movk	w10, #15258, lsl #16
	sub	x9, x9, x27
	madd	x0, x8, x10, x9
	ldp	x29, x30, [sp, #128]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #112]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #96]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #80]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #64]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #48]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #32]               ; 16-byte Folded Reload
	add	sp, sp, #144
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_composed_cdf_passes            ; -- Begin function composed_cdf_passes
	.p2align	2
_composed_cdf_passes:                   ; @composed_cdf_passes
	.cfi_startproc
; %bb.0:
	stp	x24, x23, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	sub	sp, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x19, x2
	mov	x20, x1
	mov	x21, x0
Lloh0:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh1:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh2:
	ldr	x8, [x8]
	stur	x8, [x29, #-56]
	cmp	x2, #1
	csinc	x8, x2, xzr, hi
	lsl	x8, x8, #3
	mov	x9, x8
Lloh3:
	adrp	x16, ___chkstk_darwin@GOTPAGE
Lloh4:
	ldr	x16, [x16, ___chkstk_darwin@GOTPAGEOFF]
	blr	x16
	mov	x9, sp
	add	x10, x8, #15
	and	x12, x10, #0xfffffffffffffff0
	sub	x23, x9, x12
	mov	sp, x23
	mov	x9, x8
Lloh5:
	adrp	x16, ___chkstk_darwin@GOTPAGE
Lloh6:
	ldr	x16, [x16, ___chkstk_darwin@GOTPAGEOFF]
	blr	x16
	mov	x8, sp
	sub	x22, x8, x12
	mov	sp, x22
	cbz	x2, LBB11_3
; %bb.1:
	cmp	x19, #8
	b.hs	LBB11_4
; %bb.2:
	mov	x8, #0                          ; =0x0
	b	LBB11_7
LBB11_3:
	mov	x0, x22
	mov	x1, x20
	mov	x2, x19
	bl	_prod_exp_slice
	mov	x0, x23
	mov	x1, x22
	mov	x2, x19
	bl	_prod_erfcx_slice
	b	LBB11_15
LBB11_4:
	and	x8, x19, #0xfffffffffffffff8
	add	x9, x21, #32
	add	x10, x23, #32
	add	x11, x22, #32
	mov	x12, #15309                     ; =0x3bcd
	movk	x12, #26239, lsl #16
	movk	x12, #41118, lsl #32
	movk	x12, #16358, lsl #48
	dup.2d	v0, x12
	fmov.2d	v1, #-0.50000000
	mov	x12, x8
LBB11_5:                                ; =>This Inner Loop Header: Depth=1
	ldp	q2, q3, [x9, #-32]
	ldp	q4, q5, [x9], #64
	fabs.2d	v2, v2
	fabs.2d	v3, v3
	fabs.2d	v4, v4
	fabs.2d	v5, v5
	fmul.2d	v6, v2, v0
	fmul.2d	v7, v3, v0
	fmul.2d	v16, v4, v0
	fmul.2d	v17, v5, v0
	stp	q6, q7, [x10, #-32]
	stp	q16, q17, [x10], #64
	fmul.2d	v6, v2, v1
	fmul.2d	v7, v3, v1
	fmul.2d	v16, v4, v1
	fmul.2d	v17, v5, v1
	fmul.2d	v2, v2, v6
	fmul.2d	v3, v3, v7
	fmul.2d	v4, v4, v16
	fmul.2d	v5, v5, v17
	stp	q2, q3, [x11, #-32]
	stp	q4, q5, [x11], #64
	subs	x12, x12, #8
	b.ne	LBB11_5
; %bb.6:
	cmp	x19, x8
	b.eq	LBB11_9
LBB11_7:
	sub	x9, x19, x8
	lsl	x11, x8, #3
	add	x8, x22, x11
	add	x10, x23, x11
	add	x11, x21, x11
	mov	x12, #15309                     ; =0x3bcd
	movk	x12, #26239, lsl #16
	movk	x12, #41118, lsl #32
	movk	x12, #16358, lsl #48
	fmov	d0, x12
	fmov	d1, #-0.50000000
LBB11_8:                                ; =>This Inner Loop Header: Depth=1
	ldr	d2, [x11], #8
	fabs	d2, d2
	fmul	d3, d2, d0
	str	d3, [x10], #8
	fmul	d3, d2, d1
	fmul	d2, d2, d3
	str	d2, [x8], #8
	subs	x9, x9, #1
	b.ne	LBB11_8
LBB11_9:
	mov	x0, x22
	mov	x1, x20
	mov	x2, x19
	bl	_prod_exp_slice
	mov	x0, x23
	mov	x1, x22
	mov	x2, x19
	bl	_prod_erfcx_slice
	cmp	x19, #8
	b.lo	LBB11_12
; %bb.10:
	lsl	x8, x19, #3
	add	x9, x21, x8
	cmp	x20, x9
	b.hs	LBB11_17
; %bb.11:
	add	x8, x20, x8
	cmp	x21, x8
	b.hs	LBB11_17
LBB11_12:
	mov	x8, #0                          ; =0x0
LBB11_13:
	sub	x9, x19, x8
	lsl	x11, x8, #3
	add	x8, x21, x11
	add	x10, x22, x11
	add	x11, x20, x11
	fmov	d0, #0.50000000
	fmov	d1, #1.00000000
LBB11_14:                               ; =>This Inner Loop Header: Depth=1
	ldr	d2, [x11]
	fmul	d2, d2, d0
	ldr	d3, [x10], #8
	fmul	d2, d2, d3
	ldr	d3, [x8], #8
	fsub	d4, d1, d2
	fcmp	d3, #0.0
	fcsel	d2, d2, d4, mi
	str	d2, [x11], #8
	subs	x9, x9, #1
	b.ne	LBB11_14
LBB11_15:
	ldur	x8, [x29, #-56]
Lloh7:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh8:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh9:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB11_20
; %bb.16:
	sub	sp, x29, #48
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	ret
LBB11_17:
	and	x8, x19, #0xfffffffffffffff8
	add	x9, x20, #32
	add	x10, x22, #32
	add	x11, x21, #32
	fmov.2d	v0, #0.50000000
	fmov.2d	v1, #1.00000000
	mov	x12, x8
LBB11_18:                               ; =>This Inner Loop Header: Depth=1
	ldp	q2, q3, [x9, #-32]
	ldp	q4, q5, [x9]
	fmul.2d	v2, v2, v0
	fmul.2d	v3, v3, v0
	fmul.2d	v4, v4, v0
	fmul.2d	v5, v5, v0
	ldp	q6, q7, [x10, #-32]
	ldp	q16, q17, [x10], #64
	fmul.2d	v2, v2, v6
	fmul.2d	v3, v3, v7
	fmul.2d	v4, v4, v16
	fmul.2d	v5, v5, v17
	ldp	q6, q7, [x11, #-32]
	ldp	q16, q17, [x11], #64
	fcmlt.2d	v6, v6, #0.0
	fcmlt.2d	v7, v7, #0.0
	fcmlt.2d	v16, v16, #0.0
	fcmlt.2d	v17, v17, #0.0
	fsub.2d	v18, v1, v2
	fsub.2d	v19, v1, v3
	fsub.2d	v20, v1, v4
	fsub.2d	v21, v1, v5
	bif.16b	v2, v18, v6
	bif.16b	v3, v19, v7
	bif.16b	v4, v20, v16
	bif.16b	v5, v21, v17
	stp	q2, q3, [x9, #-32]
	stp	q4, q5, [x9], #64
	subs	x12, x12, #8
	b.ne	LBB11_18
; %bb.19:
	cmp	x19, x8
	b.eq	LBB11_15
	b	LBB11_13
LBB11_20:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh0, Lloh1, Lloh2
	.loh AdrpLdrGotLdr	Lloh7, Lloh8, Lloh9
	.loh AdrpLdrGot	Lloh3, Lloh4
	.loh AdrpLdrGot	Lloh5, Lloh6
	.cfi_endproc
                                        ; -- End function
.subsections_via_symbols
