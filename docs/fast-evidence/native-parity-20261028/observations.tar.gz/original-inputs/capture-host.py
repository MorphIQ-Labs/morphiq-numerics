import datetime, json, os, pathlib, subprocess

def read(path):
    try:
        return pathlib.Path(path).read_text().strip()
    except OSError as error:
        return str(error)

paths = ['/proc/loadavg', '/proc/stat', '/proc/sys/kernel/perf_event_paranoid',
         '/sys/devices/system/cpu/intel_pstate/no_turbo',
         '/sys/devices/system/cpu/intel_pstate/min_perf_pct',
         '/sys/devices/system/cpu/intel_pstate/max_perf_pct']
for pattern in ['cpu[0-9]*/cpufreq/scaling_governor', 'cpu[0-9]*/cpufreq/scaling_cur_freq',
                'cpu[0-9]*/cpufreq/energy_performance_preference',
                'cpu[0-9]*/topology/thread_siblings_list']:
    paths += [str(p) for p in pathlib.Path('/sys/devices/system/cpu').glob(pattern)]
for pattern in ['hwmon*/name', 'hwmon*/temp*_input', 'hwmon*/temp*_label', 'hwmon*/fan*_input']:
    paths += [str(p) for p in pathlib.Path('/sys/class/hwmon').glob(pattern)]
for pattern in ['*/type', '*/online', '*/status']:
    paths += [str(p) for p in pathlib.Path('/sys/class/power_supply').glob(pattern)]
print(json.dumps(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                     allowed_cpus=sorted(os.sched_getaffinity(0)),
                     selected_cpu=os.environ.get('MORPHIQ_BENCH_CPU'),
                     files={p:read(p) for p in paths},
                     processes=subprocess.check_output(['ps','-eo','pid,ppid,pcpu,comm'],text=True)),indent=2))
