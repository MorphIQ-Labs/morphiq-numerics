"""Replay independent rounded fixtures against standalone fast observations."""
import argparse
import json
import math
from pathlib import Path
import struct

p = argparse.ArgumentParser(description=__doc__)
p.add_argument('expected', type=Path)
p.add_argument('observed', type=Path)
p.add_argument('output', type=Path)
a = p.parse_args()
reference = json.loads(a.expected.read_text())
def value(word):
    return struct.unpack('>d', bytes.fromhex(word))[0]
summary = {name: dict(cases=0, accelerated=0, max_ulp=0,
                     max_absolute_error_upper=0., failures=[]) for name in ['exp', 'erfcx', 'cdf']}
seen = set()
for line in a.observed.read_text().splitlines():
    name, xword, yword = line.split(',')
    key = name + ' ' + xword
    seen.add(key)
    x, actual, expected = value(xword), value(yword), value(reference[key])
    cell = summary[name]
    cell['cases'] += 1
    active = (abs(x) < 704 if name == 'exp' else
              -.5 <= x < 16 and abs(x) >= 2**-33 if name == 'erfcx' else
              2**-33 <= abs(x) <= 8)
    if not active:
        continue
    cell['accelerated'] += 1
    uncertainty = max(math.nextafter(expected, math.inf)-expected,
                      expected-math.nextafter(expected, -math.inf)) * .5
    error = math.nextafter(abs(actual-expected)+uncertainty, math.inf)
    cap = (2**-49 if name == 'cdf' else
           math.nextafter(math.nextafter(abs(expected), 0.)*2**-51, 0.))
    cell['max_ulp'] = max(cell['max_ulp'], abs(int(yword, 16)-int(reference[key], 16)))
    cell['max_absolute_error_upper'] = max(cell['max_absolute_error_upper'], error)
    if not math.isfinite(actual) or error > cap:
        cell['failures'].append(dict(input=xword, output=yword, error=error, cap=cap))
assert seen == set(reference), 'incomplete observation population'
a.output.write_text(json.dumps(summary, indent=2)+'\n')
print(json.dumps(summary, indent=2))
