from pathlib import Path
import csv,hashlib,io,json,os,re,subprocess,tarfile
P=Path(__file__).resolve().parent;os.sched_setaffinity(0,{0});W=P/'source';root=P/'combined-65bec-smoke'
m=json.loads((P/'qualification-v8-manifest.json').read_text())
for c in m['cells']:
 if c['backend']=='auto' and c['population']=='ordinary' and c['primitive']=='cdf' and c['kind'] in ['scalar','latency'] and c['length']==52 and c['reference']=='scipy_ndtr':
  out=root/c['id'];out.mkdir(exist_ok=False)
  a=[str(P/'venv/bin/python'),str(P/'qualify-cell.py'),'--product',str(P/'qualification-combined-65bec-bin/auto.so'),'--primitive','cdf','--length','52','--population',c['input']['file'],'--kind',c['kind'],'--reference',c['reference'],'--counts',str(out/'counts.json'),'--target-ms','100','--diagnostic']
  for phase in ['calibration','0']:
   with (out/(phase+'.log')).open('w') as log:subprocess.run(a+['--process',phase,'--out',str(out/phase)],stdout=log,stderr=subprocess.STDOUT,check=True)
r=json.loads((root/'result.json').read_text());r['successful_cells']=len(list(root.glob('*/0/metadata.json')));r['timed_samples']=4*r['successful_cells'];r['completed_cells']=[f.parent.parent.name for f in root.glob('*/0/metadata.json')];(root/'result.json').write_text(json.dumps(r,indent=2)+'\n')
arm=W/'docs/fast-evidence/native-arm-expanded-20261028'
for sums in arm.rglob('SHA256SUMS'):
 for line in sums.read_text().splitlines():
  h,n=line.split(maxsplit=1);f=sums.parent/n.lstrip('*');assert hashlib.sha256(f.read_bytes()).hexdigest()==h,f
# Preserve raw evidence bytes; remove attribution from imported outer prose and
# normalize exposed CSV text to the repository's LF whitespace convention.
for f in arm.rglob('*.md'):
 s=f.read_text();s='\n'.join(line for line in s.split('\n') if not line.startswith('OpenAI Codex'));f.write_text(s)
for f in arm.rglob('*.csv'):
 data=f.read_bytes();f.write_bytes(data.replace(b'\r\n',b'\n'))
for sums in sorted(arm.rglob('SHA256SUMS'),key=lambda x:len(x.parts),reverse=True):
 rows=[]
 for line in sums.read_text().splitlines():
  _,name=line.split(maxsplit=1);f=sums.parent/name.lstrip('*');rows.append(hashlib.sha256(f.read_bytes()).hexdigest()+'  '+name)
 sums.write_text('\n'.join(rows)+'\n')
out=W/'docs/fast-evidence/combined-landing-20261029';out.mkdir(exist_ok=False)
(out/'builds.json').write_bytes((P/'qualification-combined-65bec-builds.json').read_bytes())
(out/'identity.json').write_bytes((P/'qualification-combined-65bec-identity/summary.json').read_bytes())
(out/'smoke.json').write_bytes((root/'result.json').read_bytes())
with tarfile.open(out/'smoke.tar.gz','w:gz') as t:
 for f in sorted(root.rglob('*')):
  if f.is_file():t.add(f,arcname='smoke/'+str(f.relative_to(root)),recursive=False)
 for name in ['qualify-cell.py','native-matrix.c','native-cache.c','identity-qualification-combined-65bec.py','build-qualification-combined-65bec.py','package-combined-smoke.py']:
  t.add(P/name,arcname='harness/'+name,recursive=False)
 for c in m['cells']:
  if c['id'] in r['completed_cells']:
   f=Path(c['input']['file']);t.add(f,arcname='inputs/'+f.name,recursive=False)
(out/'README.md').write_text('''# Combined-source landing checks, 29 October 2026

Runtime source: `65becb36f1b788f0d08bc14cfd44af182d9021da`, combining #240 and #242. All four x86 wrappers were rebuilt with the original Rust toolchain, features, target flags and wrapper source; `builds.json` records their hashes. Each differs from the earlier qualified x86 binary. No old timing is relabeled as qualification of this combination.

All **5,518,032** comparisons pass across automatic, SSE2, AVX2 and AVX-512 scalar/slice paths, including special values, remainders, strong fallback and unchanged strong controls. `identity.json` records zero mismatches and connects the unchanged outputs to the existing independent oracle observations; whole-domain proofs and CI are separate.

The owner explicitly requested focused smoke checks for landing and deferred the full combined native matrix to [#243](https://github.com/MorphIQ-Labs/morphiq-numerics/issues/243), to be run against the normal release tag. Eight focused CPU-2 calls complete: erfcx lengths 0, 3, 8, 9 and 52; scalar and dependent CDF at 52; and a strong erfcx control. These use one process, two paired rounds and a 100ms calibration target. They are execution/diagnostic checks, **not the 250ms-minimum, ten-process confidence qualification**. Empty-call and strong-control costs remain diagnostic. An initial control setup omitted reference-pointer arguments and failed before measurement; its log is retained, and corrected setup ran separately. No production failure occurred.

The full native ARM packet is retained in `../native-arm-expanded-20261028/final-c893-qualified`: 125/125 required decisions at c893513. The earlier x86 packet remains in `../native-matrix-20261028`: 430/430 required decisions at fe6af560. Their source/host scopes remain explicit. Later source integration does not create a new native timing result. Required GitHub CI remains enforced; #194 tracks the release/tag and capability handoff, while #243 owns combined-release performance qualification.

`smoke.tar.gz` retains the raw diagnostic observations, input bits, metadata, failed setup and executed timer/build/identity scripts. `SHA256SUMS` binds the landing files. ARM raw archives are unchanged; exposed CSV line endings use LF. No numerical implementation, numerical bound or acceptance threshold is changed by this evidence commit.
''')
(out/'SHA256SUMS').write_text(''.join(hashlib.sha256(f.read_bytes()).hexdigest()+'  '+f.name+'\n' for f in sorted(out.iterdir()) if f.is_file()))
print('Packaged',r['successful_cells'],'smoke cells,',r['timed_samples'],'diagnostic samples and all ARM evidence')
