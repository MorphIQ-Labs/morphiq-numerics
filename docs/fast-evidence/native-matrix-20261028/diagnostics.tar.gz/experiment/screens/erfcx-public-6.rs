//! High-word table evaluation for the explicit bounded Gaussian APIs.
use super::{T, f, t_reduce};

// Ten high coefficients per row. Padding to a power of two permits the arch
// owner to bound every gather index by masking, without unchecked callers.
const HIGH: [u64; 2048] = {
    let columns = [0, 2, 4, 6, 7, 8, 9, 10, 11, 12];
    let mut high = [0; 2048];
    let mut i = 0;
    while i < T.len() {
        let mut j = 0;
        while j < 10 { high[10 * i + j] = T[i][columns[j]]; j += 1; }
        i += 1;
    }
    high
};

#[inline]
pub(crate) fn table(x: f64) -> f64 {
    let (i, _, h, _) = t_reduce(x);
    let a = &HIGH[10 * i..10 * i + 10];
    let h2 = h * h;
    let p0 = f(a[0]) + h * f(a[1]);
    let p1 = f(a[2]) + h * f(a[3]);
    let p2 = f(a[4]) + h * f(a[5]);
    let p3 = f(a[6]) + h * f(a[7]);
    let p4 = f(a[8]) + h * f(a[9]);
    p0 + h2 * (p1 + h2 * (p2 + h2 * (p3 + h2 * p4)))
}

#[cfg(feature = "simd")]
#[inline(always)]
pub(crate) fn lanes<K: morphiq_numerics_arch::Simd>(k: K, input: K::F) -> K::F {
    let words = k.store(input);
    let mut indices = K::Words::default();
    let mut h = K::Array::default();
    for (i, &x) in words.as_ref().iter().enumerate() {
        let (index, _, residual, _) = t_reduce(x);
        h.as_mut()[i] = residual;
        indices.as_mut()[i] = (index * 10) as u64;
    }
    let indices = k.load_bits(indices);
    let a = |j: u64| k.gather_wrapped(&HIGH, k.add_u(indices, k.splat_bits(j)));
    let h = k.load(h);
    let h2 = k.mul(h, h);
    let p0 = k.add(a(0), k.mul(h, a(1)));
    let p1 = k.add(a(2), k.mul(h, a(3)));
    let p2 = k.add(a(4), k.mul(h, a(5)));
    let p3 = k.add(a(6), k.mul(h, a(7)));
    let p4 = k.add(a(8), k.mul(h, a(9)));
    k.add(p0, k.mul(h2, k.add(p1, k.mul(h2, k.add(p2, k.mul(h2, k.add(p3, k.mul(h2, p4))))))))
}
