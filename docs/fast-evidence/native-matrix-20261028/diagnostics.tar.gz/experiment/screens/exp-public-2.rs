//! Explicit bounded exponential: high-word table and quartic local polynomial.
//! The strong exponential retains its own compensated evaluator.
use super::tables::{INV_N, POLY_S, SHIFTER, S_L1, S_L2D, S_T};

// A layout projection of the existing generated table, not new coefficients.
const HIGH: [u64; 512] = {
    let mut high = [0; 512];
    let mut i = 0;
    while i < 512 { high[i] = S_T[i].0; i += 1; }
    high
};
const SCALE_MASK: u64 = 0xfff0_0000_0000_0000;

#[inline]
pub(crate) fn exp(x: f64) -> f64 {
    if !(x.abs() < 704.0) { return super::exp(x); }
    let t = x * INV_N + SHIFTER;
    let n = t - SHIFTER;
    let bits = t.to_bits();
    #[allow(clippy::cast_possible_truncation)] // masked index is at most 511
    let index = (bits & 511) as usize;
    // Bits 9..20 encode the signed scale modulo 4096. Adding this field to
    // the normal table word is exact for this screened exponent domain.
    let high = f64::from_bits(HIGH[index].wrapping_add((bits << 43) & SCALE_MASK));
    let r = (x - n * S_L1) - n * S_L2D;
    let [d3, d4, _] = POLY_S;
    let p = d3 + r * d4;
    let u = r + (r * r) * (0.5 + r * p);
    high + high * u
}

#[cfg(feature = "simd")]
#[inline(always)]
pub(crate) fn lanes<K: morphiq_numerics_arch::Simd>(k: K, input: K::F) -> K::F {
    let active = k.lt(k.abs(input), k.splat(704.0));
    let x = k.select(active, input, k.splat(0.0));
    let t = k.add(k.mul(x, k.splat(INV_N)), k.splat(SHIFTER));
    let n = k.sub(t, k.splat(SHIFTER));
    let bits = k.to_bits(t);
    let high = k.gather_wrapped(&HIGH, bits);
    let scale = k.and_u(k.shl_u(bits, 43), k.splat_bits(SCALE_MASK));
    let high = k.to_float(k.add_u(k.to_bits(high), scale));
    let r = k.sub(k.sub(x, k.mul(n, k.splat(S_L1))), k.mul(n, k.splat(S_L2D)));
    let [d3, d4, _] = POLY_S;
    let p = k.add(k.splat(d3), k.mul(r, k.splat(d4)));
    let u = k.add(r, k.mul(k.mul(r, r), k.add(k.splat(0.5), k.mul(r, p))));
    let result = k.add(high, k.mul(high, u));
    let active = k.mask_bits(active);
    if active == (1 << K::LANES) - 1 { return result; }
    let x = k.store(input);
    let mut out = k.store(result);
    finish(x.as_ref(), out.as_mut(), active);
    k.load(out)
}

// Keep the strong fallback's constants and control flow out of the vector
// loop. This boundary carries only arrays and scalar operations, never SIMD
// instructions outside the backend's feature-enabled wrapper.
#[cfg(feature = "simd")]
#[inline(never)]
fn finish(input: &[f64], out: &mut [f64], active: u64) {
    for (i, (y, &x)) in out.iter_mut().zip(input).enumerate() {
        if active >> i & 1 == 0 { *y = super::exp(x); }
    }
}

#[cfg(feature = "simd")]
struct Slice<'a> { input: &'a [f64], output: &'a mut [f64] }
#[cfg(feature = "simd")]
impl morphiq_numerics_arch::WithSimd for Slice<'_> {
    type Output = ();
    #[inline(always)]
    fn with<K: morphiq_numerics_arch::Simd>(self, k: K) {
        let mut done = 0;
        while self.input.len() - done >= K::LANES {
            let mut x = K::Array::default();
            x.as_mut().copy_from_slice(&self.input[done..done + K::LANES]);
            let y = lanes(k, k.load(x));
            self.output[done..done + K::LANES].copy_from_slice(k.store(y).as_ref());
            done += K::LANES;
        }
        if done < self.input.len() {
            let y = lanes(k, k.load_partial(&self.input[done..]));
            k.store_partial(y, &mut self.output[done..]);
        }
    }
}

#[cfg(feature = "simd")]
pub(crate) fn slice(input: &[f64], output: &mut [f64]) {
    use morphiq_numerics_arch::Simd;
    if input.len() <= 1 {
        if let Some(&x) = input.first() { output[0] = exp(x); }
        return;
    }
    let op = Slice { input, output };
    #[cfg(all(target_arch = "x86_64", target_feature = "sse2"))]
    {
        use morphiq_numerics_arch::{Avx2, Avx512, Sse2};
        if input.len() >= 8 && let Some(k) = Avx512::try_new() { return k.vectorize(op); }
        if input.len() >= 4 && let Some(k) = Avx2::try_new() { return k.vectorize(op); }
        Sse2::new().vectorize(op);
    }
    #[cfg(not(all(target_arch = "x86_64", target_feature = "sse2")))]
    morphiq_numerics_arch::dispatch(op);
}
