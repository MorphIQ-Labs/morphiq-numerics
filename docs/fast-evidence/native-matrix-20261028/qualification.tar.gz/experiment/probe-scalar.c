#define _POSIX_C_SOURCE 200809L
#include <dlfcn.h>
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <time.h>
typedef double (*scalar)(double);
int main(int argc,char **argv) {
 if(argc!=4) return 2;
 void *lib=dlopen(argv[1],RTLD_NOW); if(!lib){puts(dlerror());return 2;}
 scalar f=(scalar)dlsym(lib,argv[2]);if(!f){puts(dlerror());return 2;}
 FILE *input=fopen(argv[3],"rb");if(!input)return 2;
 double x[256],y[256];size_t n=fread(x,sizeof(double),256,input);fclose(input);if(!n)return 2;
 uint64_t count=100000000/n;
 struct timespec start,end;clock_gettime(CLOCK_MONOTONIC,&start);
 for(uint64_t r=0;r<count;r++) {for(size_t i=0;i<n;i++)y[i]=f(x[i]);__asm__ volatile("" : : "r"(x),"r"(y) : "memory");}
 clock_gettime(CLOCK_MONOTONIC,&end);
 printf("%zu %llu %.6f %.17g\n",n,(unsigned long long)count,((end.tv_sec-start.tv_sec)*1e9+(end.tv_nsec-start.tv_nsec))/(double)count,y[n-1]);return 0;
}
