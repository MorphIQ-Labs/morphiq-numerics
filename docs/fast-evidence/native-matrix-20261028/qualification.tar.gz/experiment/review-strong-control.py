"""Describe strong-exp generated work without treating layout as an invariant."""
from pathlib import Path
from collections import Counter
import json
import os
import re
import subprocess

P=Path(__file__).resolve().parent
assert (P/'qualification-v8/result.json').exists(), 'Review after timing'
os.sched_setaffinity(0,{0})


def functions(path):
    text=subprocess.check_output(['objdump','-d','-C','--no-show-raw-insn',str(path)],text=True)
    result={};name=None
    for line in text.splitlines():
        match=re.match(r'^[0-9a-f]+ <(.+)>:$',line)
        if match:
            name=re.sub(r'\.llvm\.\d+','',match[1])
            result.setdefault(name,[])
        elif name:
            match=re.match(r'^\s*[0-9a-f]+:\s+([\w.]+)\s*(.*)',line)
            if match and match[1] not in ['int3','nop','nopl','nopw']:
                result[name].append(dict(op=match[1],operands=match[2]))
    return result


before=functions(P/'final-bin/control.so')
after=functions(P/'qualification-v8-bin/auto.so')
names=sorted(n for n in before.keys() & after.keys()
    if n in ['control_exp','control_exp_slice'] or 'morphiq_numerics::exp::' in n and '::bounded' not in n)
rows=[]
for name in names:
    a=Counter(x['op'] for x in before[name]);b=Counter(x['op'] for x in after[name])
    rows.append(dict(symbol=name,before_instructions=len(before[name]),after_instructions=len(after[name]),
        opcode_counts_equal=a==b,before_opcodes=dict(a),after_opcodes=dict(b)))
result=dict(scope='Opcode counts only, not a machine-code equivalence proof or a causal explanation of sub-percent timing differences. Numerical identity and source/proof checks are separate.',functions=rows)
(P/'strong-control-code-review.json').write_text(json.dumps(result,indent=2)+'\n')
print('Matched strong-exp functions:',len(rows),'equal opcode counts:',sum(r['opcode_counts_equal'] for r in rows))
for r in rows:
    if not r['opcode_counts_equal']:
        print(r['symbol'],r['before_instructions'],r['after_instructions'])
