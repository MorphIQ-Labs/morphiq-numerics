// Experiment only: no whole-domain error claim; no production API changes.
#![allow(dead_code)]
#[path = "/home/stephen/Development/MorphIQ-Labs/core/morphiq-numerics/crates/morphiq-numerics/src/erfcx/tables.rs"] mod tables;
#[inline] fn f(x:u64)->f64 { f64::from_bits(x) }
#[inline] fn reduce(x:f64)->(usize,f64) {
 if x<1.0 { let k=(x*32.0+6755399441055744.0)-6755399441055744.0;
 ((k as i32+16) as usize,x-k*(1.0/32.0)) }
 else { let b=x.to_bits();let e=((b>>52) as i32)-1023; let i=((b>>47)&31) as usize;
 (49+32*e as usize+i,x-f((b&!((1u64<<47)-1))|(1u64<<46))) }
}
#[inline] fn table_horner(x:f64)->f64 {
 let (i,h)=reduce(x);let a=&tables::T[i];let mut y=f(a[12]);
 for j in (6..12).rev() { y=f(a[j])+h*y; }
 y=f(a[4])+h*y;y=f(a[2])+h*y;f(a[0])+h*y
}
#[inline] fn table_split(x:f64)->f64 {
 let (i,h)=reduce(x);let a=&tables::T[i];let h2=h*h;
 let p0=f(a[0])+h*f(a[2]);let p1=f(a[4])+h*f(a[6]);
 let p2=f(a[7])+h*f(a[8]);let p3=f(a[9])+h*f(a[10]);
 let p4=f(a[11])+h*f(a[12]);
 p0+h2*(p1+h2*(p2+h2*(p3+h2*p4)))
}
#[unsafe(no_mangle)] pub extern "C" fn candidate_erfcx(x:f64)->f64 {
 if (-0.5..16.0).contains(&x)&&x.abs()>=2f64.powi(-33) { table_horner(x) }
 else { morphiq_numerics::normal::erfcx(x) }
}
#[unsafe(no_mangle)] pub extern "C" fn split_erfcx(x:f64)->f64 {
 if (-0.5..16.0).contains(&x)&&x.abs()>=2f64.powi(-33) { table_split(x) }
 else { morphiq_numerics::normal::erfcx(x) }
}
#[unsafe(no_mangle)] pub extern "C" fn candidate_cdf(x:f64)->f64 {
 let a=x.abs();if !(2f64.powi(-33)..=8.0).contains(&a) { return morphiq_numerics::normal::norm_cdf(x); }
 let e=morphiq_numerics::fast::elementary::exp((-0.5*a)*a);
 let lower=(0.5*e)*table_horner(a*f(0x3fe6a09e667f3bcd));
 if x<0.0 { lower } else { 1.0-lower }
}
#[unsafe(no_mangle)] pub extern "C" fn split_cdf(x:f64)->f64 {
 let a=x.abs();if !(2f64.powi(-33)..=8.0).contains(&a) { return morphiq_numerics::normal::norm_cdf(x); }
 let e=morphiq_numerics::fast::elementary::exp((-0.5*a)*a);
 let lower=(0.5*e)*table_split(a*f(0x3fe6a09e667f3bcd));
 if x<0.0 { lower } else { 1.0-lower }
}
#[unsafe(no_mangle)] pub extern "C" fn original_erfcx(x:f64)->f64 { morphiq_numerics::fast::normal::erfcx(x) }
#[unsafe(no_mangle)] pub extern "C" fn original_cdf(x:f64)->f64 { morphiq_numerics::fast::normal::norm_cdf(x) }

#[path = "/home/stephen/Development/MorphIQ-Labs/core/morphiq-numerics/crates/morphiq-numerics/src/exp/tables.rs"] mod exp_tables;
use std::arch::x86_64::*;
static EXP_WORDS:[u64;1024] = { let mut a=[0;1024];let mut i=0;while i<512 {a[2*i]=exp_tables::S_T[i].0;a[2*i+1]=exp_tables::S_T[i].1;i+=1;}a};
#[unsafe(no_mangle)]
pub unsafe extern "C" fn original_exp_slice(x:*const f64,y:*mut f64,n:usize) {
 unsafe {morphiq_numerics::fast::elementary::exp_slice(std::slice::from_raw_parts(x,n),std::slice::from_raw_parts_mut(y,n));}
}
// Experimental AVX-512 entry, caller must check CPU support and valid disjoint slices.
// Gather indices are masked to [0,1023] inside the kernel; no coefficient changes.
#[unsafe(no_mangle)]
#[target_feature(enable="avx512f")]
pub unsafe extern "C" fn gather_exp_slice(x:*const f64,y:*mut f64,len:usize) {
 unsafe {
 let mut i=0;
 while i+8<=len {
  let xv=_mm512_loadu_pd(x.add(i));
  let ax=_mm512_castsi512_pd(_mm512_and_si512(_mm512_castpd_si512(xv),_mm512_set1_epi64(0x7fffffffffffffff)));
  let mask=_mm512_cmp_pd_mask::<_CMP_LT_OQ>(ax,_mm512_set1_pd(704.0));
  let safe=_mm512_maskz_mov_pd(mask,xv);
  let t=_mm512_add_pd(_mm512_mul_pd(safe,_mm512_set1_pd(exp_tables::INV_N)),_mm512_set1_pd(exp_tables::SHIFTER));
  let n=_mm512_sub_pd(t,_mm512_set1_pd(exp_tables::SHIFTER));
  let ni=_mm512_sub_epi64(_mm512_castpd_si512(t),_mm512_set1_epi64(exp_tables::SHIFTER.to_bits() as i64));
  let indices=_mm512_slli_epi64::<1>(_mm512_and_si512(ni,_mm512_set1_epi64(511)));
  let hi=_mm512_i64gather_pd::<8>(indices,EXP_WORDS.as_ptr().cast());
  let lo=_mm512_i64gather_pd::<8>(_mm512_add_epi64(indices,_mm512_set1_epi64(1)),EXP_WORDS.as_ptr().cast());
  let scale=_mm512_castsi512_pd(_mm512_slli_epi64::<52>(_mm512_add_epi64(_mm512_srai_epi64::<9>(ni),_mm512_set1_epi64(1023))));
  let r1=_mm512_sub_pd(safe,_mm512_mul_pd(n,_mm512_set1_pd(exp_tables::S_L1)));
  let r=_mm512_sub_pd(r1,_mm512_mul_pd(n,_mm512_set1_pd(exp_tables::S_L2D)));
  let [d3,d4,d5]=exp_tables::POLY_S;
  let p=_mm512_add_pd(_mm512_set1_pd(d3),_mm512_mul_pd(r,_mm512_add_pd(_mm512_set1_pd(d4),_mm512_mul_pd(r,_mm512_set1_pd(d5)))));
  let u=_mm512_add_pd(r,_mm512_mul_pd(_mm512_mul_pd(r,r),_mm512_add_pd(_mm512_set1_pd(0.5),_mm512_mul_pd(r,p))));
  let result=_mm512_mul_pd(_mm512_add_pd(hi,_mm512_add_pd(lo,_mm512_mul_pd(hi,u))),scale);
  _mm512_storeu_pd(y.add(i),result);
  if mask!=255 {for j in 0..8 {if mask>>j&1==0 {*y.add(i+j)=morphiq_numerics::fast::elementary::exp(*x.add(i+j));}}}
  i+=8;
 }
 while i<len {*y.add(i)=morphiq_numerics::fast::elementary::exp(*x.add(i));i+=1;}
 }
}

#[unsafe(no_mangle)] pub extern "C" fn high_exp(x:f64)->f64 {
 if x.abs()>=704.0 || x.is_nan() {return morphiq_numerics::elementary::exp(x);}
 let t=x*exp_tables::INV_N+exp_tables::SHIFTER;
 let n=t-exp_tables::SHIFTER;let ni=t.to_bits() as i64-exp_tables::SHIFTER.to_bits() as i64;
 let j=(ni&511) as usize;let k=ni>>9;
 let hi=f(exp_tables::S_T[j].0.wrapping_add((k as u64)<<52));
 let r=(x-n*exp_tables::S_L1)-n*exp_tables::S_L2D;
 let [d3,d4,d5]=exp_tables::POLY_S;
 let p=d3+r*(d4+r*d5);let u=r+(r*r)*(0.5+r*p);hi+hi*u
}
#[unsafe(no_mangle)]
#[target_feature(enable="avx512f")]
pub unsafe extern "C" fn high_exp_slice(x:*const f64,y:*mut f64,len:usize) {
 unsafe {
 let mut i=0;
 while i+8<=len {
  let xv=_mm512_loadu_pd(x.add(i));
  let ax=_mm512_castsi512_pd(_mm512_and_si512(_mm512_castpd_si512(xv),_mm512_set1_epi64(0x7fffffffffffffff)));
  let mask=_mm512_cmp_pd_mask::<_CMP_LT_OQ>(ax,_mm512_set1_pd(704.0));
  let safe=_mm512_maskz_mov_pd(mask,xv);
  let t=_mm512_add_pd(_mm512_mul_pd(safe,_mm512_set1_pd(exp_tables::INV_N)),_mm512_set1_pd(exp_tables::SHIFTER));
  let n=_mm512_sub_pd(t,_mm512_set1_pd(exp_tables::SHIFTER));
  let ni=_mm512_sub_epi64(_mm512_castpd_si512(t),_mm512_set1_epi64(exp_tables::SHIFTER.to_bits() as i64));
  let indices=_mm512_slli_epi64::<1>(_mm512_and_si512(ni,_mm512_set1_epi64(511)));
  let hi=_mm512_i64gather_pd::<8>(indices,EXP_WORDS.as_ptr().cast());
  let scaled=_mm512_castsi512_pd(_mm512_add_epi64(_mm512_castpd_si512(hi),_mm512_slli_epi64::<52>(_mm512_srai_epi64::<9>(ni))));
  let r1=_mm512_sub_pd(safe,_mm512_mul_pd(n,_mm512_set1_pd(exp_tables::S_L1)));
  let r=_mm512_sub_pd(r1,_mm512_mul_pd(n,_mm512_set1_pd(exp_tables::S_L2D)));
  let [d3,d4,d5]=exp_tables::POLY_S;
  let p=_mm512_add_pd(_mm512_set1_pd(d3),_mm512_mul_pd(r,_mm512_add_pd(_mm512_set1_pd(d4),_mm512_mul_pd(r,_mm512_set1_pd(d5)))));
  let u=_mm512_add_pd(r,_mm512_mul_pd(_mm512_mul_pd(r,r),_mm512_add_pd(_mm512_set1_pd(0.5),_mm512_mul_pd(r,p))));
  let result=_mm512_add_pd(scaled,_mm512_mul_pd(scaled,u));
  _mm512_storeu_pd(y.add(i),result);
  if mask!=255 {for j in 0..8 {if mask>>j&1==0 {*y.add(i+j)=high_exp(*x.add(i+j));}}}
  i+=8;
 }
 while i<len {*y.add(i)=high_exp(*x.add(i));i+=1;}
 }
}

pub(crate) const CENTER: [(f64, f64); 13] = [
    (
        f64::from_bits(0x3ff0000000000000),
        f64::from_bits(0x0000000000000000),
    ),
    (
        f64::from_bits(0xbfc5555555555555),
        f64::from_bits(0xbc65555555555555),
    ),
    (
        f64::from_bits(0x3f9999999999999a),
        f64::from_bits(0xbc3999999999999a),
    ),
    (
        f64::from_bits(0xbf68618618618618),
        f64::from_bits(0xbc08618618618618),
    ),
    (
        f64::from_bits(0x3f32f684bda12f68),
        f64::from_bits(0x3bd2f684bda12f68),
    ),
    (
        f64::from_bits(0xbef8d3018d3018d3),
        f64::from_bits(0xbb38d3018d3018d3),
    ),
    (
        f64::from_bits(0x3ebc01c01c01c01c),
        f64::from_bits(0x3afc01c01c01c01c),
    ),
    (
        f64::from_bits(0xbe7bbd779334ef0b),
        f64::from_bits(0x3b14e65f77088199),
    ),
    (
        f64::from_bits(0x3e387a00187a0018),
        f64::from_bits(0x3ade80061e80061f),
    ),
    (
        f64::from_bits(0xbdf3777c55568ccd),
        f64::from_bits(0xba7aaabe22270001),
    ),
    (
        f64::from_bits(0x3dac2e3054870b38),
        f64::from_bits(0xba4d5bceb1cfc09c),
    ),
    (
        f64::from_bits(0xbd62b67310aa9f3a),
        f64::from_bits(0xb9f0a97d2e29d0a6),
    ),
    (
        f64::from_bits(0x3d16f448e13e85e1),
        f64::from_bits(0xb997f9c97a441499),
    ),
];

#[unsafe(no_mangle)] pub extern "C" fn central_cdf(x:f64)->f64 {
 let a=x.abs();if !(2f64.powi(-33)..=8.0).contains(&a) {return morphiq_numerics::normal::norm_cdf(x);}
 if a<=1.0 {
  let z=x*x; let mut p=CENTER[12].0;
  for j in (0..12).rev() {p=CENTER[j].0+z*p;}
  return 0.5+(x*f(0x3fd9884533d43651))*p;
 }
 let e=high_exp((-0.5*a)*a);
 let lower=(0.5*e)*table_split(a*f(0x3fe6a09e667f3bcd));
 if x<0.0 {lower} else {1.0-lower}
}
#[unsafe(no_mangle)] pub extern "C" fn high_cdf(x:f64)->f64 {
 let a=x.abs();if !(2f64.powi(-33)..=8.0).contains(&a) {return morphiq_numerics::normal::norm_cdf(x);}
 let e=high_exp((-0.5*a)*a);
 let lower=(0.5*e)*table_split(a*f(0x3fe6a09e667f3bcd));
 if x<0.0 {lower} else {1.0-lower}
}

#[inline]
#[target_feature(enable="avx512f")]
unsafe fn high_vector(xv:__m512d)->(__m512d,u8) {
 unsafe {
  let ax=_mm512_castsi512_pd(_mm512_and_si512(_mm512_castpd_si512(xv),_mm512_set1_epi64(0x7fffffffffffffff)));
  let mask=_mm512_cmp_pd_mask::<_CMP_LT_OQ>(ax,_mm512_set1_pd(704.0));
  let safe=_mm512_maskz_mov_pd(mask,xv);
  let t=_mm512_add_pd(_mm512_mul_pd(safe,_mm512_set1_pd(exp_tables::INV_N)),_mm512_set1_pd(exp_tables::SHIFTER));
  let n=_mm512_sub_pd(t,_mm512_set1_pd(exp_tables::SHIFTER));
  let ni=_mm512_sub_epi64(_mm512_castpd_si512(t),_mm512_set1_epi64(exp_tables::SHIFTER.to_bits() as i64));
  let indices=_mm512_slli_epi64::<1>(_mm512_and_si512(ni,_mm512_set1_epi64(511)));
  let hi=_mm512_i64gather_pd::<8>(indices,EXP_WORDS.as_ptr().cast());
  let scaled=_mm512_castsi512_pd(_mm512_add_epi64(_mm512_castpd_si512(hi),_mm512_slli_epi64::<52>(_mm512_srai_epi64::<9>(ni))));
  let r1=_mm512_sub_pd(safe,_mm512_mul_pd(n,_mm512_set1_pd(exp_tables::S_L1)));
  let r=_mm512_sub_pd(r1,_mm512_mul_pd(n,_mm512_set1_pd(exp_tables::S_L2D)));
  let [d3,d4,d5]=exp_tables::POLY_S;
  let p=_mm512_add_pd(_mm512_set1_pd(d3),_mm512_mul_pd(r,_mm512_add_pd(_mm512_set1_pd(d4),_mm512_mul_pd(r,_mm512_set1_pd(d5)))));
  let u=_mm512_add_pd(r,_mm512_mul_pd(_mm512_mul_pd(r,r),_mm512_add_pd(_mm512_set1_pd(0.5),_mm512_mul_pd(r,p))));
  let result=_mm512_add_pd(scaled,_mm512_mul_pd(scaled,u));
 (result,mask)
 }
}
#[unsafe(no_mangle)]
#[target_feature(enable="avx512f")]
pub unsafe extern "C" fn masked_exp_slice(x:*const f64,y:*mut f64,len:usize) {
 unsafe {
 let mut i=0;
 while i+8<=len {
  let (result,mask)=high_vector(_mm512_loadu_pd(x.add(i)));
  _mm512_storeu_pd(y.add(i),result);
  if mask!=255 {for j in 0..8 {if mask>>j&1==0 {*y.add(i+j)=high_exp(*x.add(i+j));}}}
  i+=8;
 }
 if i<len {
  let valid=((1u16<<(len-i))-1) as u8;
  let (result,mask)=high_vector(_mm512_maskz_loadu_pd(valid,x.add(i)));
  _mm512_mask_storeu_pd(y.add(i),valid,result);
  if mask&valid!=valid {for j in 0..len-i {if mask>>j&1==0 {*y.add(i+j)=high_exp(*x.add(i+j));}}}
 }
 }
}
#[unsafe(no_mangle)] pub extern "C" fn paired_cdf(x:f64)->f64 {
 let a=x.abs();if !(2f64.powi(-33)..=8.0).contains(&a) {return morphiq_numerics::normal::norm_cdf(x);}
 if a<=1.0 {
  let z=x*x;let zz=z*z;
  let p0=CENTER[0].0+z*CENTER[1].0;
  let p1=CENTER[2].0+z*CENTER[3].0;
  let p2=CENTER[4].0+z*CENTER[5].0;
  let p3=CENTER[6].0+z*CENTER[7].0;
  let p4=CENTER[8].0+z*CENTER[9].0;
  let p5=CENTER[10].0+z*CENTER[11].0;
  let p=p0+zz*(p1+zz*(p2+zz*(p3+zz*(p4+zz*(p5+zz*CENTER[12].0)))));
  return 0.5+(x*f(0x3fd9884533d43651))*p;
 }
 let e=high_exp((-0.5*a)*a);
 let lower=(0.5*e)*table_split(a*f(0x3fe6a09e667f3bcd));
 if x<0.0 {lower} else {1.0-lower}
}

static EXP_HIGH:[u64;512]={let mut a=[0;512];let mut i=0;while i<512{a[i]=exp_tables::S_T[i].0;i+=1;}a};
#[inline]
#[target_feature(enable="avx512f")]
unsafe fn compact_vector(xv:__m512d)->(__m512d,u8) {
 unsafe {
  let ax=_mm512_castsi512_pd(_mm512_and_si512(_mm512_castpd_si512(xv),_mm512_set1_epi64(0x7fffffffffffffff)));
  let mask=_mm512_cmp_pd_mask::<_CMP_LT_OQ>(ax,_mm512_set1_pd(704.0));
  let safe=_mm512_maskz_mov_pd(mask,xv);
  let t=_mm512_add_pd(_mm512_mul_pd(safe,_mm512_set1_pd(exp_tables::INV_N)),_mm512_set1_pd(exp_tables::SHIFTER));
  let n=_mm512_sub_pd(t,_mm512_set1_pd(exp_tables::SHIFTER));
  let tb=_mm512_castpd_si512(t);
  let indices=_mm512_and_si512(tb,_mm512_set1_epi64(511));
  let hi=_mm512_i64gather_pd::<8>(indices,EXP_HIGH.as_ptr().cast());
  let scaled=_mm512_castsi512_pd(_mm512_add_epi64(_mm512_castpd_si512(hi),_mm512_and_si512(_mm512_slli_epi64::<43>(tb),_mm512_set1_epi64(0xfff0000000000000u64 as i64))));
  let r1=_mm512_sub_pd(safe,_mm512_mul_pd(n,_mm512_set1_pd(exp_tables::S_L1)));
  let r=_mm512_sub_pd(r1,_mm512_mul_pd(n,_mm512_set1_pd(exp_tables::S_L2D)));
  let [d3,d4,_]=exp_tables::POLY_S;
  let p=_mm512_add_pd(_mm512_set1_pd(d3),_mm512_mul_pd(r,_mm512_set1_pd(d4)));
  let u=_mm512_add_pd(r,_mm512_mul_pd(_mm512_mul_pd(r,r),_mm512_add_pd(_mm512_set1_pd(0.5),_mm512_mul_pd(r,p))));
  let result=_mm512_add_pd(scaled,_mm512_mul_pd(scaled,u));
 (result,mask)
 }
}
#[unsafe(no_mangle)]
#[target_feature(enable="avx512f")]
pub unsafe extern "C" fn compact_exp_slice(x:*const f64,y:*mut f64,len:usize) {
 unsafe {
 let mut i=0;
 while i+8<=len {
  let (result,mask)=compact_vector(_mm512_loadu_pd(x.add(i)));
  _mm512_storeu_pd(y.add(i),result);
  if mask!=255 {for j in 0..8 {if mask>>j&1==0 {*y.add(i+j)=quartic_exp(*x.add(i+j));}}}
  i+=8;
 }
 if i<len {
  let valid=((1u16<<(len-i))-1) as u8;
  let (result,mask)=compact_vector(_mm512_maskz_loadu_pd(valid,x.add(i)));
  _mm512_mask_storeu_pd(y.add(i),valid,result);
  if mask&valid!=valid {for j in 0..len-i {if mask>>j&1==0 {*y.add(i+j)=quartic_exp(*x.add(i+j));}}}
 }
 }
}
#[unsafe(no_mangle)] pub extern "C" fn quartic_exp(x:f64)->f64 {
 if x.abs()>=704.0 || x.is_nan() {return morphiq_numerics::elementary::exp(x);}
 let t=x*exp_tables::INV_N+exp_tables::SHIFTER;
 let n=t-exp_tables::SHIFTER;let ni=t.to_bits() as i64-exp_tables::SHIFTER.to_bits() as i64;
 let j=(ni&511) as usize;let k=ni>>9;
 let hi=f(exp_tables::S_T[j].0.wrapping_add((k as u64)<<52));
 let r=(x-n*exp_tables::S_L1)-n*exp_tables::S_L2D;
 let [d3,d4,_]=exp_tables::POLY_S;
 let p=d3+r*d4;let u=r+(r*r)*(0.5+r*p);hi+hi*u
}
#[unsafe(no_mangle)] pub extern "C" fn quartic_cdf(x:f64)->f64 {
 let a=x.abs();if !(2f64.powi(-33)..=8.0).contains(&a) {return morphiq_numerics::normal::norm_cdf(x);}
 if a<=1.0 {
  let z=x*x;let zz=z*z;
  let p0=CENTER[0].0+z*CENTER[1].0;
  let p1=CENTER[2].0+z*CENTER[3].0;
  let p2=CENTER[4].0+z*CENTER[5].0;
  let p3=CENTER[6].0+z*CENTER[7].0;
  let p4=CENTER[8].0+z*CENTER[9].0;
  let p5=CENTER[10].0+z*CENTER[11].0;
  let p=p0+zz*(p1+zz*(p2+zz*(p3+zz*(p4+zz*(p5+zz*CENTER[12].0)))));
  return 0.5+(x*f(0x3fd9884533d43651))*p;
 }
 let e=quartic_exp((-0.5*a)*a);
 let lower=(0.5*e)*table_split(a*f(0x3fe6a09e667f3bcd));
 if x<0.0 {lower} else {1.0-lower}
}
