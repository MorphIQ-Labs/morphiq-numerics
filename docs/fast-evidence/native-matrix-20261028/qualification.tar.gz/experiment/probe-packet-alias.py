"""Controlled address-offset diagnostic; run only after qualification stops."""
from pathlib import Path
import argparse
import csv
import ctypes as C
import hashlib
import json
import os
import struct

P = Path(__file__).resolve().parent
ap = argparse.ArgumentParser()
ap.add_argument('--length', type=int, choices=[8,9], default=8)
ap.add_argument('--population', choices=['ordinary','wide'], default='wide')
ap.add_argument('--input-offset', type=int, default=1200)
ap.add_argument('--output-offset', type=int)
ap.add_argument('--count', type=int, default=2_000_000)
ap.add_argument('--only', choices=['ours','reference'])
ap.add_argument('--out', required=True)
args = ap.parse_args()
assert (P/'qualification/result.json').exists(), 'Finish the uninstrumented campaign first'
os.sched_setaffinity(0, {2})
out = Path(args.out)
out.mkdir(parents=True, exist_ok=False)
path = P/'qualification-v4-bin/avx512.so'
product = C.CDLL(str(path))
native = C.CDLL(str(P/'bin/native-matrix.so'))
D = C.POINTER(C.c_double)
native.measure_packet.argtypes = [C.c_void_p,D,D,C.c_size_t,C.c_uint64]
native.measure_packet.restype = C.c_uint64
entries = [('ours', C.cast(product.prod_exp_slice,C.c_void_p).value),
           ('reference', C.cast(native.sleef_exp_avx512,C.c_void_p).value)]
if args.only:
    entries = [e for e in entries if e[0] == args.only]
words = json.loads((P/f'qualification-inputs/exp-{args.population}-{args.length}.json').read_text())
values = [struct.unpack('>d',bytes.fromhex(w))[0] for w in words]
storage = [C.create_string_buffer(12288) for _ in range(2)]
bases = [(C.addressof(b)+4095)&~4095 for b in storage]
assert 0 <= args.input_offset < 4096 and args.input_offset%8 == 0
x = C.cast(bases[0]+args.input_offset, D)
for i,value in enumerate(values):x[i]=value
offsets = [args.output_offset] if args.output_offset is not None else list(range(0,4096,8))
assert all(0 <= o < 4096 and o%8 == 0 for o in offsets)
(out/'metadata.json').write_text(json.dumps(dict(arguments=vars(args),
    product_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
    input_words=words, input_address=C.addressof(x.contents),
    buffer_bases=bases, entry_addresses=entries,
    maps=Path('/proc/self/maps').read_text(),
    cpu_before=Path('/proc/stat').read_text(),
    scope='Exploratory controlled offsets; not a replacement qualification campaign'),indent=2)+'\n')
with (out/'samples.csv').open('w') as stream:
    writer=csv.writer(stream)
    writer.writerow(['round','name','input_offset','output_offset','count','elapsed_ns','ns_per_call'])
    for rep in range(2):
        for offset in offsets if rep == 0 else offsets[::-1]:
            y=C.cast(bases[1]+offset,D)
            for name,ptr in entries if rep == 0 else entries[::-1]:
                native.measure_packet(ptr,x,y,args.length,args.count//2)
                elapsed=native.measure_packet(ptr,x,y,args.length,args.count)
                writer.writerow([rep,name,args.input_offset,offset,args.count,elapsed,elapsed/args.count])
(out/'cpu-after.txt').write_text(Path('/proc/stat').read_text())
print(out, flush=True)
