## Current acceptance decision — 2026-10-28

The owner retired the 3% absolute process-range/block-drift gate as unrealistic for this environment. Retain its measurements and failed historical attempts as diagnostics; it is no longer an acceptance blocker. Do not retry until an absolute-spread threshold happens to pass. The meet-or-beat criterion remains every declared comparable-reference pair having a one-sided 95% upper bound on the paired time ratio at or below 1.0, with no allowed slowdown. Preserve raw samples, adequate timed duration, paired order, host conditions and explicit statistical/workload scope.

PR #240's optimized exp/erfcx/CDF subset passes all seven declared x86 52-value reference pairs, including their confidence bounds. The retained [source-bound evidence](https://github.com/MorphIQ-Labs/morphiq-numerics/tree/5aa5d4a/docs/fast-evidence/native-parity-20261028) includes the historical absolute-spread failures; those statements describe the frozen campaign, not a continuing 3% acceptance requirement. CPU 2 is the benchmark core and CPU 14 its idle sibling. The owner directed timing to proceed with unrelated work on other cores recorded. Focused local proof/generator checks are authorized; full CI/tests/lint/determinism remain on GitHub.

The owner requested completion of #194 beyond this packet. Remaining work is the declared native x86/ARM workload/backend matrix, latency and short/remainder/large batches, fallback and composition costs, allocation/footprint/dispatch evidence, full assurance gates, a normal release-PR/tag and capability/adoption handoff to #91/#155. The owner will run the ARM work directly on that host; no SSH connection is needed. See the native ARM handoff below. X86 work continues. The selected implementation rows currently exposed by #240 are exp, erfcx and normal CDF. Unimplemented candidates in #192/#193 are not represented as delivered or implicitly selected by this measurement packet. Consumer integration stays with the consumer; #194 owns the library qualification and handoff.

## Purpose
Final library qualification for fast-tier epic #178. Begin baseline capture before optimization; close only against exact released implementations. This is separate from #149's later complete-baseline comparison campaign and from consumer integration.

## Acceptance
- [ ] Every selected primitive maps to its API, proved domain/error contract, source/proof bindings, independent oracle/witness evidence, scalar/SIMD backends and first usable release tag.
- [ ] Run the declared native ARM/x86 comparator/workload matrix with exact inputs and pinned implementations. Retain repeated paired raw data, stability controls, uncertainty and per-cell/aggregate decisions. Missing evidence or failed required parity criteria remain open, not inferred from CI or before/after improvements.
- [ ] Compare public scalar calls, separate slice calls and available composition interfaces. Measure latency/throughput, short batches/remainders, allocations, dispatch, cache competition, intermediate passes and fallback behavior. Preserve successful-output/refusal populations and operation order.
- [ ] Independently qualify composed outputs against propagated primitive bounds; primitive correctness does not establish a complete consumer algorithm.
- [ ] All required oracle, generator, proof/axiom/binding, mutation, no_std and determinism gates pass. Fast/strong outputs may differ, but each API preserves its own scalar/SIMD and cross-target bits.
- [ ] Release through the normal release-PR/tag workflow with a capability inventory and limitations. Do not silently enlarge 0.1 scope or presume a release number.
- [ ] Hand off adoption guidance to #91/#155. Consumers explicitly choose contracts using their error budgets and independently qualify complete outputs and costs; there is no blanket no-slowdown promise when adopting a stronger guarantee.

## Dependencies

Depends on #191 and the selected implementation rows in #192/#193. Baseline capture starts before implementation; final qualification follows it.

## Native ARM handoff — run directly on the host

The owner will run this work directly on the native ARM host. **No SSH credentials, remote connection, cloud provisioning or pause of another project's job is requested.** This issue is the handoff between machines. Use native AArch64 Linux or Apple Silicon macOS; record which. A Rosetta process, x86 container or emulated ARM run does not establish native ARM performance. CPU 2 / sibling 14 are instructions for the existing x86 host only, not ARM CPU numbers.

### Source and evidence to take to the host

- Current committed baseline: `5aa5d4a116c8f8da3835d46d1cef94687ab26646` on PR #240 (`perf/qdfp-fast-primitives`). It includes the optimized kernels, proof bindings, deliberately updated fast digest and the seven-pair x86 evidence. It is **not yet the final release-qualified candidate**. The exploratory x86 expansion found exp short-slice/AVX2 gaps; experimental dispatch/remainder changes are local and are not in this commit. Do not accidentally benchmark the old `0c5ece3` checkout or treat an uncommitted experiment as the released implementation.
- Read `AGENTS.md`, `docs/PROVENANCE.md`, `docs/fast.md`, the current acceptance decision above and the expanded matrix below. Changes to arithmetic, dispatch, compiler settings or the harness require affected cells to be remeasured and the exact revision/settings recorded. ARM preparation and baseline observations can start now; final acceptance must name the final committed implementation and its usable release tag.
- [Frozen x86 evidence](https://github.com/MorphIQ-Labs/morphiq-numerics/tree/5aa5d4a116c8f8da3835d46d1cef94687ab26646/docs/fast-evidence/native-parity-20261028) includes `README.md`, `summary.json`, `manifest.json`, `SHA256SUMS` and `observations.tar.gz`. Archive SHA-256: `cd89aab5ae35fb47e929d8131d93beea87818cc0a139293ada6b97c0b63dd630`. Inside it, `original-inputs/timed-input-bits.csv` has SHA-256 `0859a015fa53943c2c5375cd56c31fd48ba8d027d3fcd16207013763e5c59087`. Reuse those exact bits, not decimal reconstructions. The archive also contains public Rust wrapper source, reference pins, C timing wrappers, raw paired samples, independent accuracy observations and proof receipts.
- [CI for this baseline](https://github.com/MorphIQ-Labs/morphiq-numerics/actions/runs/40743487102): at handoff, 29 of 30 PR checks are successful; `formal (coq)` is still running. Query the live result before calling it green. Native ARM correctness in CI is already successful; it is not an ARM speed measurement.

Preparation in an existing clean native checkout (Bash):

```bash
set -euo pipefail
git fetch origin perf/qdfp-fast-primitives
bench_revision=5aa5d4a116c8f8da3835d46d1cef94687ab26646
test -z "$(git status --porcelain)"
git switch --detach "$bench_revision"
case "$(uname -m)" in
  aarch64|arm64) ;;
  *) echo 'Use a native ARM shell and toolchain'; exit 1 ;;
esac
bench_out="$PWD/target/arm-194-$(date -u +%Y%m%dT%H%M%SZ)"
mkdir -p "$bench_out/evidence"
git rev-parse HEAD > "$bench_out/revision.txt"
git status --porcelain > "$bench_out/worktree-status.txt"
rustc -vV > "$bench_out/rustc.txt"
cargo -V > "$bench_out/cargo.txt"
uname -a > "$bench_out/kernel.txt"
tar -xzf docs/fast-evidence/native-parity-20261028/observations.tar.gz \
  -C "$bench_out/evidence"
python3 - "$bench_out/evidence" <<'PY'
import hashlib, pathlib, sys
p = pathlib.Path(sys.argv[1]) / 'original-inputs/timed-input-bits.csv'
assert hashlib.sha256(p.read_bytes()).hexdigest() == \
    '0859a015fa53943c2c5375cd56c31fd48ba8d027d3fcd16207013763e5c59087'
PY
env RUSTFLAGS= CARGO_ENCODED_RUSTFLAGS= RUSTC_WRAPPER= RUSTC_WORKSPACE_WRAPPER= \
  CARGO_TARGET_DIR="$bench_out/build" \
  cargo build --locked --release -p morphiq-numerics-reference \
    --features simd,std --bin bench-fast-primitives \
    > "$bench_out/build.log" 2>&1
```

Check that `rustc -vV` also reports an AArch64 host and that no Cargo target override produces a non-native executable. Capture the executable architecture and SHA-256. Rust is pinned by `rust-toolchain.toml` to 1.97.1. Record any necessary host-specific build change; do not enable fast-math or implicit contraction. The commands above prepare the **baseline** and do not run a qualification campaign.

### Harness work needed before final ARM timings

The archived external-comparison scripts are executed x86 evidence, **not a turnkey ARM runner**. Their absolute library paths, Linux CPU-2 affinity, `.so` names and AVX2/AVX-512 wrappers must be adapted explicitly. The repository's `bench-fast-primitives` runner is portable but only compares strong/fast implementations on 52 values; it cannot establish external-reference parity or the expanded matrix by itself. Do not run the historical 3% script below as the current acceptance gate.

1. Rebuild the pinned references listed in the expanded matrix on the ARM host. Keep their native compiler, CMake configuration, build logs and binary hashes. Use native SLEEF binary64 NEON exp-u10 and erfc-u15 entry points, verified against the pinned installed header/exported symbols; do not guess an x86 symbol rename. Use native scalar remainder calls, and include them in the timing. Preserve the CDF composition `0.5 * erfc(x * -0x1.6a09e667f3bcdp-1)` and its rounding order. If a pinned comparator cannot be built, report that cell as unavailable; do not silently substitute platform libm or count it as passed.
2. Adapt the archived Rust cdylib's dependency path to this clean checkout and use the native shared-library extension. Keep `simd,std`, release thin LTO and one codegen unit for the external-wrapper comparison. Both sides use the archived C timer interface, with allocations/input construction outside the clock. SciPy ndtr uses its native Cython capsule with its extra integer argument fixed to one; timing a Python ufunc call would be a different comparison.
3. Materialize and hash every exact input-bit bank and the complete per-cell manifest before qualification. Include the ordinary bank, accelerated-domain coverage, reduction/table boundaries, CDF cancellation/tails, special values and mixed strong-fallback populations. Include the declared public lengths, scalar throughput and dependent latency. Record compiler output showing the dependency chain survives optimization; keep its added arithmetic/call overhead visible. Record dispatch, scalar remainders, empty calls, allocations, code/table footprint, cache competition and intermediate passes separately. The current standalone fast erfcx slice is an inlined scalar loop; do not label it a NEON kernel.
4. Check scalar/slice bit identity and independent 256-bit oracle observations on the actual timed banks/binaries **outside timing windows**. Keep proved bounds separate from observed errors and rounding uncertainty. Full tests, lint and the determinism matrix remain in GitHub CI; focused proof/generator checks are permitted when changed kernels need them, also outside timing windows.
5. Use the expanded paired protocol below, not the historical repeatability campaign. Freeze calibrated counts, retain every attempt, and report every required cell independently. For each process, take the median of its two paired log time ratios; across ten process values compute `exp(mean + t(0.95,9)*sample_stddev/sqrt(10))`. The one-sided 95% upper ratio must be at most 1.0 for each selected comparable-contract cost cell. An upper bound above 1.0 means meet-or-beat is not established; it is not permission to discard data or relax the numerical contract. The 3% absolute-spread criterion is retired.

Use AC power and record power mode, thermal conditions, SoC/core topology and contention. On Linux select a suitable physical core from that host's topology and use `taskset`; record siblings if present. On macOS record the actual scheduling controls and limitations—do not claim Linux-style hard affinity. Run builds, profiling and independent oracle work before or after the timing windows. Do not stop unrelated jobs without authorization. No local full CI is required for this handoff.

### What remains open and what to return

The seven original 52-value x86 pairs passed the paired cost rule. A later short exploratory screen found fast exp slower for automatic 8/9-element slices (about 1.40/1.55 times SLEEF on the ordinary bank) and some AVX2/large wide-domain batches. Those short screen measurements are diagnostic, not a new qualification result. Remainder/dispatch work is being investigated; a complete root cause or a successful fix has not been established. Erfcx/CDF looking competitive in that screen does not replace their required matrix measurements. Do not infer ARM performance from either x86 result.

Return an evidence archive linked from this issue with: clean commit and eventual release tag; source/harness/binary hashes; Rust/C and reference versions/settings; host/conditions/scheduling records; exact input banks and cell manifest; per-cell frozen counts; all calibration, warmup, raw timings, rejected attempts and interruptions; paired confidence summaries; independent accuracy/identity outputs; profiles/allocation/footprint observations collected separately; and all failed or unavailable comparisons. Include executable hashes even if executables are omitted. Preserve meaningful contention/thermal information when redacting private identifiers. Remove throwaway reference clones, worktrees and build output after packaging and verifying the retained evidence; preserve uncommitted work first.

ARM evidence remains open until returned and evaluated. The known x86 gaps, expanded measurements, final assurance checks, normal owner-merged release PR/tag and capability/adoption handoff to #91/#155 also remain open. Recording this handoff does not close #194 or narrow its acceptance criteria.

## Expanded qualification matrix and ARM handoff context — 2026-10-28

Scope is the implemented exp/erfcx/CDF rows of #240. Use the final source/release candidate identified by the implementation PR, not the old 0c5ece3 baseline. Current committed candidate is 5aa5d4a116c8f8da3835d46d1cef94687ab26646; an exploratory expansion found exp short-slice/AVX2 gaps and a follow-up is being evaluated. **Do not treat that exploratory screen as completed qualification or freeze ARM timing on a superseded kernel.** The final revision and executable handoff will replace this candidate notice when ready.

- Native hosts: current i9-10920X, CPU 2 with sibling 14 idle; native ARM will be run directly by the owner on that host. No remote ARM connection or cloud provisioning is required. Record ARM SoC, OS, native architecture, toolchain, power/thermal state and actual scheduling restrictions. Emulation and GitHub timing do not substitute for native ARM speed.
- Exact references: CORE-MATH c7100a07428584639defdd64409e3621884c362b; SLEEF 3.9.0 / 906ca7512ee483296780a81a21b9ca715d40dfe1; libcerf 3.3 / 7e6b637031b5c6cbc89a5f7220bf4ef07518d035; SciPy 1.16.3 / NumPy 2.3.4; independent mpmath 1.3.0 at 256 bits. Use compatible licensed references as black boxes; do not inspect glibc, Apple libm, Cephes or other unqualified implementation source.
- Public scalar exp compares to CORE-MATH and SLEEF scalar; erfcx to libcerf; CDF to SciPy ndtr. Public batched exp/CDF compare to the matching SLEEF SIMD width, with CDF formed as 0.5*erfc(-x/sqrt(2)); erfcx compares to the libcerf scalar loop. Record reference special-value/accuracy/determinism differences explicitly. SciPy erfcx remains diagnostic because retained observations exceed the selected 4u budget.
- Public automatic slices cover every required length: 0–17, 31–33, 51–53, 63–65, 256, 4096, 65536. Length zero is an empty-dispatch diagnostic, not a primitive-throughput parity cell. On x86, separately measure SSE2, AVX2+FMA and AVX-512F exp/CDF paths at lengths 1–17, 52, 4096 and 65536; static erfcx builds at 52/4096 record compiler/ISA effects without falsely calling its scalar loop a vector kernel. ARM covers its native NEON path with the automatic public lengths.
- Ordinary packets preserve the original exact input bits. Additional exact-bit banks cover the accelerated domain, cell/dispatch boundaries, cancellation, representable tails, and mixed screened/fallback inputs at 52 and 4096 values. Fast-screen inputs carry the unchanged 4u relative exp/erfcx or 16u absolute CDF contract. Outside-screen/special-value populations retain strong-owner guarantees and their measured fallback costs; do not impose a weaker-contract comparator's speed on a stronger fallback or hide its cost. Scalar dependent-latency measurements and allocation, empty-dispatch, remainder, footprint, memory-pass/cache and composition evidence are separate from independent throughput.
- Qualification uses one comparator pair per fresh process, avoiding unrelated ISA/workload history inside a process. Ten processes in two blocks of five; two alternating paired samples per process; freeze per-entry counts after excluded calibration targeting 350 ms, with at least 250 ms for every timed sample and an excluded half-count warmup before each sample. This reduces the expanded matrix's wall-clock cost without reducing the ten independent process observations or allowing slower results. Retain all raw samples, calibration, warmups, failures and host records. No builds, oracle work or profiling alongside this experiment's timings.
- Decision stays per cell: median paired log ratio per process; geometric mean and one-sided 95% Student-t upper bound over ten processes (9 degrees of freedom). Every selected comparable-contract cost cell must have upper bound <=1.0. No 3% absolute-spread gate, no permitted slowdown, no discarded outliers, no aggregation hiding losses. Report all descriptive spread and unmatched guarantees. A short exploratory screen cannot pass this rule.
- Build no_std+simd static x86 variants with explicit target features, and the normal simd+std runtime-dispatch variant. These are supported production configurations, not edits that change arithmetic. Verify scalar/slice/output-bit agreement outside timings; archive all flags and binary/source hashes. Use SSE2-compatible scalar remainders for the SSE2 reference, AVX2/FMA for AVX2 and native NEON for ARM.
- Independent oracle observations must cover the exact timed banks and the same public binaries. Proved bounds, observed maxima and reference uncertainty are distinct. Record screen/strong-fallback frequencies by input region; the selected accelerated kernels have no adaptive refinement. Composed public CDF evidence includes its exp/erfcx error propagation and independent exact-input observations. Generic consumer examples need propagated budgets; private consumer integration and product budgets remain with #91/#155.

The ARM return packet must include clean source revision/release tag, source/binary hashes, Rust/C compiler and reference pins, build flags/logs, native host/conditions and scheduling limitations, exact input-bit bank hashes, per-cell frozen counts, all calibration/warmup/raw timings, paired confidence summaries, independent accuracy/identity outputs and any unsupported comparisons. Finish builds before timing; run no local full CI. Clean temporary reference clones/worktrees and build directories after packaging the evidence. Full CI, normal release-PR/tag, capability inventory and adoption handoff are still required before closing #194.

<details>
<summary>Historical local handoff — superseded; retained for audit, not current execution instructions</summary>

The starting revision, 3% gate and repeatability commands in this historical record are superseded by the current acceptance decision and native ARM handoff above. Preserve the failed attempts; do not execute this old protocol for current acceptance.

Use the owner's dedicated local benchmark host for this step. Do not provision GCP resources or use the busy feed Mac as the primary qualification host. This is a **repeatability experiment**, followed by qualification if stable; it is not a request to run CI locally. Release benchmark builds, the runner's consistency checks, independent numerical observations and separate profiling are allowed. Tests, lint, generators, Coq and the determinism matrix remain in GitHub CI.

### Exact starting point and scope

- Repository: `MorphIQ-Labs/morphiq-numerics`, PR #240, branch `perf/qdfp-fast-primitives`.
- **Benchmark revision: `0c5ece39f017b3d4a36231086207272002a58aaa`.** This adds configurable timing iterations and sample-duration reporting; it does not change the library's numerical implementation. **CI update:** all 30 checks, including the complete formal/axiom/extraction gate, passed on `71590a51799f67b45caa1db4bfbed64287e08561` ([run](https://github.com/MorphIQ-Labs/morphiq-numerics/actions/runs/40673841678)). Its numerical runtime, benchmark runner, Cargo files and toolchain have no diff from this pinned benchmark revision; subsequent edits are proof/binding/workflow-only. Native performance qualification is still incomplete. Pin this revision for the campaign. If the final PR head changes, compare its diff before reusing results; changes to numerical code, compiler settings or harness require new measurements.
- Read `AGENTS.md`, `docs/PROVENANCE.md`, `docs/fast.md`, #191 and this issue. The longer handoff in #240 contains the broader qualification requirements and frozen Risk consumer references.
- Runner: `crates/reference/src/bin/bench-fast-primitives.rs`; build with `simd,std`. The pinned toolchain is Rust 1.97.1.
- `MORPHIQ_FAST_BENCH_ITERATIONS` is a positive u32, default 10,000. It controls timed calls **per sample**, not batch size. The batch stays **52 values**. stderr records the count and every sample's `elapsed_ns`; stdout remains `primitive,mode,ns_per_52_value_call` without a header.
- Modes: **0 strong scalar loop; 1 fast scalar loop; 2 strong slice; 3 fast slice**. Four samples per primitive/mode, in alternating/reversed order, 100 warmup calls per sample. Each process also performs an untimed 65,537-point fast scalar/slice comparison. Inputs: exp `[-0.2,0.2]`, erfcx `[0,6]`, normal CDF `[-3,3]`.
- This runner does not cover dependency-chain latency, other batch lengths/distributions, forced individual backends, external comparators, or Greeks/IV. Do not count this repeatability run as full release qualification.

### Why repeat the experiment

The retained GCP pilot is in `docs/fast-evidence/gcp-pilot-20261028/`. All archived accuracy observations passed, but **6/12 timing cells failed the predeclared 3% range criterion**. All block-median drifts were below 3%. Samples were as short as ~1.6 ms; noise amplification is plausible, not a proven root cause. Preserve the failed pilot and its outliers. Its VM and supporting resources were deleted; no further cloud run is needed for this handoff.

### Freeze this protocol before measuring

1. Use an otherwise idle, AC-powered host with a recorded power/governor/turbo policy. On Linux pin one physical core and leave its SMT sibling idle. Do not stop unrelated services without the owner's authorization. Record any unavailable controls; local hardware alone does not prove repeatability.
2. Build once, then finish all builds before timing. No profiler, oracle, other benchmark, CI or feed workload concurrently. Use the same binary and input bits throughout.
3. Run an excluded short calibration to choose a **single common iteration count**, targeting about 500 ms for the fastest observed sample. Freeze that count before the warmup and two measured blocks. Slower cells may take longer than 500 ms. Verify that every retained timed sample lasts at least **250 ms**. Calibration and warmup are retained but excluded from statistics.
4. One warmup process, then **two blocks of five fresh processes**, with a 30-second gap between blocks. Retain all four samples per cell in every process.
5. For each of 12 primitive/interface cells, use the median of its four samples as that process's result. Require **both** `abs(block2_median / block1_median - 1) <= 0.03` and `(max(process_medians) - min(process_medians)) / median(process_medians) <= 0.03`. This is the original pilot stability criterion, not an allowed product regression. All cells must pass; do not average failures away or discard outliers.
6. Report per-process paired fast/strong ratios for scalar and slice separately, along with absolute medians, spread and block drift. Ratios supplement, not replace, the absolute stability gate. These compare two internal contracts; they do not establish external-competitor parity.
7. If stable, repeat the control in a separate idle session on the same local host, retaining the same binary/settings. If it fails, retain the run and investigate recorded contention, frequency/thermal changes and sample durations before proposing another protocol. Do not retry until a passing sample appears. No automatic GCP fallback.

### Build and capture the host (Bash, Linux or macOS)

Use a clean clone/worktree. Commands below are benchmark preparation, not local CI. Native Windows needs an equivalent native build/affinity procedure; WSL results must be labelled WSL, not native Windows.

```bash
set -euo pipefail
git clone git@github.com:MorphIQ-Labs/morphiq-numerics.git morphiq-numerics-pr240
cd morphiq-numerics-pr240
git fetch origin perf/qdfp-fast-primitives
git checkout --detach 0c5ece39f017b3d4a36231086207272002a58aaa
test -z "$(git status --porcelain)" || { echo 'Use a clean checkout'; exit 1; }

bench_out="$PWD/target/pr240-local-$(date -u +%Y%m%dT%H%M%SZ)"
mkdir -p "$bench_out"
git rev-parse HEAD > "$bench_out/revision.txt"
git status --porcelain > "$bench_out/worktree-status.txt"
rustc -vV > "$bench_out/rustc.txt"
cargo -V > "$bench_out/cargo.txt"
uname -a > "$bench_out/kernel.txt"
if command -v lscpu >/dev/null; then
  lscpu > "$bench_out/cpu.txt"
  cat /etc/os-release > "$bench_out/os.txt"
else
  sysctl -n machdep.cpu.brand_string > "$bench_out/cpu.txt"
  sw_vers > "$bench_out/os.txt"
fi
ps -eo pid,pcpu,comm > "$bench_out/processes-before.txt"

env RUSTFLAGS= CARGO_ENCODED_RUSTFLAGS= RUSTC_WRAPPER= RUSTC_WORKSPACE_WRAPPER= \
  CARGO_TARGET_DIR="$bench_out/build" \
  cargo build --locked --release -p morphiq-numerics-reference \
    --features simd,std --bin bench-fast-primitives > "$bench_out/build.log" 2>&1
cp "$bench_out/build/release/bench-fast-primitives" "$bench_out/bench-fast-primitives"

bench_pin=()
if [ "$(uname -s)" = Linux ]; then
  command -v taskset >/dev/null || { echo 'Install taskset before this run'; exit 1; }
  : "${MORPHIQ_BENCH_CPU:?Select an appropriate logical CPU from this host's topology}"
  bench_pin=(taskset -c "$MORPHIQ_BENCH_CPU")
fi
printf '%s\n' "${bench_pin[*]:-unbound; record scheduling limitation}" > "$bench_out/affinity.txt"
```

Before continuing, write `conditions.txt` in `$bench_out`: host/CPU identity and ISA, physical/logical core topology, chosen CPU and sibling, OS/kernel, AC/power mode, governor/EPP/turbo policy, cooling/thermal state, competing activity, ambient compiler/profile overrides (if any), and unavailable controls. Capture available frequency/temperature observations outside timed sections. Do not silently claim fixed frequency or affinity when the platform cannot provide it.

### Calibrate, freeze and measure

```bash
MORPHIQ_FAST_BENCH_ITERATIONS=100000 "${bench_pin[@]}" \
  "$bench_out/bench-fast-primitives" \
  > "$bench_out/calibration.csv" 2> "$bench_out/calibration.stderr"

bench_iterations=$(python3 - "$bench_out/calibration.csv" <<'PY'
import csv, math, sys
rows = list(csv.reader(open(sys.argv[1])))
assert len(rows) == 48
times = [float(row[2]) for row in rows]
assert all(math.isfinite(x) and x > 0 for x in times)
n = math.ceil(500_000_000 / min(times) / 1000) * 1000
assert 1 <= n <= 20_000_000, 'Unexpected calibration; inspect before proceeding'
print(n)
PY
)
export MORPHIQ_FAST_BENCH_ITERATIONS="$bench_iterations"
printf '%s\n' "$bench_iterations" > "$bench_out/timed-iterations.txt"
"${bench_pin[@]}" "$bench_out/bench-fast-primitives" \
  > "$bench_out/warmup.csv" 2> "$bench_out/warmup.stderr"

for block in 1 2; do
  for repetition in 1 2 3 4 5; do
    prefix="$bench_out/block-$block-run-$repetition"
    date -u > "$prefix-start.txt"
    uptime >> "$prefix-start.txt"
    "${bench_pin[@]}" "$bench_out/bench-fast-primitives" \
      > "$prefix.csv" 2> "$prefix.stderr"
    date -u > "$prefix-end.txt"
    uptime >> "$prefix-end.txt"
  done
  if [ "$block" = 1 ]; then sleep 30; fi
done
ps -eo pid,pcpu,comm > "$bench_out/processes-after.txt"
```

Do not use calibration timings as a performance claim. Retain stdout and stderr. Inspect all 48 `elapsed_ns` records in each of the ten measured processes: each must be at least 250,000,000 ns. If the duration requirement is missed, label that campaign invalid for this protocol, preserve it, and increase the count in a separately recorded campaign; do not quietly mix counts or drop its short samples.

### Summarize without discarding outliers

```bash
python3 - "$bench_out" <<'PY'
import csv, json, math, pathlib, statistics, sys
p = pathlib.Path(sys.argv[1])
keys = [(f, m) for f in ('exp', 'erfcx', 'cdf') for m in range(4)]
processes, durations = [], []
for b in (1, 2):
    for r in range(1, 6):
        stem = p / f'block-{b}-run-{r}'
        cells = {k: [] for k in keys}
        for f, mode, ns in csv.reader(open(str(stem) + '.csv')):
            v = float(ns)
            assert math.isfinite(v) and v > 0
            cells[(f, int(mode))].append(v)
        assert all(len(v) == 4 for v in cells.values())
        elapsed = [int(s.rsplit('=', 1)[1]) for s in
                   pathlib.Path(str(stem) + '.stderr').read_text().splitlines()
                   if ',elapsed_ns=' in s]
        assert len(elapsed) == 48
        durations.append(min(elapsed))
        processes.append({k: statistics.median(v) for k, v in cells.items()})
rows = []
for k in keys:
    v = [x[k] for x in processes]
    med = statistics.median(v)
    drift = abs(statistics.median(v[5:]) / statistics.median(v[:5]) - 1)
    spread = (max(v) - min(v)) / med
    rows.append(dict(primitive=k[0], mode=k[1], ns_per_52_value_call=med,
                     process_medians=v, block_drift=drift, relative_range=spread,
                     stable=drift <= .03 and spread <= .03))
ratios = []
for f in ('exp', 'erfcx', 'cdf'):
    for name, strong, fast in (('scalar', 0, 1), ('slice', 2, 3)):
        v = [x[(f, fast)] / x[(f, strong)] for x in processes]
        ratios.append(dict(primitive=f, interface=name, fast_over_strong=v,
                           median=statistics.median(v)))
result = dict(minimum_sample_ns=min(durations),
              sample_duration_valid=min(durations) >= 250_000_000,
              all_cells_stable=all(x['stable'] for x in rows), cells=rows,
              paired_process_ratios=ratios)
(p / 'stability-summary.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
if not (result['sample_duration_valid'] and result['all_cells_stable']):
    raise SystemExit('Repeatability NOT established; retain the complete run')
PY
```

### Replay independent accuracy observations after timing

Use the same binary. This replays retained reference inputs; it does not prove a whole-domain bound or qualify consumer prices/Greeks/IV.

```bash
tar -xzf docs/fast-evidence/qdfp-20261027/observations.tar.gz -C "$bench_out"
"${bench_pin[@]}" "$bench_out/bench-fast-primitives" \
  "$bench_out/observations/fast-reference-inputs.txt" > "$bench_out/observed.csv"
python3 -I "$bench_out/observations/analyze.py" \
  "$bench_out/observations/fast-reference-expected.json" \
  "$bench_out/observed.csv" "$bench_out/error-summary.json" \
  > "$bench_out/error-analysis.log"
python3 - "$bench_out/error-summary.json" <<'PY'
import json, sys
summary = json.load(open(sys.argv[1]))
assert all(not row['failures'] for row in summary.values()), summary
PY
```

The explicit final assertion is necessary: the archived analyzer alone does not fail its exit status for nonempty failure lists. Accelerated contracts: exp relative `2^-51` on `abs(x)<704`; erfcx relative `2^-51` on `-0.5<=x<16` and `abs(x)>=2^-33`; CDF absolute `2^-49` on `2^-33<=abs(x)<=8`. Outside these regions the strong owners apply. Fast CDF has no relative-tail guarantee.

### Return evidence and next decision

Attach/link the complete run directory **excluding `build/` and the executable**. Include its executable's SHA-256, revision/clean-tree status, toolchain/build log and settings, host/conditions/affinity records, frozen iteration count, calibration/warmup, all ten raw CSV/stderr pairs and timestamps/load records, stability/paired-ratio summary, accuracy summary and replay output. Hash the retained inputs and evidence files as well. Preserve failed cells/runs and describe any interruptions. Collect profiles separately after timing, never concurrently. Redact private host/user identifiers as needed without removing relevant performance conditions.

```bash
python3 - "$bench_out" <<'PY'
import hashlib, pathlib, sys
p = pathlib.Path(sys.argv[1])
lines = []
for f in sorted(p.rglob('*')):
    rel = f.relative_to(p)
    if not f.is_file() or rel.parts[0] == 'build' or str(rel) == 'SHA256SUMS':
        continue
    lines.append(f'{hashlib.sha256(f.read_bytes()).hexdigest()}  {rel}')
(p / 'SHA256SUMS').write_text('\n'.join(lines) + '\n')
PY
tar -czf "$bench_out.tar.gz" \
  --exclude="$(basename "$bench_out")/build" \
  --exclude="$(basename "$bench_out")/bench-fast-primitives" \
  -C "$(dirname "$bench_out")" "$(basename "$bench_out")"
```

The manifest deliberately records the executable hash even though the executable is excluded from the archive. With `set -e`, a failed repeatability/accuracy assertion stops the shell sequence; retain the failure and still package it explicitly afterward, rather than treating it as a successful campaign. If metadata needs redaction, retain the original privately and regenerate the shared bundle's hashes after redaction, recording the change.

If repeatable in both sessions, proceed to the matrix in #191/#240: scalar throughput and dependency latency; scalar and native SIMD interfaces; lengths `0–17`, `31–33`, `51–53`, `63–65`, `256`, `4096`, `65536`; ordinary/boundary/tail/special and mixed-fallback inputs; explicit comparator versions/contracts and frozen acceptance rules; dispatch/remainder/cache/allocation costs. One local architecture does not qualify the other. Before a parity claim, freeze the comparator and decision matrix on #191; before merge/release, complete the required formal and cross-target checks too.

The frozen QdFp consumer remains Risk MR !707, revision `fa959bd6d38753071ee5610876c08f16a993ff29`. Do not retune it or attribute these primitive observations to all pricing models. Its exploratory `0.01` price-unit budget is not an approved universal product, Greeks or IV contract. Other-model adoption remains outstanding.

</details>
