from pathlib import Path
import hashlib,json,re,struct,subprocess
P=Path(__file__).resolve().parent;out=P/'qualification-v8-footprints';out.mkdir(exist_ok=False)
source=P/'source/crates/morphiq-numerics/src/exp/bounded_tables.rs';words=re.findall(r'0x[0-9a-f]+',source.read_text())[4:];high=b''.join(struct.pack('<Q',int(w,16)) for w in words);assert len(high)==8192
records=[]
for name in ['auto','sse2','avx2','avx512']:
 path=P/'qualification-v8-bin'/f'{name}.so';data=path.read_bytes();assert data.count(high)==1
 symbols=subprocess.check_output(['nm','-S','-C','--size-sort',str(path)],text=True);(out/(name+'-symbols.txt')).write_text(symbols)
 sections=subprocess.check_output(['size','-A',str(path)],text=True);(out/(name+'-sections.txt')).write_text(sections)
 entries={};wrappers={}
 for line in symbols.splitlines():
  parts=line.split(maxsplit=3)
  if len(parts)!=4:continue
  address,size,kind,symbol=parts
  if kind.lower()!='t':continue
  if any(s in symbol for s in ['morphiq_numerics::exp::bounded','morphiq_numerics::erfcx::bounded','morphiq_numerics::fast::']):entries[address]=max(entries.get(address,0),int(size,16))
  if symbol.startswith('prod_'):wrappers[symbol]=int(size,16)
 records.append(dict(backend=name,sha256=hashlib.sha256(data).hexdigest(),file_bytes=len(data),bounded_exp_table_bytes=len(high),table_occurrences=1,identified_fast_kernel_text_bytes=sum(entries.values()),public_wrapper_text_bytes=wrappers))
(out/'summary.json').write_text(json.dumps(dict(scope='Symbol-attributed fast kernels, not complete transitive call-graph size; full DSO includes strong fallbacks and Rust std wrapper support. Inlined/shared routines prevent additive per-API attribution.',exp_high_bytes=8192,erfcx_shared_table_bytes=177*13*8,cdf_central_high_coefficients_bytes=13*8,builds=records),indent=2)+'\n')
