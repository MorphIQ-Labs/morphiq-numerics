from pathlib import Path
import re
p=Path(__file__).resolve().parent;w=p/'source'
f=w/'crates/morphiq-numerics/src/exp/bounded.rs';s=f.read_text();old=re.search(r'const HIGH: \[u64; 1024\] = \[(.*?)\];',s,re.S).group(1);new=(w/'crates/morphiq-numerics/src/exp/bounded_tables.rs').read_text();assert re.findall('0x[0-9a-f]+',old)==re.findall('0x[0-9a-f]+',new)[4:]
s='//! Explicit bounded exponential: high-word table and constrained cubic.\n\nuse super::bounded_tables::{C2, HIGH, INV, L1, L2D};\nuse super::tables::{POLY_S, SHIFTER};\n\n'+s[s.index('#[inline]'):]
for a,b in [('(INV_N * 2.0)','INV'),('INV_N * 2.0','INV'),('(S_L1 * 0.5)','L1'),('S_L1 * 0.5','L1'),('(S_L2D * 0.5)','L2D'),('S_L2D * 0.5','L2D'),('at most 511','at most 1023'),('bits 0..8','bits 0..9'),('Bits 9..20','Bits 10..21')]:s=s.replace(a,b)
# Replacement of parenthesized expressions must preserve splat's call syntax.
s=s.replace('k.splatINV','k.splat(INV)').replace('k.splatL1','k.splat(L1)').replace('k.splatL2D','k.splat(L2D)')
f.write_text(s)
f=w/'crates/morphiq-numerics/src/exp/mod.rs';f.write_text(f.read_text().replace('pub(crate) mod bounded;','pub(crate) mod bounded;\nmod bounded_tables;'))
f=w/'formal/fast/FastExpScale.v';s=f.read_text();repl={'ExpStageTables':'FastExpTables','st_t_bits':'fx_t_bits','512':'1024','511':'1023','2^21':'2^22','9..20':'10..21','bits 9':'bits 10',' 9':' 10','2^9':'2^10',' 43':' 42','2^43':'2^42','9460198045384704':'4730099022692352'}
for a in sorted(repl,key=len,reverse=True): pass
s=re.sub('|'.join(map(re.escape,sorted(repl,key=len,reverse=True))),lambda m:repl[m[0]],s);f.write_text(s)
# Adapt the independently owned 1024-way reduction from our proved 512-way reduction.
s=(w/'formal/exp/ExpStageReduction.v').read_text();s=s[s.index('Definition stage_of'):s.index('Theorem stage_of_extended_ok')]
repl={'stage_of_wide_ok':'fast_stage_of_ok','stage_of':'fast_stage_of','st_inv':'fx_inv','st_l1':'fx_l1','L_range':'fast_L_range','l1_eq':'fast_l1_eq','l1_close':'fast_l1_close','762':'704','562859':'1040034','562860':'1040035','512':'1024','511':'1023','ni 9':'ni 10','ones 9':'ones 10','-1100':'-1016','<= 1100':'<= 1016','0.000676902':'0.000338451','738.6598':'1477.3196','738.6599':'1477.3198','0.0013538031':'0.0006769016','0.001353803':'0.0006769015','0.001354':'0.000677','(-40)':'(-41)','(-41)':'(-42)','(-10)':'(-11)','(-11)':'(-12)','(-63)':'(-64)','/ 1024':'/ 2048','/ 2048':'/ 4096','/ 2 ^ 42':'/ 2 ^ 41','P42':'P41','4398046511104':'2199023255552','2199023255552':'4398046511104'}
s=re.sub('|'.join(map(re.escape,sorted(repl,key=len,reverse=True))),lambda m:repl[m[0]],s)
s=re.sub(r'\bL\b','fast_L',s)
header='''(** 1024-way bounded exp reduction; all operations are binary64. *)
From Coq Require Import ZArith Reals Lia Lra Psatz Classical.
From Flocq Require Import Core Relative IEEE754.Binary IEEE754.Bits.
From Binary64 Require Import Binary64Add IEEE64 IEEE64Add IEEE64Mul Grid Encodings RoundingConstant.
From Interval Require Import Tactic.
Require Import ExpStageReduction StageGappa FastExpTables.
Open Scope R_scope.
Notation shifter := ExpReduction.shifter.
Definition fast_L : R := ln 2 / 1024.
Lemma fast_L_range : 0.0006769015 <= fast_L <= 0.0006769016.
Proof. unfold fast_L. split; interval with (i_prec 64). Qed.
Lemma fast_l1_eq : B fx_l1 = IZR 1488522236 * bpow radix2 (-41).
Proof. rewrite fx_l1_val. change (-41)%Z with (- Z.of_nat 41)%Z. rewrite bpow_m. field. Qed.
Lemma fast_l1_close : Rabs (fast_L - B fx_l1) <= bpow radix2 (-42).
Proof. unfold fast_L. rewrite fx_l1_val. change (-42)%Z with (- Z.of_nat 42)%Z. rewrite bpow_m. interval with (i_prec 100). Qed.
'''
f=w/'formal/fast/FastExpReduction.v';f.write_text(header+s)
# Reduction's second subtraction: direct absolute rounding estimate.
s=(w/'formal/exp/ExpStageReduction.v').read_text();s=s[s.index('Theorem stage_a_r_ok'):s.index('Theorem stage_a_r_ok')+s[s.index('Theorem stage_a_r_ok'):].index('Qed.')+4]
s=s[:s.index('  set (R :=')] + '''  assert (Split : Rabs (fast_L-B fx_l1-B fx_l2d)<=bpow radix2 (-99)).
  { replace (fast_L-B fx_l1-B fx_l2d) with (-(B fx_l1+B fx_l2d-ln 2/1024)) by (unfold fast_L;ring).
    rewrite Rabs_Ropp. change (-99)%Z with (-Z.of_nat 99)%Z. rewrite bpow_m. exact fx_l_split_d. }
  assert (Csmall : Rabs (B fx_l2d)<=0.0000000000000411) by (rewrite fx_l2d_val;interval).
  assert (Psmall : Rabs (B n*B fx_l2d)<=1040035*0.0000000000000411).
  { rewrite Bn,Rabs_mult. apply Rmult_le_compat;try apply Rabs_pos;assumption. }
  pose proof (ExpReduction.rnd_abs_err (B n*B fx_l2d)) as Err.
  assert (Tiny : bpow radix2 (-1074)<=bpow radix2 (-100)) by (apply bpow_le;lia).
  assert (ErrSmall : Rabs (rn(B n*B fx_l2d)-B n*B fx_l2d)<=
    bpow radix2 (-53)*(1040035*0.0000000000000411)+bpow radix2 (-100)).
  { eapply Rle_trans;[exact Err|]. pose proof (bpow_gt_0 radix2 (-53));nra. }
  rewrite <-Bp in ErrSmall.
  replace (B r1-B(fmul n fx_l2d)-(X-IZR ni*fast_L)) with
    (IZR ni*(fast_L-B fx_l1-B fx_l2d)+(B n*B fx_l2d-B(fmul n fx_l2d))) by (rewrite Br1,Bn;ring).
  eapply Rle_trans;[apply Rabs_triang|]. rewrite Rabs_mult,Rabs_minus_sym.
  assert (S : Rabs(IZR ni)*Rabs(fast_L-B fx_l1-B fx_l2d)<=1040035*bpow radix2 (-99)).
  { apply Rmult_le_compat;try apply Rabs_pos;assumption. }
  bpow_num_all;lra.
Qed.
'''
for a,b in [('stage_a_r_ok','fast_stage_r_ok'),('st_l1','fx_l1'),('st_l2d','fx_l2d'),('520018','1040035'),('0.000677','0.000338451'),('(-10)','(-11)'),('(/ 1024)','(/ 2048)')]:s=s.replace(a,b)
s=re.sub(r'\bL\b','fast_L',s)
f.write_text(f.read_text()+s)
s=(w/'formal/exp/ExpStageA.v').read_text();table=s[s.index('Lemma table_facts'):s.index('Theorem stage_a_at_ok')];split=s[s.index('Lemma exp_split'):s.index('(** exp/mod.rs\'s [E_A]')]
for a,b in [('table_facts','fast_table_facts'),('exp_split','fast_exp_split'),('st_t_','fx_t_'),('512','1024')]:table=table.replace(a,b);split=split.replace(a,b)
split=re.sub(r'\bL\b','fast_L',split);f.write_text(f.read_text()+'\n'+table+split)
