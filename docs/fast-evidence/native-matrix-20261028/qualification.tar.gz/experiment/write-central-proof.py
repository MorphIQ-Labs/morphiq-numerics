from pathlib import Path
p=Path(__file__).resolve().parent/'source/formal/fast/FastNormalCentral.v'
l=['(** Paired bounded central CDF: IEEE transcription and arithmetic certificate. *)',
'From Coq Require Import Reals ZArith Lia Lra Psatz Classical.',
'From Flocq Require Import Core IEEE754.Binary IEEE754.Bits.',
'From Binary64 Require Import Binary64Add IEEE64 IEEE64Add IEEE64Mul.',
'From Gappa Require Import Gappa_library.',
'From Interval Require Import Tactic.',
'Require Import StageGappa ErfcxTableEvaluation ErfcxTableCertificateModel NormalConstants NormalCentered NormalCenterFastConstants NormalCenterFastAnalytic FastNormalCentralAnalytic ExpStageA.',
'Require normal_fast_center.','Open Scope R_scope.']
for name,real in [('fast_normal_center64',False),('fast_normal_center_value',True),('fast_normal_center_ideal',None)]:
 l.append(f'Definition {name} x :=')
 if real is None:
  l+=[' let z:=x*x in let zz:=z*z in']
  for i in range(6):l += [f' let p{i}:=normal_fast_center_coefficient {2*i}+z*normal_fast_center_coefficient {2*i+1} in']
  l+=[' let y6:=normal_fast_center_coefficient 12 in']
  for i in reversed(range(6)):l += [f' let y{i}:=p{i}+zz*y{i+1} in']
  l+=[' /2+x*normal_density_constant*y0.']
 elif real:
  l+=[' let z:=rndF(x*x) in let zz:=rndF(z*z) in']
  for i in range(6):l += [f' let p{i}:=rndF(B normal_center_{2*i}_hi+rndF(z*B normal_center_{2*i+1}_hi)) in']
  l+=[' let y6:=B normal_center_12_hi in']
  for i in reversed(range(6)):l += [f' let y{i}:=rndF(p{i}+rndF(zz*y{i+1})) in']
  l+=[' rndF(B c_half+rndF(rndF(x*B normal_density_hi)*y0)).']
 else:
  l+=[' let z:=fmul x x in let zz:=fmul z z in']
  for i in range(6):l += [f' let p{i}:=fadd normal_center_{2*i}_hi (fmul z normal_center_{2*i+1}_hi) in']
  l+=[' let y6:=normal_center_12_hi in']
  for i in reversed(range(6)):l += [f' let y{i}:=fadd p{i} (fmul zz y{i+1}) in']
  l+=[' fadd c_half (fmul (fmul x normal_density_hi) y0).']
l+=['Lemma fast_normal_center_ieee x : finite x -> Rabs(B x)<=1 ->',
' finite(fast_normal_center64 x) /\\ B(fast_normal_center64 x)=fast_normal_center_value(B x).',
'Proof.',' intros Fx X. pose proof X as Xcopy.']
for i in range(13):
 l += [f' destruct normal_center_{i}_hi_ok as [F{i} W{i}].',f' assert (C{i}:Rabs(B normal_center_{i}_hi)<=1) by (rewrite W{i};interval).']
l += [' destruct normal_density_hi_ok as [Fd Wd].',
' assert (Cd:Rabs(B normal_density_hi)<=/2) by (rewrite Wd;interval).',
' pose proof c_half_finite as Fh.',
' assert (Ch:Rabs(B c_half)<=/2) by (rewrite c_half_g,half_g_eq;rewrite Rabs_pos_eq;lra).',
' table_op fmul_bnd 1%Z 0%Z x x Fz Vz Cz.',
' set (z:=fmul x x) in *. pose proof Cz as Czcopy.',
' table_op fmul_bnd 1%Z 0%Z z z Fzz Vzz Czz.',
' set (zz:=fmul z z) in *.']
for i in range(6):
 l += [f' table_op fmul_bnd 1%Z 0%Z z normal_center_{2*i+1}_hi Fm{i} Vm{i} Cm{i}.',
 f' table_op fadd_bnd 2%Z 0%Z normal_center_{2*i}_hi (fmul z normal_center_{2*i+1}_hi) Fp{i} Vp{i} Cp{i}.',
 f' set (p{i}:=fadd normal_center_{2*i}_hi (fmul z normal_center_{2*i+1}_hi)) in *.']
l += [' set (y6:=normal_center_12_hi) in *.']
for i in reversed(range(6)):
 prev=1+2*(5-i)
 l += [f' table_op fmul_bnd {prev}%Z 0%Z zz y{i+1} Ft{i} Vt{i} Ct{i}.',
 f' table_op fadd_bnd {prev+2}%Z 0%Z p{i} (fmul zz y{i+1}) Fy{i} Vy{i} Cy{i}.',
 f' set (y{i}:=fadd p{i} (fmul zz y{i+1})) in *.']
l += [' table_op fmul_bnd 1%Z (-1)%Z x normal_density_hi Fdx Vdx Cdx.',
' table_op fmul_bnd 13%Z (-1)%Z (fmul x normal_density_hi) y0 Fv Vv Cv.',
' table_op fadd_bnd 7%Z 0%Z c_half (fmul (fmul x normal_density_hi) y0) Fy Vy Cy.',
' unfold fast_normal_center64;fold z zz p0 p1 p2 p3 p4 p5 y6 y5 y4 y3 y2 y1 y0.',
' split;[exact Fy|].',
' rewrite Vy,Vv,Vdx,'+','.join(f'Vy{i},Vt{i}' for i in range(6))+','+','.join(f'Vp{i},Vm{i}' for i in range(6))+',Vzz,Vz.',
' reflexivity.','Qed.']
l += ['Lemma fast_normal_center_ideal_eq x : fast_normal_center_ideal x=/2+normal_center_polynomial 12 x.',
'Proof.',' unfold fast_normal_center_ideal,normal_center_polynomial.',
' rewrite <-(normal_center_mixed_polynomial x).',
' unfold normal_center_mixed_shape;cbn [normal_center_tail_polynomial].',
' ring.','Qed.']
# Canonical float encodings for direct application of Gappa's certificate.
import re,struct
source=(p.parents[1]/'normal/NormalCenterFastConstants.v').read_text()
words=re.findall(r'Definition normal_center_(\d+)_hi := b64_of_bits (\d+)\.',source)
for i,w in words+[('density','4600858325139338833')]:
 val=struct.unpack('>d',int(w).to_bytes(8,'big'))[0];m,d=val.as_integer_ratio();e=-(d.bit_length()-1)
 name=f'normal_center_{i}_hi' if i!='density' else 'normal_density_hi'
 expr=f'Float1 ({m})' if e==0 else f'float2R (Float2 ({m}) ({e}))'
 l += [f'Lemma fast_center_{i}_g : B {name}={expr}.',
       f'Proof. unfold {name};'+('apply word_integer_ok' if e==0 else 'apply word_value_ok')+';vm_compute;reflexivity. Qed.']
l += ['Theorem fast_normal_center_arithmetic x : Rabs x<=1 -> F64 x ->',
' Rabs(fast_normal_center_value x-fast_normal_center_ideal x)<=bpow radix2(-51) /\\',
' 0<=fast_normal_center_value x<=1.',
'Proof.',' intros X F. assert (Rx:rn x=x) by (apply round_generic;[exact _|exact F]).',
' set (delta:=normal_density_constant-B normal_density_hi).',
' assert (D:Rabs delta<=bpow radix2(-54)).',
' { unfold delta,normal_density_constant;rewrite (proj2 normal_density_hi_ok);bpow_num;interval with(i_prec 100). }',
' assert (Density:normal_density_constant=B normal_density_hi+delta) by (unfold delta;ring).',
' unfold fast_normal_center_value,fast_normal_center_ideal;rewrite Density.',
' rewrite c_half_g,half_g_eq,'+','.join('fast_center_'+i+'_g' for i,_ in words)+',fast_center_density_g.',
' unfold normal_fast_center_coefficient;binary_factorials;repeat rewrite INR_IZR_INZ;small_numerals.',
' apply Rabs_le_inv in X,D.',
' rewrite <-Rx at 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20.',
' split;[apply Rabs_le|];repeat split;erfcx_goal (normal_fast_center.l1 x delta).',
'Qed.']
p.write_text('\n'.join(l)+'\n')
