
target/benchmarks/pr240-parity-next-20261028/bin/native-matrix.so:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000000f30 <measure_chain1>:
     f30:	48 83 ec 78          	sub    $0x78,%rsp
     f34:	48 89 5c 24 48       	mov    %rbx,0x48(%rsp)
     f39:	48 89 f3             	mov    %rsi,%rbx
     f3c:	48 89 6c 24 50       	mov    %rbp,0x50(%rsp)
     f41:	48 89 cd             	mov    %rcx,%rbp
     f44:	4c 89 74 24 68       	mov    %r14,0x68(%rsp)
     f49:	49 89 d6             	mov    %rdx,%r14
     f4c:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
     f51:	48 85 c9             	test   %rcx,%rcx
     f54:	0f 84 16 01 00 00    	je     1070 <measure_chain1+0x140>
     f5a:	4c 89 7c 24 70       	mov    %r15,0x70(%rsp)
     f5f:	66 0f ef c0          	pxor   %xmm0,%xmm0
     f63:	4c 89 64 24 58       	mov    %r12,0x58(%rsp)
     f68:	49 89 fc             	mov    %rdi,%r12
     f6b:	4c 89 6c 24 60       	mov    %r13,0x60(%rsp)
     f70:	41 bd 64 00 00 00    	mov    $0x64,%r13d
     f76:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
     f7d:	00 00 00 
     f80:	45 31 ff             	xor    %r15d,%r15d
     f83:	66 90                	xchg   %ax,%ax
     f85:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
     f8c:	00 00 00 00 
     f90:	f2 0f 5c c0          	subsd  %xmm0,%xmm0
     f94:	f2 42 0f 58 04 fb    	addsd  (%rbx,%r15,8),%xmm0
     f9a:	49 83 c7 01          	add    $0x1,%r15
     f9e:	41 ff d4             	call   *%r12
     fa1:	4c 39 fd             	cmp    %r15,%rbp
     fa4:	75 ea                	jne    f90 <measure_chain1+0x60>
     fa6:	49 83 ed 01          	sub    $0x1,%r13
     faa:	75 d4                	jne    f80 <measure_chain1+0x50>
     fac:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
     fb1:	bf 01 00 00 00       	mov    $0x1,%edi
     fb6:	f2 0f 11 44 24 28    	movsd  %xmm0,0x28(%rsp)
     fbc:	45 31 ed             	xor    %r13d,%r13d
     fbf:	48 89 74 24 20       	mov    %rsi,0x20(%rsp)
     fc4:	e8 f7 f2 ff ff       	call   2c0 <clock_gettime@plt>
     fc9:	f2 0f 10 44 24 28    	movsd  0x28(%rsp),%xmm0
     fcf:	48 69 44 24 30 00 ca 	imul   $0x3b9aca00,0x30(%rsp),%rax
     fd6:	9a 3b 
     fd8:	48 83 7c 24 08 00    	cmpq   $0x0,0x8(%rsp)
     fde:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
     fe3:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
     fe8:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
     fed:	74 32                	je     1021 <measure_chain1+0xf1>
     fef:	45 31 ff             	xor    %r15d,%r15d
     ff2:	0f 1f 00             	nopl   (%rax)
     ff5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
     ffc:	00 00 00 00 
    1000:	f2 0f 5c c0          	subsd  %xmm0,%xmm0
    1004:	f2 42 0f 58 04 fb    	addsd  (%rbx,%r15,8),%xmm0
    100a:	49 83 c7 01          	add    $0x1,%r15
    100e:	41 ff d4             	call   *%r12
    1011:	4c 39 fd             	cmp    %r15,%rbp
    1014:	75 ea                	jne    1000 <measure_chain1+0xd0>
    1016:	49 83 c5 01          	add    $0x1,%r13
    101a:	4c 39 6c 24 08       	cmp    %r13,0x8(%rsp)
    101f:	75 ce                	jne    fef <measure_chain1+0xbf>
    1021:	4c 8b 64 24 58       	mov    0x58(%rsp),%r12
    1026:	4c 8b 6c 24 60       	mov    0x60(%rsp),%r13
    102b:	4c 8b 7c 24 70       	mov    0x70(%rsp),%r15
    1030:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
    1035:	f2 41 0f 11 06       	movsd  %xmm0,(%r14)
    103a:	bf 01 00 00 00       	mov    $0x1,%edi
    103f:	e8 7c f2 ff ff       	call   2c0 <clock_gettime@plt>
    1044:	48 8b 5c 24 48       	mov    0x48(%rsp),%rbx
    1049:	48 8b 6c 24 50       	mov    0x50(%rsp),%rbp
    104e:	48 69 44 24 30 00 ca 	imul   $0x3b9aca00,0x30(%rsp),%rax
    1055:	9a 3b 
    1057:	4c 8b 74 24 68       	mov    0x68(%rsp),%r14
    105c:	48 2b 44 24 10       	sub    0x10(%rsp),%rax
    1061:	48 03 44 24 38       	add    0x38(%rsp),%rax
    1066:	48 2b 44 24 18       	sub    0x18(%rsp),%rax
    106b:	48 83 c4 78          	add    $0x78,%rsp
    106f:	c3                   	ret
    1070:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
    1075:	bf 01 00 00 00       	mov    $0x1,%edi
    107a:	48 89 74 24 20       	mov    %rsi,0x20(%rsp)
    107f:	e8 3c f2 ff ff       	call   2c0 <clock_gettime@plt>
    1084:	48 69 44 24 30 00 ca 	imul   $0x3b9aca00,0x30(%rsp),%rax
    108b:	9a 3b 
    108d:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    1092:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    1097:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    109c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    10a1:	48 85 c0             	test   %rax,%rax
    10a4:	74 1c                	je     10c2 <measure_chain1+0x192>
    10a6:	a8 01                	test   $0x1,%al
    10a8:	74 0d                	je     10b7 <measure_chain1+0x187>
    10aa:	bd 01 00 00 00       	mov    $0x1,%ebp
    10af:	48 83 7c 24 08 01    	cmpq   $0x1,0x8(%rsp)
    10b5:	74 0b                	je     10c2 <measure_chain1+0x192>
    10b7:	48 83 c5 02          	add    $0x2,%rbp
    10bb:	48 39 6c 24 08       	cmp    %rbp,0x8(%rsp)
    10c0:	75 f5                	jne    10b7 <measure_chain1+0x187>
    10c2:	66 0f ef c0          	pxor   %xmm0,%xmm0
    10c6:	e9 65 ff ff ff       	jmp    1030 <measure_chain1+0x100>

Disassembly of section .fini:
