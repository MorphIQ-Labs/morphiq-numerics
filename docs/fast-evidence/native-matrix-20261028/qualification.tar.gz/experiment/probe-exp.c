#define _POSIX_C_SOURCE 200809L
#include <dlfcn.h>
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <time.h>
typedef void (*packet)(const double*,double*,size_t);
int main(int argc,char **argv) {
 if(argc!=4 && argc!=5) return 2;
 void *lib=dlopen(argv[1],RTLD_NOW); if(!lib){puts(dlerror());return 2;}
 packet f=(packet)dlsym(lib,argv[2]);if(!f){puts(dlerror());return 2;}
 size_t n=strtoul(argv[3],NULL,10);double *x=malloc(n*sizeof(double)),*y=malloc(n*sizeof(double));
 for(size_t i=0;i<n;i++) x[i]= argc==5 ? -703.999+1407.998*((double)i+0.5)/(double)n : -0.2+0.4*(double)(i%52)/51.0;
 uint64_t count=80000000/(n/8+1);
 struct timespec start,end;clock_gettime(CLOCK_MONOTONIC,&start);
 for(uint64_t i=0;i<count;i++) {f(x,y,n);__asm__ volatile("" : : "r"(x),"r"(y) : "memory");}
 clock_gettime(CLOCK_MONOTONIC,&end);
 printf("%zu %llu %.6f %.17g\n",n,(unsigned long long)count,((end.tv_sec-start.tv_sec)*1e9+(end.tv_nsec-start.tv_nsec))/(double)count,y[n-1]);
 free(x);free(y);return 0;
}
