"""Exploratory screen only. Every cell is retained; this cannot qualify parity."""
from pathlib import Path
import csv,json,math,statistics,subprocess,sys,time
P=Path(__file__).resolve().parent
label=sys.argv[1]
root=P/('screen-'+label);root.mkdir(exist_ok=False)
cells=json.loads((P/'matrix-manifest.json').read_text())['cells']
cells=[c for c in cells if c['backend']=='auto' and not c['control'] and ((c['primitive']=='exp' and c['kind']=='vector' and c['population'] in ['ordinary','wide']) or (c['primitive']=='cdf' and c['kind']=='scalar'))]
for c in cells:c['product']=str(P/'candidates'/(label+'.so'))
rows=[]
for i,c in enumerate(cells):
 out=root/c['id'];out.mkdir()
 args=[sys.executable,str(P/'pair-cell.py'),'--product',c['product'],'--primitive',c['primitive'],'--length',str(c['length']),'--population',c['input']['file'],'--kind',c['kind'],'--reference',c['reference'],'--counts',str(out/'counts.json'),'--target-ms','70','--diagnostic']
 if c['control']:args+=['--symbol-prefix','control_','--reference-product',str(P/'final-bin/control.so')]
 for proc in ['calibration','0']:
  cmd=args+['--process',proc,'--out',str(out/proc)]
  r=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
  (out/(proc+'.log')).write_text(r.stdout)
  if r.returncode:raise SystemExit(f'{c["id"]} failed {proc}: {r.stdout}')
 samples=[json.loads(l) for l in (out/'0/samples.jsonl').read_text().splitlines()]
 samples=[r for r in samples if r['kind']=='timed']
 ours=[r['ns_per_call'] for r in samples if r['name']=='ours'];reference=[r['ns_per_call'] for r in samples if r['name']=='reference']
 ratio=math.exp(statistics.mean(math.log(a/b) for a,b in zip(ours,reference)))
 row=dict(id=c['id'],required=c['required_parity'],ratio=ratio,ours_ns=statistics.median(ours),reference_ns=statistics.median(reference))
 rows.append(row)
 with (root/'summary.csv').open('w') as f:
  w=csv.DictWriter(f,fieldnames=list(row));w.writeheader();w.writerows(rows)
 if (i+1)%25==0:print(f'{i+1}/{len(cells)} cells; {sum(r["required"] and r["ratio"]>1 for r in rows)} required cells slower in this diagnostic',flush=True)
print('Exploratory screen complete; no acceptance inference.',flush=True)
