## Capability and adoption handoff for #91 / #155

The candidate is PR #240 at `fe6af5609433ed9fa5d383e816c4c6f856fcbd3b`.
It is not a released consumer dependency. Fill the first usable release tag
only after the owner merges the implementation PR and the normal release PR.
Consumers pin that exact tag; no 0.1 prerequisite or completing version is
assumed. This packet covers only the following selected primitives.

| Public API (each also has `_slice`) | Accelerated domain and proved bound | Current batch implementation | First usable release |
| --- | --- | --- | --- |
| `fast::elementary::exp` | `abs(x) < 704`; relative error <= `2^-51` | Scalar; explicit SSE2, AVX2+FMA, AVX-512F and NEON kernels through the existing safe dispatch boundary | Pending normal release |
| `fast::normal::erfcx` | `-0.5 <= x < 16` and `abs(x) >= 2^-33`; relative error <= `2^-51` | Public slice is a scalar loop. Its internal lane evaluator is reused by CDF; do not describe the public slice as a dedicated SIMD erfcx kernel | Pending normal release |
| `fast::normal::norm_cdf` | `2^-33 <= abs(x) <= 8`; absolute error <= `2^-49` | Scalar; explicit central/tail SIMD composition, screened per-lane strong fallback, scalar remainders | Pending normal release |

Outside the accelerated domains, each API delegates to its existing strong
owner, preserving that owner's bounds and IEEE special-value semantics.
The slice APIs require equal input/output lengths and allocate no scratch.
`simd` enables the existing architecture boundary; `simd,std` enables runtime
CPU detection. Features must preserve scalar bits within the chosen API.
Native ARM speed remains unestablished until the owner-run packet is returned;
ARM correctness in CI does not establish native speed.

The source-bound derivation is `docs/fast.md`; the entry proof owners are
`FastExp.fast_exp_entry_ok`, `FastErfcx` and `FastNormal` under `formal/fast/`.
Generated constants, Gappa certificates, extracted-entry and axiom audits,
independent reference fixtures and target determinism remain required gates.
The fast-output digest deliberately changes to
`e454da537b20b961babd4309b52febf346a4b5afbadf79366d4b819eba78198b`.
The strong APIs' arithmetic, seeded streams and reduction order are unchanged.
Fast/strong output equality is not promised; scalar/SIMD equality within each
selected API is required and independently observed.

The consumer must choose each fast call using its propagated error budget.
CDF's accelerated contract is absolute, with no relative-tail guarantee;
subtraction, derivatives and inversion can amplify this error. Direct strong
tail/log/centered APIs remain distinct capabilities. Do not replace a CCDF,
log-CDF, quantile or derivative with an unqualified composition merely because
this CDF is faster. Requalify actual prices, Greeks, inverses, admission/refusal
behavior and full-chain cost in the consumer's tracker against independent
references. Synthetic library timings do not establish consumer performance.

The x86 packet records ordinary/wide/boundary/cancellation/tail/mixed/fallback
banks, short slices and remainders, large batches, dependency-chain latency,
cache-pressure calls, allocation observations and code/table footprints.
The public CDF composition is included; unrelated consumer compositions and
the broader capability requirements in #155 remain with their existing owners.
Missing candidates in #192/#193 are not delivered by this packet. #194 remains
open until required x86 and ARM decisions, full CI, the normal release/tag and
the release-bound inventory are complete.
