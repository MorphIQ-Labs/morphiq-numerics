"""Select complete evidence per final binary, retaining the superseded campaign."""
from pathlib import Path
import csv
import hashlib
import json
import os

P = Path(__file__).resolve().parent
os.sched_setaffinity(0, {0})
old = P/'qualification'
new = P/'qualification-v8'
assert json.loads((old/'result.json').read_text())['complete']
assert json.loads((new/'result.json').read_text())['complete']
old_bytes = (P/'qualification-manifest.json').read_bytes()
new_bytes = (P/'qualification-v8-manifest.json').read_bytes()
assert hashlib.sha256(old_bytes).hexdigest() == (old/'manifest.sha256').read_text().strip()
assert hashlib.sha256(new_bytes).hexdigest() == (new/'manifest.sha256').read_text().strip()
before, after = json.loads(old_bytes), json.loads(new_bytes)
old_builds = {b['name']:b['sha256'] for b in before['builds']}
new_builds = {b['name']:b['sha256'] for b in after['builds']}
assert {k for k in new_builds if new_builds[k]!=old_builds[k]} == {'avx512'}
assert before['protocol'] == after['protocol']
assert before['reference_binary_sha256'] == after['reference_binary_sha256']
for a,b in zip(before['cells'],after['cells'],strict=True):
    assert {k:v for k,v in a.items() if k!='product'} == {k:v for k,v in b.items() if k!='product'}
old_rows = {r['id']:r for r in json.loads((old/'summary.json').read_text())}
new_rows = {r['id']:r for r in json.loads((new/'summary.json').read_text())}
assert len(old_rows)==500 and len(new_rows)==84
rows = []
sources = {}
for cell in after['cells']:
    changed = cell['backend']=='avx512'
    rows.append((new_rows if changed else old_rows)[cell['id']])
    sources[cell['id']] = 'qualification-v8' if changed else 'qualification'
destination = P/'qualification-final'
destination.mkdir(exist_ok=False)
(destination/'manifest.sha256').write_text(hashlib.sha256(new_bytes).hexdigest()+'\n')
(destination/'evidence-sources.json').write_text(json.dumps(sources,indent=2)+'\n')
(destination/'summary.json').write_text(json.dumps(rows,indent=2)+'\n')
with (destination/'summary.csv').open('w') as stream:
    writer=csv.DictWriter(stream,fieldnames=list(rows[0]))
    writer.writeheader();writer.writerows(rows)
failures=[r['id'] for r in rows if r['required'] and not r['passes']]
result=dict(complete=True,cells=len(rows),required=sum(r['required'] for r in rows),
    failures=failures,all_required_pass=not failures,
    unchanged_binary_cells=416,changed_binary_cells=84,
    source_revision=after['source_revision'],
    superseded_attempt='qualification; all raw data retained, including the three failed old-binary cases')
(destination/'result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
