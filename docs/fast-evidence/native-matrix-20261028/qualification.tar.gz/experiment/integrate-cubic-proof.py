from pathlib import Path
p=Path(__file__).resolve().parent;w=p/'source';f=w/'formal/fast/FastExpPolynomial.v';s=f.read_text()
s=s.replace("(** Bounded exponential's quartic, using the existing reduction and coefficients. *)","(** Constrained cubic: independently certified on the 1024-way reduction. *)")
s=s.replace('Require exp_fast_quartic.','Require Import FastExpTables FastExpReduction.\nRequire exp_fast_cubic.')
a=s.index('Definition fast_quartic64');b=s.index('Lemma fast_quartic_certificate')
s=s[:a]+'''Definition fast_c2_g : R := float2R (Float2 2251799831492399 (-52)).
Lemma fast_c2_g_eq : B fx_c2=fast_c2_g.
Proof. rewrite fx_c2_val. unfold fast_c2_g,float2R,F2R. simpl. bpow_num_all;lra. Qed.
Definition fast_cubic64 r :=
 let r2:=fmul r r in
 let p:=fadd fx_c2 (fmul r st_d3) in
 fadd r (fmul r2 p).
Definition fast_cubic_value r :=
 let r2:=rn(r*r) in
 let p:=rn(fast_c2_g+rn(r*d3_g)) in
 rn(r+rn(r2*p)).
Lemma fast_cubic_ieee r : finite r -> Rabs(B r)<=/1024 ->
 finite(fast_cubic64 r) /\\ B(fast_cubic64 r)=fast_cubic_value(B r).
Proof.
 intros Fr Rr.
 pose proof st_d3_finite as F3;pose proof fx_c2_finite as Fc.
 assert (C3:Rabs(B st_d3)<=/4) by (rewrite st_d3_val;interval).
 assert (Cc:Rabs(B fx_c2)<=3/4) by (rewrite fx_c2_val;interval).
 pose proof Rr as Rr_copy.
 table_op fmul_bnd 1%Z (-20)%Z r r F2 V2 C2.
 table_op fmul_bnd 1%Z (-12)%Z r st_d3 Fm Vm Cm.
 table_op fadd_bnd 1%Z 0%Z fx_c2 (fmul r st_d3) Fp Vp Cp.
 table_op fmul_bnd 1%Z (-20)%Z (fmul r r) (fadd fx_c2 (fmul r st_d3)) Fv Vv Cv.
 table_op fadd_bnd 1%Z (-9)%Z r
   (fmul (fmul r r) (fadd fx_c2 (fmul r st_d3))) Fu Vu Cu.
 unfold fast_cubic64. split;[exact Fu|].
 rewrite Vu,Vv,Vp,Vm,V2,fast_c2_g_eq,d3_g_eq. reflexivity.
Qed.
'''+s[b:]
s=s.replace('fast_quartic','fast_cubic').replace('exp_fast_quartic','exp_fast_cubic').replace('Rabs R<=0.000677','Rabs R<=0.000338451').replace('bpow radix2(-59)','7*bpow radix2(-56)')
s=s.replace('fast_cubic_value,Qs,half_g','fast_cubic_value,fast_c2_g,Qs,half_g').replace('st_poly_approx R HR','st_poly_approx R ltac:(lra)')
f.write_text(s)
f=w/'formal/fast/FastExpReconstruction.v';f.write_text(f.read_text().replace('bpow radix2(-59)','7*bpow radix2(-56)'))
f=w/'formal/fast/FastExp.v';s=f.read_text().replace('quartic','cubic').replace('FastExpScale FastExpPolynomial','FastExpTables FastExpReduction FastExpScale FastExpPolynomial')
import re
for a,b in [('stage_of_ok','fast_stage_of_ok'),('stage_of','fast_stage_of'),('stage_a_r_ok','fast_stage_r_ok'),('st_l2d','fx_l2d'),('table_facts','fast_table_facts'),('st_t_','fx_t_'),('exp_split','fast_exp_split'),('512','1024'),('bpow radix2(-59)','7*bpow radix2(-56)')]:
 if a in ['stage_of','stage_of_ok','stage_a_r_ok','table_facts','exp_split']:s=re.sub(r'\b'+a+r'\b',b,s)
 else:s=s.replace(a,b)
s=re.sub(r'\*L\b','*fast_L',s);f.write_text(s)
