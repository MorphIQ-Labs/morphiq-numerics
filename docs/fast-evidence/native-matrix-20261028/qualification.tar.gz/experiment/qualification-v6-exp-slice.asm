
target/benchmarks/pr240-parity-next-20261028/qualification-v6-bin/avx512.so:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .text:

0000000000027e90 <prod_exp_slice>:
   27e90:	48 83 ec 28          	sub    $0x28,%rsp
   27e94:	48 89 d1             	mov    %rdx,%rcx
   27e97:	48 89 f2             	mov    %rsi,%rdx
   27e9a:	48 8d 41 f8          	lea    -0x8(%rcx),%rax
   27e9e:	48 83 f8 03          	cmp    $0x3,%rax
   27ea2:	73 11                	jae    27eb5 <prod_exp_slice+0x25>
   27ea4:	48 83 f9 08          	cmp    $0x8,%rcx
   27ea8:	75 16                	jne    27ec0 <prod_exp_slice+0x30>
   27eaa:	48 89 d6             	mov    %rdx,%rsi
   27ead:	ff 15 7d 17 06 00    	call   *0x6177d(%rip)        # 89630 <_DYNAMIC+0x550>
   27eb3:	eb 2a                	jmp    27edf <prod_exp_slice+0x4f>
   27eb5:	48 89 ce             	mov    %rcx,%rsi
   27eb8:	ff 15 7a 17 06 00    	call   *0x6177a(%rip)        # 89638 <_DYNAMIC+0x558>
   27ebe:	eb 1f                	jmp    27edf <prod_exp_slice+0x4f>
   27ec0:	48 89 7c 24 08       	mov    %rdi,0x8(%rsp)
   27ec5:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
   27eca:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
   27ecf:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
   27ed4:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
   27ed9:	ff 15 61 17 06 00    	call   *0x61761(%rip)        # 89640 <_DYNAMIC+0x560>
   27edf:	48 83 c4 28          	add    $0x28,%rsp
   27ee3:	c3                   	ret
   27ee4:	ff 15 9e 15 06 00    	call   *0x6159e(%rip)        # 89488 <_DYNAMIC+0x3a8>

Disassembly of section .plt:
