from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess

P = Path(__file__).resolve().parent
records = []
(P/'qualification-v4-bin').mkdir(exist_ok=False)
variants = [
    ('auto', 'simd,std', ''),
    ('sse2', 'simd', '-C target-feature=-avx,-avx2,-avx512f,-fma'),
    ('avx2', 'simd', '-C target-feature=+avx2,+fma,-avx512f'),
    ('avx512', 'simd', '-C target-feature=+avx512f,+avx2,+fma'),
]
for name, features, flags in variants:
    env = dict(os.environ)
    for key in ('CARGO_ENCODED_RUSTFLAGS', 'RUSTC_WRAPPER', 'RUSTC_WORKSPACE_WRAPPER', 'CARGO_BUILD_TARGET'):
        env.pop(key, None)
    env.update(CARGO_TARGET_DIR=str(P/'matrix-build'), RUSTFLAGS=flags)
    wrapper = 'control-wrapper' if name == 'control' else 'matrix-wrapper'
    command = ['taskset', '-c', '0,1,3-13,15-23', 'cargo', 'build', '--locked', '--release',
               '--no-default-features', '--features', features]
    with (P/f'qualification-v4-build-{name}.log').open('w') as log:
        subprocess.run(command, cwd=P/wrapper, env=env, stdout=log, stderr=subprocess.STDOUT, check=True)
    target = P/'qualification-v4-bin'/f'{name}.so'
    shutil.copyfile(P/'matrix-build/release/libmatrix_bench_wrapper.so', target)
    records.append(dict(name=name, features=features, rustflags=flags, command=command,
                        sha256=hashlib.sha256(target.read_bytes()).hexdigest(),
                        wrapper_source_sha256=hashlib.sha256((P/wrapper/'src/lib.rs').read_bytes()).hexdigest()))
    (P/'qualification-v4-builds.json').write_text(json.dumps(records, indent=2)+'\n')
    print('Built', name, flush=True)
