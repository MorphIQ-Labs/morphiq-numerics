
target/benchmarks/pr240-parity-next-20261028/qualification-v4-bin/avx512.so:     file format elf64-x86-64


Disassembly of section .text:

00000000000274b0 <morphiq_numerics::exp::bounded::fixed::<morphiq_numerics_arch::x86_64::Avx2, 4>>:
   274b0:	48 89 f2             	mov    %rsi,%rdx
   274b3:	c5 fd 10 07          	vmovupd (%rdi),%ymm0
   274b7:	c4 e2 7d 19 0d e8 f0 	vbroadcastsd -0x20f18(%rip),%ymm1        # 65a8 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x348>
   274be:	fd ff 
   274c0:	c5 fd 54 c9          	vandpd %ymm1,%ymm0,%ymm1
   274c4:	c4 e2 7d 19 15 53 ef 	vbroadcastsd -0x210ad(%rip),%ymm2        # 6420 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x1c0>
   274cb:	fd ff 
   274cd:	c5 f5 c2 ca 11       	vcmplt_oqpd %ymm2,%ymm1,%ymm1
   274d2:	c5 ed 76 d2          	vpcmpeqd %ymm2,%ymm2,%ymm2
   274d6:	62 f2 f5 48 37 c2    	vpcmpgtq %zmm2,%zmm1,%k0
   274dc:	c5 f8 93 c0          	kmovw  %k0,%eax
   274e0:	a8 0f                	test   $0xf,%al
   274e2:	0f 85 e4 00 00 00    	jne    275cc <morphiq_numerics::exp::bounded::fixed::<morphiq_numerics_arch::x86_64::Avx2, 4>+0x11c>
   274e8:	c4 e2 7d 19 0d 6f f2 	vbroadcastsd -0x20d91(%rip),%ymm1        # 6760 <anon.02ffda8f51e6076a26652e0a4fd6fa8d.746.llvm.5406940975955002095+0x180>
   274ef:	fd ff 
   274f1:	c5 fd 59 c9          	vmulpd %ymm1,%ymm0,%ymm1
   274f5:	c4 e2 7d 19 15 b2 f1 	vbroadcastsd -0x20e4e(%rip),%ymm2        # 66b0 <anon.02ffda8f51e6076a26652e0a4fd6fa8d.746.llvm.5406940975955002095+0xd0>
   274fc:	fd ff 
   274fe:	c4 e2 7d 19 1d 39 ef 	vbroadcastsd -0x210c7(%rip),%ymm3        # 6440 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x1e0>
   27505:	fd ff 
   27507:	c5 f5 58 ca          	vaddpd %ymm2,%ymm1,%ymm1
   2750b:	c5 f5 54 d3          	vandpd %ymm3,%ymm1,%ymm2
   2750f:	c4 e1 f9 7e d0       	vmovq  %xmm2,%rax
   27514:	48 8b 0d f5 18 06 00 	mov    0x618f5(%rip),%rcx        # 88e10 <_DYNAMIC+0x4f0>
   2751b:	c4 e3 f9 16 d6 01    	vpextrq $0x1,%xmm2,%rsi
   27521:	c4 e3 7d 39 d2 01    	vextracti128 $0x1,%ymm2,%xmm2
   27527:	c4 e1 f9 7e d7       	vmovq  %xmm2,%rdi
   2752c:	c4 c3 f9 16 d0 01    	vpextrq $0x1,%xmm2,%r8
   27532:	c4 a1 7a 7e 14 c1    	vmovq  (%rcx,%r8,8),%xmm2
   27538:	c5 fa 7e 1c f9       	vmovq  (%rcx,%rdi,8),%xmm3
   2753d:	c5 e1 6c d2          	vpunpcklqdq %xmm2,%xmm3,%xmm2
   27541:	c5 fa 7e 1c f1       	vmovq  (%rcx,%rsi,8),%xmm3
   27546:	c5 fa 7e 24 c1       	vmovq  (%rcx,%rax,8),%xmm4
   2754b:	c5 d9 6c db          	vpunpcklqdq %xmm3,%xmm4,%xmm3
   2754f:	c4 e3 65 38 d2 01    	vinserti128 $0x1,%xmm2,%ymm3,%ymm2
   27555:	c4 e2 7d 19 1d 2a f1 	vbroadcastsd -0x20ed6(%rip),%ymm3        # 6688 <anon.02ffda8f51e6076a26652e0a4fd6fa8d.746.llvm.5406940975955002095+0xa8>
   2755c:	fd ff 
   2755e:	c5 f5 58 db          	vaddpd %ymm3,%ymm1,%ymm3
   27562:	c5 f5 73 f1 2a       	vpsllq $0x2a,%ymm1,%ymm1
   27567:	c5 ed d4 c9          	vpaddq %ymm1,%ymm2,%ymm1
   2756b:	c4 e2 7d 19 15 0c f0 	vbroadcastsd -0x20ff4(%rip),%ymm2        # 6580 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x320>
   27572:	fd ff 
   27574:	c5 e5 59 d2          	vmulpd %ymm2,%ymm3,%ymm2
   27578:	c5 fd 58 c2          	vaddpd %ymm2,%ymm0,%ymm0
   2757c:	c4 e2 7d 19 15 a3 ee 	vbroadcastsd -0x2115d(%rip),%ymm2        # 6428 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x1c8>
   27583:	fd ff 
   27585:	c5 e5 59 d2          	vmulpd %ymm2,%ymm3,%ymm2
   27589:	c5 ed 58 c0          	vaddpd %ymm0,%ymm2,%ymm0
   2758d:	c4 e2 7d 19 15 d2 ef 	vbroadcastsd -0x2102e(%rip),%ymm2        # 6568 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x308>
   27594:	fd ff 
   27596:	c5 fd 59 d8          	vmulpd %ymm0,%ymm0,%ymm3
   2759a:	c5 fd 59 d2          	vmulpd %ymm2,%ymm0,%ymm2
   2759e:	c4 e2 7d 19 25 c1 ee 	vbroadcastsd -0x2113f(%rip),%ymm4        # 6468 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x208>
   275a5:	fd ff 
   275a7:	c5 ed 58 d4          	vaddpd %ymm4,%ymm2,%ymm2
   275ab:	c5 e5 59 d2          	vmulpd %ymm2,%ymm3,%ymm2
   275af:	c4 e2 7d 19 1d f8 ef 	vbroadcastsd -0x21008(%rip),%ymm3        # 65b0 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x350>
   275b6:	fd ff 
   275b8:	c5 fd 58 c2          	vaddpd %ymm2,%ymm0,%ymm0
   275bc:	c5 fd 58 c3          	vaddpd %ymm3,%ymm0,%ymm0
   275c0:	c5 fd 59 c1          	vmulpd %ymm1,%ymm0,%ymm0
   275c4:	c5 fd 11 02          	vmovupd %ymm0,(%rdx)
   275c8:	c5 f8 77             	vzeroupper
   275cb:	c3                   	ret
   275cc:	be 04 00 00 00       	mov    $0x4,%esi
   275d1:	b9 04 00 00 00       	mov    $0x4,%ecx
   275d6:	c5 f8 77             	vzeroupper
   275d9:	ff 25 39 18 06 00    	jmp    *0x61839(%rip)        # 88e18 <_DYNAMIC+0x4f8>
