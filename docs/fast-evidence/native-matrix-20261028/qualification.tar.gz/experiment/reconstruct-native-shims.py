"""Recover a reproducible build receipt by comparing immutable shim binaries."""
from pathlib import Path
import hashlib
import json
import os
import subprocess

P=Path(__file__).resolve().parent
assert (P/'qualification-v8/result.json').exists(), 'No builds during timings'
os.sched_setaffinity(0,{0})
out=P/'shim-reconstruction'
out.mkdir(exist_ok=False)
external=P.parent/'pr240-external-20261028/bin'
records=[]
for name in ['native-matrix','native-cache']:
    command=['cc','-O3','-fPIC','-shared','-ffp-contract=off',str(P/(name+'.c')),
             '-o',str(out/(name+'.so'))]
    if name=='native-matrix':
        command += ['-L'+str(external),'-Wl,-rpath,'+str(external),'-lsleef','-lm']
    subprocess.run(command,check=True)
    original=(P/'bin'/(name+'.so')).read_bytes()
    reproduced=(out/(name+'.so')).read_bytes()
    records.append(dict(name=name,command=command,
        measured_sha256=hashlib.sha256(original).hexdigest(),
        reconstructed_sha256=hashlib.sha256(reproduced).hexdigest(),
        identical=original==reproduced))
(P/'native-shim-reconstruction.json').write_text(json.dumps(dict(
    compiler=subprocess.check_output(['cc','--version'],text=True),records=records),indent=2)+'\n')
print(json.dumps(records,indent=2))
