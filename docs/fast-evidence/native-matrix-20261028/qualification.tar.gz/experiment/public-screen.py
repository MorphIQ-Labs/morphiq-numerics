import pathlib,sys,ctypes as C,os,json,math
P=pathlib.Path(__file__).resolve().parent;sys.path.insert(0,str(P.parent/'pr240-external-20261028'))
import external as E
os.sched_setaffinity(0,{2});lib=C.CDLL(str(P/'wrapper-build/release/libproduction_bench_wrapper.so'))
entries=[]
for f,symbol in [('exp','exp'),('erfcx','erfcx'),('cdf','norm_cdf')]:
 for suffix,kind in [('', 'scalar'),('_slice','vector')]:
  name='prod_'+symbol+suffix;entries.append(dict(name=name,primitive=f,kind=kind,ptr=C.cast(getattr(lib,name),C.c_void_p).value))
entries += [r for r in E.REG if r['name'] in ('sleef_exp_scalar_fma','core_math_exp','sleef_exp_avx512','libcerf_erfcx','scipy_ndtr','sleef_cdf_avx512')]
counts={};rows=[]
for r in entries:
 x=E.PACKETS[r['primitive']];y=E.np.empty_like(x);m=E.NATIVE.measure_packet if r['kind']=='vector' else E.NATIVE.measure2 if r['kind']=='scalar_capsule' else E.NATIVE.measure1
 elapsed=m(r['ptr'],x.ctypes.data_as(E.D),y.ctypes.data_as(E.D),52,10000);counts[r['name']]=math.ceil(200000000/(elapsed/10000)/1000)*1000
for rep in range(2):
 for r in entries if rep==0 else entries[::-1]:
  x=E.PACKETS[r['primitive']];y=E.np.empty_like(x);m=E.NATIVE.measure_packet if r['kind']=='vector' else E.NATIVE.measure2 if r['kind']=='scalar_capsule' else E.NATIVE.measure1
  elapsed=m(r['ptr'],x.ctypes.data_as(E.D),y.ctypes.data_as(E.D),52,counts[r['name']]);rows.append(dict(name=r['name'],round=rep,count=counts[r['name']],elapsed_ns=elapsed,ns_per_52=elapsed/counts[r['name']]))
label=sys.argv[1];(P/(label+'.json')).write_text(json.dumps(dict(scope='Exploratory public-call screen; no qualification claim',rows=rows),indent=2)+'\n')
for r in entries:print(r['name'],sum(x['ns_per_52'] for x in rows if x['name']==r['name'])/2)
