from pathlib import Path
import subprocess,os,shutil,sys,hashlib,json
P=Path(__file__).resolve().parent;label=sys.argv[1]
env=dict(os.environ)
for k in ['CARGO_ENCODED_RUSTFLAGS','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER','CARGO_BUILD_TARGET']:env.pop(k,None)
env.update(CARGO_TARGET_DIR=str(P/'matrix-build'),RUSTFLAGS='')
with (P/f'candidates/{label}-build.log').open('w') as f:
 subprocess.run(['taskset','-c','0,1,3-13,15-23','cargo','build','--locked','--release','--no-default-features','--features','simd,std'],cwd=P/'matrix-wrapper',env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
path=P/f'candidates/{label}.so';shutil.copyfile(P/'matrix-build/release/libmatrix_bench_wrapper.so',path)
(P/f'candidates/{label}.patch').write_bytes(subprocess.check_output(['git','diff'],cwd=P/'source'))
(P/f'candidates/{label}.json').write_text(json.dumps(dict(sha256=hashlib.sha256(path.read_bytes()).hexdigest(),source_base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=P/'source',text=True).strip(),flags=''),indent=2)+'\n')
print(label,hashlib.sha256(path.read_bytes()).hexdigest(),flush=True)
