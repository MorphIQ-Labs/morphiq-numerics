
target/benchmarks/pr240-parity-next-20261028/qualification-v3-bin/avx512.so:     file format elf64-x86-64


Disassembly of section .text:

00000000000274b0 <morphiq_numerics::exp::bounded::fixed::<morphiq_numerics_arch::x86_64::Avx2, 4>>:
   274b0:	48 89 f2             	mov    %rsi,%rdx
   274b3:	c4 e2 7d 19 0d 64 ef 	vbroadcastsd -0x2109c(%rip),%ymm1        # 6420 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x1c0>
   274ba:	fd ff 
   274bc:	c5 f9 57 c0          	vxorpd %xmm0,%xmm0,%xmm0
   274c0:	c5 fd c2 d1 11       	vcmplt_oqpd %ymm1,%ymm0,%ymm2
   274c5:	c4 e2 7d 19 1d da f0 	vbroadcastsd -0x20f26(%rip),%ymm3        # 65a8 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x348>
   274cc:	fd ff 
   274ce:	c5 fd 10 07          	vmovupd (%rdi),%ymm0
   274d2:	c5 fd 54 db          	vandpd %ymm3,%ymm0,%ymm3
   274d6:	c5 e5 c2 c9 11       	vcmplt_oqpd %ymm1,%ymm3,%ymm1
   274db:	c5 f5 54 ca          	vandpd %ymm2,%ymm1,%ymm1
   274df:	c5 ed 76 d2          	vpcmpeqd %ymm2,%ymm2,%ymm2
   274e3:	62 f2 f5 48 37 c2    	vpcmpgtq %zmm2,%zmm1,%k0
   274e9:	c5 f8 93 c0          	kmovw  %k0,%eax
   274ed:	a8 0f                	test   $0xf,%al
   274ef:	0f 85 e4 00 00 00    	jne    275d9 <morphiq_numerics::exp::bounded::fixed::<morphiq_numerics_arch::x86_64::Avx2, 4>+0x129>
   274f5:	c4 e2 7d 19 0d 62 f2 	vbroadcastsd -0x20d9e(%rip),%ymm1        # 6760 <anon.02ffda8f51e6076a26652e0a4fd6fa8d.746.llvm.5406940975955002095+0x180>
   274fc:	fd ff 
   274fe:	c5 fd 59 c9          	vmulpd %ymm1,%ymm0,%ymm1
   27502:	c4 e2 7d 19 15 a5 f1 	vbroadcastsd -0x20e5b(%rip),%ymm2        # 66b0 <anon.02ffda8f51e6076a26652e0a4fd6fa8d.746.llvm.5406940975955002095+0xd0>
   27509:	fd ff 
   2750b:	c4 e2 7d 19 1d 2c ef 	vbroadcastsd -0x210d4(%rip),%ymm3        # 6440 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x1e0>
   27512:	fd ff 
   27514:	c5 f5 58 ca          	vaddpd %ymm2,%ymm1,%ymm1
   27518:	c5 f5 54 d3          	vandpd %ymm3,%ymm1,%ymm2
   2751c:	c4 e1 f9 7e d0       	vmovq  %xmm2,%rax
   27521:	48 8b 0d 78 19 06 00 	mov    0x61978(%rip),%rcx        # 88ea0 <_DYNAMIC+0x4f0>
   27528:	c4 e3 f9 16 d6 01    	vpextrq $0x1,%xmm2,%rsi
   2752e:	c4 e3 7d 39 d2 01    	vextracti128 $0x1,%ymm2,%xmm2
   27534:	c4 e1 f9 7e d7       	vmovq  %xmm2,%rdi
   27539:	c4 c3 f9 16 d0 01    	vpextrq $0x1,%xmm2,%r8
   2753f:	c4 a1 7a 7e 14 c1    	vmovq  (%rcx,%r8,8),%xmm2
   27545:	c5 fa 7e 1c f9       	vmovq  (%rcx,%rdi,8),%xmm3
   2754a:	c5 e1 6c d2          	vpunpcklqdq %xmm2,%xmm3,%xmm2
   2754e:	c5 fa 7e 1c f1       	vmovq  (%rcx,%rsi,8),%xmm3
   27553:	c5 fa 7e 24 c1       	vmovq  (%rcx,%rax,8),%xmm4
   27558:	c5 d9 6c db          	vpunpcklqdq %xmm3,%xmm4,%xmm3
   2755c:	c4 e3 65 38 d2 01    	vinserti128 $0x1,%xmm2,%ymm3,%ymm2
   27562:	c4 e2 7d 19 1d 1d f1 	vbroadcastsd -0x20ee3(%rip),%ymm3        # 6688 <anon.02ffda8f51e6076a26652e0a4fd6fa8d.746.llvm.5406940975955002095+0xa8>
   27569:	fd ff 
   2756b:	c5 f5 58 db          	vaddpd %ymm3,%ymm1,%ymm3
   2756f:	c5 f5 73 f1 2a       	vpsllq $0x2a,%ymm1,%ymm1
   27574:	c5 ed d4 c9          	vpaddq %ymm1,%ymm2,%ymm1
   27578:	c4 e2 7d 19 15 ff ef 	vbroadcastsd -0x21001(%rip),%ymm2        # 6580 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x320>
   2757f:	fd ff 
   27581:	c5 e5 59 d2          	vmulpd %ymm2,%ymm3,%ymm2
   27585:	c5 fd 58 c2          	vaddpd %ymm2,%ymm0,%ymm0
   27589:	c4 e2 7d 19 15 96 ee 	vbroadcastsd -0x2116a(%rip),%ymm2        # 6428 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x1c8>
   27590:	fd ff 
   27592:	c5 e5 59 d2          	vmulpd %ymm2,%ymm3,%ymm2
   27596:	c5 ed 58 c0          	vaddpd %ymm0,%ymm2,%ymm0
   2759a:	c4 e2 7d 19 15 c5 ef 	vbroadcastsd -0x2103b(%rip),%ymm2        # 6568 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x308>
   275a1:	fd ff 
   275a3:	c5 fd 59 d8          	vmulpd %ymm0,%ymm0,%ymm3
   275a7:	c5 fd 59 d2          	vmulpd %ymm2,%ymm0,%ymm2
   275ab:	c4 e2 7d 19 25 b4 ee 	vbroadcastsd -0x2114c(%rip),%ymm4        # 6468 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x208>
   275b2:	fd ff 
   275b4:	c5 ed 58 d4          	vaddpd %ymm4,%ymm2,%ymm2
   275b8:	c5 e5 59 d2          	vmulpd %ymm2,%ymm3,%ymm2
   275bc:	c4 e2 7d 19 1d eb ef 	vbroadcastsd -0x21015(%rip),%ymm3        # 65b0 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x350>
   275c3:	fd ff 
   275c5:	c5 fd 58 c2          	vaddpd %ymm2,%ymm0,%ymm0
   275c9:	c5 fd 58 c3          	vaddpd %ymm3,%ymm0,%ymm0
   275cd:	c5 fd 59 c1          	vmulpd %ymm1,%ymm0,%ymm0
   275d1:	c5 fd 11 02          	vmovupd %ymm0,(%rdx)
   275d5:	c5 f8 77             	vzeroupper
   275d8:	c3                   	ret
   275d9:	be 04 00 00 00       	mov    $0x4,%esi
   275de:	b9 04 00 00 00       	mov    $0x4,%ecx
   275e3:	c5 f8 77             	vzeroupper
   275e6:	ff 25 bc 18 06 00    	jmp    *0x618bc(%rip)        # 88ea8 <_DYNAMIC+0x4f8>
