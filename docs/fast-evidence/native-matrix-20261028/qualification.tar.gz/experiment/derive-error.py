# Independent exact-rational error analysis; not a repository generator or CI gate.
# The scalar recurrence is documented in derivation.txt. This does not replace
# the required machine-checked connection to IEEE operations and source bindings.
from fractions import Fraction as F
from pathlib import Path
import re,struct,json,math,os,sys
sys.set_int_max_str_digits(0)
os.sched_setaffinity(0,{0})
P=Path(__file__).resolve().parent;W=P/'source'
u=F(1,2**53);eta=F(1,2**1075)
def f(word):return F(struct.unpack('>d',bytes.fromhex(word))[0])
class B:
 def __init__(self,lo,hi=None,e=F(0)):self.lo=F(lo);self.hi=F(lo if hi is None else hi);self.e=e
 @property
 def mag(self):return max(abs(self.lo),abs(self.hi))
 def __add__(a,b):
  if not isinstance(b,B):b=B(b)
  lo=a.lo+b.lo;hi=a.hi+b.hi;inherited=a.e+b.e
  return B(lo,hi,inherited+u*(max(abs(lo),abs(hi))+inherited)+eta)
 def __mul__(a,b):
  if not isinstance(b,B):b=B(b)
  prod=[a.lo*b.lo,a.lo*b.hi,a.hi*b.lo,a.hi*b.hi];lo=min(prod);hi=max(prod)
  inherited=a.mag*b.e+b.mag*a.e+a.e*b.e
  return B(lo,hi,inherited+u*(max(abs(lo),abs(hi))+inherited)+eta)

def pair_poly(a,h):
 h2=h*h;ps=[B(a[i])+h*B(a[i+1]) for i in range(0,10,2)]
 y=ps[-1]
 for p in ps[-2::-1]:y=p+h2*y
 return y
source=(W/'crates/morphiq-numerics/src/erfcx/tables.rs').read_text();table=source.split('pub static T:',1)[1].split('= [',1)[1].split('\n];',1)[0]
words=re.findall(r'0x([0-9a-f]{16})',table);assert len(words)==177*13
rows=[];worst=F(0)
for i in range(177):
 raw=[f(w) for w in words[i*13:(i+1)*13]];a=[raw[j] for j in [0,2,4,6,7,8,9,10,11,12]]
 e=0 if i<49 else (i-49)//32;hm=F(2)**(e-6);h=B(-hm,hm);y=pair_poly(a,h)
 omitted=abs(raw[1])+hm*abs(raw[3])+hm*hm*abs(raw[5]);pmin=y.lo-omitted;assert pmin>0
 relative=(y.e+omitted)/pmin;total=relative*(1+F(1,2**69))+F(1,2**69)
 rows.append(dict(row=i,evaluation_relative=float(relative),total_relative=float(total),in_units_u=float(total/u),within_contract=total<=4*u))
 if total>worst:worst=total;witness=i
normal=(W/'crates/morphiq-numerics/src/normal_distribution/tables.rs').read_text();center=normal.split('const CENTER:',1)[1].split('];',1)[0]
w=re.findall(r'0x([0-9a-f]{16})',center);assert len(w)==26
coeff=[f(w[2*i]) for i in range(13)];x=B(-1,1);z=x*x;zz=z*z;ps=[B(coeff[j])+z*B(coeff[j+1]) for j in range(0,12,2)];y=B(coeff[12])
for a in ps[::-1]:y=a+zz*y
D=f('3fd9884533d43651');out=B(F(1,2))+(x*B(D))*y
coefficient=sum(abs(coeff[n]-F((-1)**n,2**n*math.factorial(n)*(2*n+1))) for n in range(13))
density_error=F(1,2**54)*sum(abs(F((-1)**n,2**n*math.factorial(n)*(2*n+1))) for n in range(13))
truncation=F(2,5)/F(2**13*math.factorial(13)*27)
total=out.e+D*coefficient+density_error+truncation
result=dict(scope='Exact-rational propagation of standard round-to-nearest error |RN(t)-t| <= 2^-53 |t| + 2^-1075. Existing reduction and analytic approximation theorems are assumptions of this calculation; this is not the completed Coq/source-bound proof.',erfcx=dict(rows=rows,worst_row=witness,max_bound=float(worst),in_units_u=float(worst/u),exact_bound=str(worst),all_within_contract=all(r['within_contract'] for r in rows)),central_cdf=dict(arithmetic_bound=float(out.e),coefficient_bound=float(D*coefficient),density_bound=float(density_error),truncation_bound=float(truncation),total_bound=float(total),in_units_u=float(total/u),within_contract=total<=16*u,exact_bound=str(total)))
(P/'derived-error.json').write_text(json.dumps(result,indent=2)+'\n');print('erfcx bound in u',float(worst/u),'row',witness,'pass',result['erfcx']['all_within_contract']);print('central cdf bound in u',float(total/u),'pass',total<=16*u)
assert result['erfcx']['all_within_contract'] and result['central_cdf']['within_contract']
