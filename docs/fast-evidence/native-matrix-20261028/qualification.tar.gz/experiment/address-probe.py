import pathlib,sys,ctypes as C,os,csv,json
P=pathlib.Path(__file__).resolve().parent;sys.path.insert(0,str(P.parent/'pr240-external-20261028'))
import external as E
os.sched_setaffinity(0,{2});lib=C.CDLL(str(P/'wrapper-build/release/libproduction_bench_wrapper.so'))
entries=[dict(name='prod_norm_cdf',primitive='cdf',kind='scalar',ptr=C.cast(lib.prod_norm_cdf,C.c_void_p).value),dict(name='prod_exp_slice',primitive='exp',kind='vector',ptr=C.cast(lib.prod_exp_slice,C.c_void_p).value),next(r for r in E.REG if r['name']=='scipy_ndtr')]
counts=json.loads((P/'paired/counts.json').read_text());buffers=[E.np.empty(16384,dtype=E.np.uint8) for _ in range(2)]
def array(which,offset):
 b=buffers[which];start=(-b.ctypes.data)%4096+offset;return b[start:start+416].view(E.np.float64)
variants=[(0,o) for o in range(0,512,8)]+[(i,0) for i in range(8,512,8)]
with (P/'address-probe.csv').open('w',buffering=1) as f:
 writer=csv.writer(f);writer.writerow(['round','name','input_offset','output_offset','input_address','output_address','count','elapsed_ns','ns_per_52'])
 for rep in range(2):
  for ix,iy in variants if rep==0 else variants[::-1]:
   for r in entries if rep==0 else entries[::-1]:
    x=array(0,ix);y=array(1,iy);x[:]=E.PACKETS[r['primitive']]
    count=max(1,counts[r['name']]*3//50)
    method=E.NATIVE.measure_packet if r['kind']=='vector' else E.NATIVE.measure2 if r['kind']=='scalar_capsule' else E.NATIVE.measure1
    elapsed=method(r['ptr'],x.ctypes.data_as(E.D),y.ctypes.data_as(E.D),52,count)
    writer.writerow([rep,r['name'],ix,iy,x.ctypes.data,y.ctypes.data,count,elapsed,elapsed/count])
