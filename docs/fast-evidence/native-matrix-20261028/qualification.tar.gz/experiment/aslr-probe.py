import pathlib,sys,ctypes as C,os,json,csv
P=pathlib.Path(__file__).resolve().parent;sys.path.insert(0,str(P.parent/'pr240-external-20261028'))
import external as E
os.sched_setaffinity(0,{2});lib=C.CDLL(str(P/'wrapper-build/release/libproduction_bench_wrapper.so'))
entries=[dict(name='prod_norm_cdf',primitive='cdf',kind='scalar',ptr=C.cast(lib.prod_norm_cdf,C.c_void_p).value),dict(name='prod_erfcx',primitive='erfcx',kind='scalar',ptr=C.cast(lib.prod_erfcx,C.c_void_p).value),next(r for r in E.REG if r['name']=='scipy_ndtr')]
counts=json.loads((P/'paired/counts.json').read_text());buffers=[E.np.empty(8192,dtype=E.np.uint8) for _ in range(2)];arrays=[]
for b in buffers:
 start=(-b.ctypes.data)%4096;arrays.append(b[start:start+416].view(E.np.float64))
x,y=arrays;rows=[]
for rep in range(2):
 for r in entries if rep==0 else entries[::-1]:
  x[:]=E.PACKETS[r['primitive']];count=counts[r['name']];m=E.NATIVE.measure2 if r['kind']=='scalar_capsule' else E.NATIVE.measure1
  warm=m(r['ptr'],x.ctypes.data_as(E.D),y.ctypes.data_as(E.D),52,count//2)
  elapsed=m(r['ptr'],x.ctypes.data_as(E.D),y.ctypes.data_as(E.D),52,count)
  rows.append(dict(name=r['name'],round=rep,count=count,elapsed_ns=elapsed,ns_per_52=elapsed/count,warmup_ns=warm,function_address=r['ptr'],input_address=x.ctypes.data,output_address=y.ctypes.data))
(P/'aslr-probe'/f'{sys.argv[1]}.json').write_text(json.dumps(rows,indent=2)+'\n')
