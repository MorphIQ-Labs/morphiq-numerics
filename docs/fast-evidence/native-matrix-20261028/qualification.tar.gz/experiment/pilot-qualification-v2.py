from pathlib import Path
import csv,json,math,os,statistics,subprocess,sys
P=Path(__file__).resolve().parent;os.sched_setaffinity(0,{0});root=P/'qualification-v2-pilot';root.mkdir(exist_ok=False)
manifest=json.loads((P/'qualification-manifest.json').read_text())
ids=['avx512-exp-vector-sleef_exp_avx2-wide-5','avx512-exp-vector-sleef_exp_avx2-ordinary-5','auto-exp-vector-sleef_exp_avx512-ordinary-8','avx512-cdf-vector-sleef_cdf_avx512-wide-16']
rows=[]
for key in ids:
 c=next(c for c in manifest['cells'] if c['id']==key);out=root/key;out.mkdir();logs=[]
 args=[sys.executable,str(P/'qualify-cell.py'),'--product',c['product'],'--primitive',c['primitive'],'--length',str(c['length']),'--population',c['input']['file'],'--kind',c['kind'],'--reference',c['reference'],'--counts',str(out/'counts.json'),'--target-ms','350']
 for proc in ['calibration']+[str(i) for i in range(10)]:
  with (out/(proc+'.log')).open('w') as stream:r=subprocess.run(args+['--process',proc,'--out',str(out/proc)],stdout=stream,stderr=subprocess.STDOUT)
  if r.returncode:raise SystemExit(f'Invalid pilot {key}/{proc}; retained without retry')
  if proc=='calibration':continue
  samples=[json.loads(l) for l in (out/proc/'samples.jsonl').read_text().splitlines() if json.loads(l)['kind']=='timed'];ratios=[]
  for round in range(2):
   a=next(x['ns_per_call'] for x in samples if x['name']=='ours' and x['round']==round);b=next(x['ns_per_call'] for x in samples if x['name']=='reference' and x['round']==round);ratios.append(math.log(a/b))
  logs.append(statistics.median(ratios))
 ratio=math.exp(statistics.mean(logs));upper=math.exp(statistics.mean(logs)+1.8331129326536335*statistics.stdev(logs)/math.sqrt(10));row=dict(id=key,ratio=ratio,upper95=upper,logs=logs);rows.append(row);print(json.dumps(row),flush=True);(root/'summary.json').write_text(json.dumps(rows,indent=2)+'\n')
