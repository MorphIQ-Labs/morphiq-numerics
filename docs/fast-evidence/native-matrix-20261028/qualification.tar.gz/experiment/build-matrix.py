from pathlib import Path
import subprocess,os,shutil,json,hashlib
P=Path(__file__).resolve().parent;out=[]
for name,flags in [('sse2','-C target-feature=-avx,-avx2,-avx512f,-fma'),('avx2','-C target-feature=+avx2,+fma,-avx512f'),('avx512','-C target-feature=+avx512f,+avx2,+fma')]:
 env=dict(os.environ,CARGO_TARGET_DIR=str(P/'matrix-build'),RUSTFLAGS=flags)
 with (P/f'matrix-build-{name}.log').open('w') as f:
  subprocess.run(['taskset','-c','0,1,3-13,15-23','cargo','build','--release','--no-default-features','--features','simd'],cwd=P/'matrix-wrapper',env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
 target=P/'bin'/f'{name}.so';shutil.copyfile(P/'matrix-build/release/libmatrix_bench_wrapper.so',target)
 out.append(dict(name=name,features='simd without std',rustflags=flags,sha256=hashlib.sha256(target.read_bytes()).hexdigest()))
 print('Built',name,flush=True)
(P/'matrix-builds.json').write_text(json.dumps(out,indent=2)+'\n')
