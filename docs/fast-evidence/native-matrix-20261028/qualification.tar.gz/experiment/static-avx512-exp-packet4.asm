
target/benchmarks/pr240-parity-next-20261028/qualification-bin/avx512.so:     file format elf64-x86-64


Disassembly of section .text:

0000000000029e50 <morphiq_numerics::exp::bounded::packet::<morphiq_numerics_arch::x86_64::Avx2, 4>>:
   29e50:	55                   	push   %rbp
   29e51:	41 57                	push   %r15
   29e53:	41 56                	push   %r14
   29e55:	41 55                	push   %r13
   29e57:	41 54                	push   %r12
   29e59:	53                   	push   %rbx
   29e5a:	50                   	push   %rax
   29e5b:	48 8b 47 08          	mov    0x8(%rdi),%rax
   29e5f:	48 83 f8 03          	cmp    $0x3,%rax
   29e63:	0f 86 53 02 00 00    	jbe    2a0bc <morphiq_numerics::exp::bounded::packet::<morphiq_numerics_arch::x86_64::Avx2, 4>+0x26c>
   29e69:	48 8b 4f 18          	mov    0x18(%rdi),%rcx
   29e6d:	48 83 f9 03          	cmp    $0x3,%rcx
   29e71:	0f 86 5e 02 00 00    	jbe    2a0d5 <morphiq_numerics::exp::bounded::packet::<morphiq_numerics_arch::x86_64::Avx2, 4>+0x285>
   29e77:	4c 8b 37             	mov    (%rdi),%r14
   29e7a:	48 8b 5f 10          	mov    0x10(%rdi),%rbx
   29e7e:	48 83 c1 fc          	add    $0xfffffffffffffffc,%rcx
   29e82:	49 bf fc ff ff ff ff 	movabs $0x1ffffffffffffffc,%r15
   29e89:	ff ff 1f 
   29e8c:	4c 01 f8             	add    %r15,%rax
   29e8f:	49 83 cf 03          	or     $0x3,%r15
   29e93:	49 21 c7             	and    %rax,%r15
   29e96:	4c 39 f9             	cmp    %r15,%rcx
   29e99:	4c 0f 42 f9          	cmovb  %rcx,%r15
   29e9d:	4d 85 ff             	test   %r15,%r15
   29ea0:	0f 84 e2 00 00 00    	je     29f88 <morphiq_numerics::exp::bounded::packet::<morphiq_numerics_arch::x86_64::Avx2, 4>+0x138>
   29ea6:	45 31 e4             	xor    %r12d,%r12d
   29ea9:	c5 fb 12 25 77 c6 fd 	vmovddup -0x23989(%rip),%xmm4        # 6528 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x348>
   29eb0:	ff 
   29eb1:	c5 fb 10 2d e7 c4 fd 	vmovsd -0x23b19(%rip),%xmm5        # 63a0 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x1c0>
   29eb8:	ff 
   29eb9:	4c 8d 2d 08 da fd ff 	lea    -0x225f8(%rip),%r13        # 78c8 <anon.ee651107ab5319c6bc273e1a29320aaf.386.llvm.14746981713632465754+0x1d4>
   29ec0:	48 8b 2d 61 1d 06 00 	mov    0x61d61(%rip),%rbp        # 8bc28 <_DYNAMIC+0x4f8>
   29ec7:	e9 86 00 00 00       	jmp    29f52 <morphiq_numerics::exp::bounded::packet::<morphiq_numerics_arch::x86_64::Avx2, 4>+0x102>
   29ecc:	0f 1f 40 00          	nopl   0x0(%rax)
   29ed0:	c5 fb 59 0d 08 c8 fd 	vmulsd -0x237f8(%rip),%xmm0,%xmm1        # 66e0 <anon.02ffda8f51e6076a26652e0a4fd6fa8d.746.llvm.5406940975955002095+0x180>
   29ed7:	ff 
   29ed8:	c5 f3 58 0d 50 c7 fd 	vaddsd -0x238b0(%rip),%xmm1,%xmm1        # 6630 <anon.02ffda8f51e6076a26652e0a4fd6fa8d.746.llvm.5406940975955002095+0xd0>
   29edf:	ff 
   29ee0:	c4 e1 f9 7e c8       	vmovq  %xmm1,%rax
   29ee5:	89 c1                	mov    %eax,%ecx
   29ee7:	81 e1 ff 03 00 00    	and    $0x3ff,%ecx
   29eed:	c5 f3 58 0d 13 c7 fd 	vaddsd -0x238ed(%rip),%xmm1,%xmm1        # 6608 <anon.02ffda8f51e6076a26652e0a4fd6fa8d.746.llvm.5406940975955002095+0xa8>
   29ef4:	ff 
   29ef5:	48 c1 e0 2a          	shl    $0x2a,%rax
   29ef9:	49 03 44 cd 00       	add    0x0(%r13,%rcx,8),%rax
   29efe:	c4 e1 f9 6e d0       	vmovq  %rax,%xmm2
   29f03:	c5 f3 59 1d f5 c5 fd 	vmulsd -0x23a0b(%rip),%xmm1,%xmm3        # 6500 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x320>
   29f0a:	ff 
   29f0b:	c5 fb 58 c3          	vaddsd %xmm3,%xmm0,%xmm0
   29f0f:	c5 f3 59 0d 91 c4 fd 	vmulsd -0x23b6f(%rip),%xmm1,%xmm1        # 63a8 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x1c8>
   29f16:	ff 
   29f17:	c5 f3 58 c0          	vaddsd %xmm0,%xmm1,%xmm0
   29f1b:	c5 fb 59 c8          	vmulsd %xmm0,%xmm0,%xmm1
   29f1f:	c5 fb 59 1d c1 c5 fd 	vmulsd -0x23a3f(%rip),%xmm0,%xmm3        # 64e8 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x308>
   29f26:	ff 
   29f27:	c5 e3 58 1d b9 c4 fd 	vaddsd -0x23b47(%rip),%xmm3,%xmm3        # 63e8 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x208>
   29f2e:	ff 
   29f2f:	c5 f3 59 cb          	vmulsd %xmm3,%xmm1,%xmm1
   29f33:	c5 fb 58 c1          	vaddsd %xmm1,%xmm0,%xmm0
   29f37:	c5 fb 58 05 f1 c5 fd 	vaddsd -0x23a0f(%rip),%xmm0,%xmm0        # 6530 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x350>
   29f3e:	ff 
   29f3f:	c5 fb 59 c2          	vmulsd %xmm2,%xmm0,%xmm0
   29f43:	c4 a1 7b 11 44 e3 20 	vmovsd %xmm0,0x20(%rbx,%r12,8)
   29f4a:	49 ff c4             	inc    %r12
   29f4d:	4d 39 e7             	cmp    %r12,%r15
   29f50:	74 36                	je     29f88 <morphiq_numerics::exp::bounded::packet::<morphiq_numerics_arch::x86_64::Avx2, 4>+0x138>
   29f52:	c4 81 7b 10 44 e6 20 	vmovsd 0x20(%r14,%r12,8),%xmm0
   29f59:	c5 f9 54 cc          	vandpd %xmm4,%xmm0,%xmm1
   29f5d:	c5 f9 2e e9          	vucomisd %xmm1,%xmm5
   29f61:	0f 87 69 ff ff ff    	ja     29ed0 <morphiq_numerics::exp::bounded::packet::<morphiq_numerics_arch::x86_64::Avx2, 4>+0x80>
   29f67:	ff d5                	call   *%rbp
   29f69:	c5 fb 10 2d 2f c4 fd 	vmovsd -0x23bd1(%rip),%xmm5        # 63a0 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x1c0>
   29f70:	ff 
   29f71:	c5 fb 12 25 af c5 fd 	vmovddup -0x23a51(%rip),%xmm4        # 6528 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x348>
   29f78:	ff 
   29f79:	c4 a1 7b 11 44 e3 20 	vmovsd %xmm0,0x20(%rbx,%r12,8)
   29f80:	49 ff c4             	inc    %r12
   29f83:	4d 39 e7             	cmp    %r12,%r15
   29f86:	75 ca                	jne    29f52 <morphiq_numerics::exp::bounded::packet::<morphiq_numerics_arch::x86_64::Avx2, 4>+0x102>
   29f88:	c4 e2 7d 19 0d 0f c4 	vbroadcastsd -0x23bf1(%rip),%ymm1        # 63a0 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x1c0>
   29f8f:	fd ff 
   29f91:	c5 f9 57 c0          	vxorpd %xmm0,%xmm0,%xmm0
   29f95:	c5 fd c2 d1 11       	vcmplt_oqpd %ymm1,%ymm0,%ymm2
   29f9a:	c4 e2 7d 19 1d 85 c5 	vbroadcastsd -0x23a7b(%rip),%ymm3        # 6528 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x348>
   29fa1:	fd ff 
   29fa3:	c4 c1 7d 10 06       	vmovupd (%r14),%ymm0
   29fa8:	c5 fd 54 db          	vandpd %ymm3,%ymm0,%ymm3
   29fac:	c5 e5 c2 c9 11       	vcmplt_oqpd %ymm1,%ymm3,%ymm1
   29fb1:	c5 f5 54 ca          	vandpd %ymm2,%ymm1,%ymm1
   29fb5:	c5 ed 76 d2          	vpcmpeqd %ymm2,%ymm2,%ymm2
   29fb9:	62 f2 f5 48 37 c2    	vpcmpgtq %zmm2,%zmm1,%k0
   29fbf:	c5 f8 93 c0          	kmovw  %k0,%eax
   29fc3:	a8 0f                	test   $0xf,%al
   29fc5:	0f 85 23 01 00 00    	jne    2a0ee <morphiq_numerics::exp::bounded::packet::<morphiq_numerics_arch::x86_64::Avx2, 4>+0x29e>
   29fcb:	c4 e2 7d 19 0d 0c c7 	vbroadcastsd -0x238f4(%rip),%ymm1        # 66e0 <anon.02ffda8f51e6076a26652e0a4fd6fa8d.746.llvm.5406940975955002095+0x180>
   29fd2:	fd ff 
   29fd4:	c5 fd 59 c9          	vmulpd %ymm1,%ymm0,%ymm1
   29fd8:	c4 e2 7d 19 15 4f c6 	vbroadcastsd -0x239b1(%rip),%ymm2        # 6630 <anon.02ffda8f51e6076a26652e0a4fd6fa8d.746.llvm.5406940975955002095+0xd0>
   29fdf:	fd ff 
   29fe1:	c4 e2 7d 19 1d d6 c3 	vbroadcastsd -0x23c2a(%rip),%ymm3        # 63c0 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x1e0>
   29fe8:	fd ff 
   29fea:	c5 f5 58 ca          	vaddpd %ymm2,%ymm1,%ymm1
   29fee:	c5 f5 54 d3          	vandpd %ymm3,%ymm1,%ymm2
   29ff2:	c4 e1 f9 7e d0       	vmovq  %xmm2,%rax
   29ff7:	48 8d 0d ca d8 fd ff 	lea    -0x22736(%rip),%rcx        # 78c8 <anon.ee651107ab5319c6bc273e1a29320aaf.386.llvm.14746981713632465754+0x1d4>
   29ffe:	c4 e3 f9 16 d2 01    	vpextrq $0x1,%xmm2,%rdx
   2a004:	c4 e3 7d 39 d2 01    	vextracti128 $0x1,%ymm2,%xmm2
   2a00a:	c4 e1 f9 7e d6       	vmovq  %xmm2,%rsi
   2a00f:	c4 e3 f9 16 d7 01    	vpextrq $0x1,%xmm2,%rdi
   2a015:	c5 fa 7e 14 f9       	vmovq  (%rcx,%rdi,8),%xmm2
   2a01a:	c5 fa 7e 1c f1       	vmovq  (%rcx,%rsi,8),%xmm3
   2a01f:	c5 e1 6c d2          	vpunpcklqdq %xmm2,%xmm3,%xmm2
   2a023:	c5 fa 7e 1c d1       	vmovq  (%rcx,%rdx,8),%xmm3
   2a028:	c5 fa 7e 24 c1       	vmovq  (%rcx,%rax,8),%xmm4
   2a02d:	c5 d9 6c db          	vpunpcklqdq %xmm3,%xmm4,%xmm3
   2a031:	c4 e3 65 38 d2 01    	vinserti128 $0x1,%xmm2,%ymm3,%ymm2
   2a037:	c4 e2 7d 19 1d c8 c5 	vbroadcastsd -0x23a38(%rip),%ymm3        # 6608 <anon.02ffda8f51e6076a26652e0a4fd6fa8d.746.llvm.5406940975955002095+0xa8>
   2a03e:	fd ff 
   2a040:	c5 f5 58 db          	vaddpd %ymm3,%ymm1,%ymm3
   2a044:	c5 f5 73 f1 2a       	vpsllq $0x2a,%ymm1,%ymm1
   2a049:	c5 ed d4 c9          	vpaddq %ymm1,%ymm2,%ymm1
   2a04d:	c4 e2 7d 19 15 aa c4 	vbroadcastsd -0x23b56(%rip),%ymm2        # 6500 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x320>
   2a054:	fd ff 
   2a056:	c5 e5 59 d2          	vmulpd %ymm2,%ymm3,%ymm2
   2a05a:	c5 fd 58 c2          	vaddpd %ymm2,%ymm0,%ymm0
   2a05e:	c4 e2 7d 19 15 41 c3 	vbroadcastsd -0x23cbf(%rip),%ymm2        # 63a8 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x1c8>
   2a065:	fd ff 
   2a067:	c5 e5 59 d2          	vmulpd %ymm2,%ymm3,%ymm2
   2a06b:	c5 ed 58 c0          	vaddpd %ymm0,%ymm2,%ymm0
   2a06f:	c4 e2 7d 19 15 70 c4 	vbroadcastsd -0x23b90(%rip),%ymm2        # 64e8 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x308>
   2a076:	fd ff 
   2a078:	c5 fd 59 d8          	vmulpd %ymm0,%ymm0,%ymm3
   2a07c:	c5 fd 59 d2          	vmulpd %ymm2,%ymm0,%ymm2
   2a080:	c4 e2 7d 19 25 5f c3 	vbroadcastsd -0x23ca1(%rip),%ymm4        # 63e8 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x208>
   2a087:	fd ff 
   2a089:	c5 ed 58 d4          	vaddpd %ymm4,%ymm2,%ymm2
   2a08d:	c5 e5 59 d2          	vmulpd %ymm2,%ymm3,%ymm2
   2a091:	c4 e2 7d 19 1d 96 c4 	vbroadcastsd -0x23b6a(%rip),%ymm3        # 6530 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x350>
   2a098:	fd ff 
   2a09a:	c5 fd 58 c2          	vaddpd %ymm2,%ymm0,%ymm0
   2a09e:	c5 fd 58 c3          	vaddpd %ymm3,%ymm0,%ymm0
   2a0a2:	c5 fd 59 c1          	vmulpd %ymm1,%ymm0,%ymm0
   2a0a6:	c5 fd 11 03          	vmovupd %ymm0,(%rbx)
   2a0aa:	48 83 c4 08          	add    $0x8,%rsp
   2a0ae:	5b                   	pop    %rbx
   2a0af:	41 5c                	pop    %r12
   2a0b1:	41 5d                	pop    %r13
   2a0b3:	41 5e                	pop    %r14
   2a0b5:	41 5f                	pop    %r15
   2a0b7:	5d                   	pop    %rbp
   2a0b8:	c5 f8 77             	vzeroupper
   2a0bb:	c3                   	ret
   2a0bc:	48 8d 3d 11 f8 fd ff 	lea    -0x207ef(%rip),%rdi        # 98d4 <anon.ee651107ab5319c6bc273e1a29320aaf.386.llvm.14746981713632465754+0x21e0>
   2a0c3:	48 8d 15 be 00 06 00 	lea    0x600be(%rip),%rdx        # 8a188 <anon.02ffda8f51e6076a26652e0a4fd6fa8d.1766.llvm.5406940975955002095+0xa8>
   2a0ca:	be 13 00 00 00       	mov    $0x13,%esi
   2a0cf:	ff 15 f3 18 06 00    	call   *0x618f3(%rip)        # 8b9c8 <_DYNAMIC+0x298>
   2a0d5:	48 8d 3d f8 f7 fd ff 	lea    -0x20808(%rip),%rdi        # 98d4 <anon.ee651107ab5319c6bc273e1a29320aaf.386.llvm.14746981713632465754+0x21e0>
   2a0dc:	48 8d 15 bd 00 06 00 	lea    0x600bd(%rip),%rdx        # 8a1a0 <anon.02ffda8f51e6076a26652e0a4fd6fa8d.1766.llvm.5406940975955002095+0xc0>
   2a0e3:	be 13 00 00 00       	mov    $0x13,%esi
   2a0e8:	ff 15 da 18 06 00    	call   *0x618da(%rip)        # 8b9c8 <_DYNAMIC+0x298>
   2a0ee:	be 04 00 00 00       	mov    $0x4,%esi
   2a0f3:	b9 04 00 00 00       	mov    $0x4,%ecx
   2a0f8:	4c 89 f7             	mov    %r14,%rdi
   2a0fb:	48 89 da             	mov    %rbx,%rdx
   2a0fe:	48 83 c4 08          	add    $0x8,%rsp
   2a102:	5b                   	pop    %rbx
   2a103:	41 5c                	pop    %r12
   2a105:	41 5d                	pop    %r13
   2a107:	41 5e                	pop    %r14
   2a109:	41 5f                	pop    %r15
   2a10b:	5d                   	pop    %rbp
   2a10c:	c5 f8 77             	vzeroupper
   2a10f:	ff 25 0b 1b 06 00    	jmp    *0x61b0b(%rip)        # 8bc20 <_DYNAMIC+0x4f0>
