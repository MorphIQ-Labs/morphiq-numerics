import pathlib,sys,ctypes as C,os,csv,json,math
P=pathlib.Path(__file__).resolve().parent;sys.path.insert(0,str(P.parent/'pr240-external-20261028'))
import external as E
os.sched_setaffinity(0,{2})
lib=C.CDLL(str(P/'build/release/libparity_experiment.so'))
entries=[]
for name,f,kind in [('quartic_exp','exp','scalar'),('compact_exp_slice','exp','vector'),('quartic_cdf','cdf','scalar'),('high_exp','exp','scalar'),('masked_exp_slice','exp','vector'),('paired_cdf','cdf','scalar'),('high_exp_slice','exp','vector'),('gather_exp_slice','exp','vector'),('original_exp_slice','exp','vector'),('original_cdf','cdf','scalar'),('split_cdf','cdf','scalar'),('high_cdf','cdf','scalar'),('central_cdf','cdf','scalar')]:entries.append(dict(name=name,primitive=f,kind=kind,ptr=C.cast(getattr(lib,name),C.c_void_p).value))
entries += [r for r in E.REG if r['name'] in ('sleef_exp_avx512','scipy_ndtr')]
label=sys.argv[1];counts={};rows=[]
for r in entries:
 x=E.PACKETS[r['primitive']];y=E.np.empty_like(x)
 method=E.NATIVE.measure_packet if r['kind']=='vector' else E.NATIVE.measure2 if r['kind']=='scalar_capsule' else E.NATIVE.measure1
 elapsed=method(r['ptr'],x.ctypes.data_as(E.D),y.ctypes.data_as(E.D),52,10000);counts[r['name']]=math.ceil(200000000/(elapsed/10000)/1000)*1000
for repeat in range(2):
 for r in entries if repeat==0 else entries[::-1]:
  x=E.PACKETS[r['primitive']];y=E.np.empty_like(x)
  method=E.NATIVE.measure_packet if r['kind']=='vector' else E.NATIVE.measure2 if r['kind']=='scalar_capsule' else E.NATIVE.measure1
  elapsed=method(r['ptr'],x.ctypes.data_as(E.D),y.ctypes.data_as(E.D),52,counts[r['name']]);rows.append(dict(name=r['name'],round=repeat,count=counts[r['name']],elapsed_ns=elapsed,ns_per_52=elapsed/counts[r['name']]))
(P/(label+'.json')).write_text(json.dumps(dict(scope='Exploratory candidate screen, no qualification claim, 200ms target',rows=rows),indent=2)+'\n')
for r in entries:print(r['name'],sum(x['ns_per_52'] for x in rows if x['name']==r['name'])/2)
