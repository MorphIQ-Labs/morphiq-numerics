import pathlib,sys,ctypes as C,os,json,struct,csv,math,random
P=pathlib.Path(__file__).resolve().parent;sys.path.insert(0,str(P.parent/'pr240-external-20261028'))
import external as E
import mpmath as mp
os.sched_setaffinity(0,{0});mp.mp.prec=256
out=P/'matrix-observations';out.mkdir(exist_ok=False)
lib=C.CDLL(str(P/'final-bin/auto.so'));rng=random.Random(194240)
def bits(x):return struct.pack('>d',float(x)).hex()
def val(w):return struct.unpack('>d',bytes.fromhex(w))[0]
fixture=json.loads((E.BASE/'observations/fast-reference-expected.json').read_text());results=[]
for f,name in [('exp','prod_exp'),('erfcx','prod_erfcx'),('cdf','prod_norm_cdf')]:
 words={key.split()[1] for key in fixture if key.startswith(f+' ')}
 lo,hi=(-704,704) if f=='exp' else (-.5,16) if f=='erfcx' else (-8,8)
 words.update(bits(lo+(hi-lo)*i/8192) for i in range(8193));words.update(bits(x) for x in E.PACKETS[f])
 if f=='cdf':
  for x in [-1,1,-8,8]:words.update(bits(y) for y in [x,math.nextafter(x,-math.inf),math.nextafter(x,math.inf)])
 if f=='exp':
  words.update(bits(rng.uniform(-704,704)) for _ in range(8192))
  for n in range(-520000,520001,127):
   x=float(mp.mpf(n)*mp.log(2)/512)
   words.update(bits(y) for y in [x,math.nextafter(x,-math.inf),math.nextafter(x,math.inf)])
 xs=sorted([val(w) for w in words if math.isfinite(val(w)) and (abs(val(w))<704 if f=='exp' else -.5<=val(w)<16 and abs(val(w))>=2**-33 if f=='erfcx' else 2**-33<=abs(val(w))<=8)])
 fn=getattr(lib,name);fn.argtypes=[C.c_double];fn.restype=C.c_double
 worst=mp.mpf(0);fail=[];witness=None;budget=mp.mpf(2)**(-49 if f=='cdf' else -51)
 with (out/(name+'-observations.csv')).open('w') as stream:
  w=csv.writer(stream);w.writerow(['input_bits','output_bits','reference_256bit','error'])
  for x in xs:
   a=mp.mpf(x);ref=mp.exp(a) if f=='exp' else mp.exp(a*a)*mp.erfc(a) if f=='erfcx' else mp.erfc(-a/mp.sqrt(2))/2
   y=fn(x);error=abs(mp.mpf(y)-ref)/(1 if f=='cdf' else abs(ref))
   w.writerow([bits(x),bits(y),mp.nstr(ref,85),mp.nstr(error,30)])
   if error>worst:worst=error;witness=dict(input=bits(x),output=bits(y),reference=mp.nstr(ref,85))
   if error>budget:fail.append(bits(x))
 results.append(dict(name=name,cases=len(xs),max_error=float(worst),budget=float(budget),metric='absolute' if f=='cdf' else 'relative',failures=fail,witness=witness))
(out/'accuracy-summary.json').write_text(json.dumps(dict(scope='Independent finite observations, not whole-domain proof',cells=results),indent=2)+'\n')
# Public scalar/slice identity on all three functions, mixed inputs and remainders.
identities=[]
for backend in ['auto','sse2','avx2','avx512']:
 backend_lib=C.CDLL(str(P/'final-bin'/f'{backend}.so'))
 for f,name in [('exp','exp'),('erfcx','erfcx'),('cdf','norm_cdf')]:
  fn=C.CFUNCTYPE(None,E.D,E.D,C.c_size_t)(C.cast(getattr(backend_lib,'prod_'+name+'_slice'),C.c_void_p).value)
  scalar=getattr(lib,'prod_'+name);scalar.argtypes=[C.c_double];scalar.restype=C.c_double
  words=[key.split()[1] for key in fixture if key.startswith(f+' ')]
  lo,hi=(-704,704) if f=='exp' else (-.5,16) if f=='erfcx' else (-8,8)
  xs=[val(w) for w in words]+[lo+(hi-lo)*i/65536 for i in range(65537)]
  xs += [float('inf'),-float('inf'),val('7ff8123456789abc'),val('fff8123456789abc'),0.,-0.]
  for boundary in [-704,-8,-1,-.5,-2**-33,2**-33,1,8,16,704]:
   xs += [math.nextafter(boundary,-math.inf),boundary,math.nextafter(boundary,math.inf)]
  rng.shuffle(xs);fail=[];checked=0
  for x in [E.np.array(xs)]+[E.np.array(xs[:n]) for n in range(66)]+[E.np.array(xs[-53:])]:
   y=E.np.empty_like(x);fn(x.ctypes.data_as(E.D),y.ctypes.data_as(E.D),len(x))
   for a,b in zip(x,y):
    c=scalar(a)
    if bits(b)!=bits(c):fail.append(dict(input=bits(a),scalar=bits(c),vector=bits(b)))
   checked+=len(x)
  identities.append(dict(backend=backend,primitive=f,cases=checked,mismatches=fail))
(out/'identity-summary.json').write_text(json.dumps(identities,indent=2)+'\n')
print(json.dumps(results,indent=2));print(json.dumps(identities,indent=2))
assert not any(r['mismatches'] for r in identities) and not any(r['failures'] for r in results)
