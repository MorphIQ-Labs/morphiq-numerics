"""Audit completed raw evidence; never run this while timings are active."""
from pathlib import Path
import hashlib
import json
import math
import os
import statistics

P = Path(__file__).resolve().parent
os.sched_setaffinity(0, {0})
root = P / 'qualification-final'
assert (root / 'result.json').exists(), 'Campaign must finish before audit'
manifest_bytes = (P / 'qualification-v8-manifest.json').read_bytes()
assert hashlib.sha256(manifest_bytes).hexdigest() == (root / 'manifest.sha256').read_text().strip()
manifest = json.loads(manifest_bytes)
rows = {r['id']: r for r in json.loads((root / 'summary.json').read_text())}
assert len(rows) == len(manifest['cells']) == 500
builds = {b['name']: b['sha256'] for b in manifest['builds']}
durations = []
sibling_activity = []
controls = []
nonparity = []
required = []


def ticks(text, cpu):
    line = next(l for l in text.splitlines() if l.startswith(cpu + ' '))
    return [int(x) for x in line.split()[1:9]]


for cell in manifest['cells']:
    folder = P / ('qualification-v8' if cell['backend']=='avx512' else 'qualification') / cell['id']
    frozen_counts = json.loads((folder / 'counts.json').read_text())
    logs = []
    for process in range(10):
        assert (folder / f'{process}.complete').exists()
        meta = json.loads((folder / str(process) / 'metadata.json').read_text())
        assert meta['counts'] == frozen_counts
        assert meta['product_sha256'] == builds[cell['backend']]
        assert meta['input_sha256'] == cell['input']['sha256']
        assert meta['before']['affinity'] == meta['after']['affinity'] == [2]
        a, b = (ticks(meta[x]['cpu_stat'], 'cpu14') for x in ['before', 'after'])
        delta = [v-u for u, v in zip(a, b)]
        busy = sum(delta) - delta[3] - delta[4]
        if busy:
            sibling_activity.append(dict(cell=cell['id'], process=process, busy_ticks=busy, total_ticks=sum(delta)))
        raw = [json.loads(s) for s in (folder / str(process) / 'samples.jsonl').read_text().splitlines()]
        assert len(raw) == 8
        paired = []
        for round_number in range(2):
            order = ['ours', 'reference'] if (process + round_number) % 2 == 0 else ['reference', 'ours']
            samples = raw[round_number*4:round_number*4+4]
            assert [(s['name'], s['kind']) for s in samples] == [(name, kind) for name in order for kind in ['warmup', 'timed']]
            for sample in samples:
                assert sample['round'] == round_number
                count = frozen_counts[sample['name']]
                assert sample['count'] == (count if sample['kind'] == 'timed' else max(1, count//2))
                if sample['kind'] == 'timed':
                    durations.append(sample['elapsed_ns'])
            timed = {s['name']: s for s in samples if s['kind'] == 'timed'}
            paired.append(math.log(timed['ours']['ns_per_call']/timed['reference']['ns_per_call']))
        logs.append(statistics.median(paired))
    row = rows[cell['id']]
    assert row['process_log_ratios'] == logs
    mean = statistics.mean(logs)
    half = manifest['protocol']['upper95_t9'] * statistics.stdev(logs) / math.sqrt(10)
    assert math.isclose(row['ratio'], math.exp(mean), rel_tol=1e-14)
    assert math.isclose(row['upper95'], math.exp(mean+half), rel_tol=1e-14)
    detail = dict(row, lower95=math.exp(mean-half), primitive=cell['primitive'], backend=cell['backend'], length=cell['length'], reference=cell['reference'], population=cell['population'])
    (controls if cell['control'] else required if cell['required_parity'] else nonparity).append(detail)

result = dict(source_revision=manifest['source_revision'], cells=len(rows), required=len(required),
    required_failures=[r for r in required if not r['passes']],
    required_mean_losses=[r for r in required if r['ratio'] > 1],
    worst_required_upper=max(required, key=lambda r: r['upper95']),
    timed_samples=len(durations), minimum_timed_ns=min(durations),
    invalid_duration_samples=sum(d < 250_000_000 for d in durations),
    sibling_active_windows=sibling_activity, controls=controls, nonparity=nonparity)
assert len(durations) == 20000
(P / 'qualification-final-audit.json').write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps({k: v for k,v in result.items() if k not in ['controls','nonparity','sibling_active_windows','required_failures']}, indent=2))
print('Required failures:', len(result['required_failures']), 'Sibling active windows:', len(sibling_activity))
