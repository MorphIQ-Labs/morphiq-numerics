import pathlib,sys,ctypes as C,os,csv,math,json
P=pathlib.Path(__file__).resolve().parent;sys.path.insert(0,str(P.parent/'pr240-external-20261028'))
import external as E
os.sched_setaffinity(0,{2});libs={n:C.CDLL(str(P/'bin'/f'{n}.so')) for n in ['auto','sse2','avx2','avx512']};native=C.CDLL(str(P/'bin/native-matrix.so'))
refs={r['name']:r for r in E.REG}
for prim in ['exp','cdf']:
 name=f'sleef_{prim}_sse2';refs[name]=dict(name=name,primitive=prim,kind='vector',ptr=C.cast(getattr(native,name),C.c_void_p).value)
rows=[]
def measure(r,x,count):
 y=E.np.empty_like(x);m=E.NATIVE.measure_packet if r['kind']=='vector' else E.NATIVE.measure2 if r['kind']=='scalar_capsule' else E.NATIVE.measure1
 elapsed=m(r['ptr'],x.ctypes.data_as(E.D),y.ctypes.data_as(E.D),len(x),count);return elapsed
with (P/'matrix-screen.csv').open('w',buffering=1) as f:
 writer=csv.writer(f);writer.writerow(['backend','primitive','population','length','interface','round','name','iterations','elapsed_ns','ns_per_call'])
 for backend in ['auto','sse2','avx2','avx512']:
  for prim,symbol in [('exp','exp'),('erfcx','erfcx'),('cdf','norm_cdf')]:
   for population in ['ordinary','wide']:
    for n in [1,7,8,9,52,4096]:
     if population=='ordinary':x=E.np.resize(E.PACKETS[prim],n)
     else:
      lo,hi={'exp':(-703.999,703.999),'erfcx':(-.5,15.999),'cdf':(-8,8)}[prim]
      x=E.np.array([lo+(hi-lo)*(i+.5)/n for i in range(n)])
     kinds=['vector']+(['scalar'] if backend=='auto' and n in [52,4096] else [])
     for kind in kinds:
      prod=dict(name=f'prod_{symbol}'+('_slice' if kind=='vector' else ''),kind=kind,ptr=C.cast(getattr(libs[backend],f'prod_{symbol}'+('_slice' if kind=='vector' else '')),C.c_void_p).value)
      refname='libcerf_erfcx' if prim=='erfcx' else ('sleef_exp_scalar_fma' if prim=='exp' else 'scipy_ndtr') if kind=='scalar' else f'sleef_{prim}_'+('avx512' if backend=='auto' else backend)
      ref=refs[refname];entries=[prod,ref];counts={}
      for r in entries:
       elapsed=measure(r,x,1000);counts[r['name']]=max(1,math.ceil(30000000/(elapsed/1000)))
      for rep in range(2):
       for r in entries if rep==0 else entries[::-1]:
        count=counts[r['name']];elapsed=measure(r,x,count)
        writer.writerow([backend,prim,population,n,kind,rep,r['name'],count,elapsed,elapsed/count])
print('Exploratory size/domain screen complete; not qualification.')
