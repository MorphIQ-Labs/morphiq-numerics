from pathlib import Path
import subprocess,os,json,time,signal,sys
P=Path(__file__).resolve().parent;os.sched_setaffinity(0,{0})
python=str(P/'venv/bin/python');capture=P.parent/'pr240-local-20261028T102243Z/capture-host.py'
env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MORPHIQ_BENCH_CPU='2')
def snapshot(name):
 with (P/'paired'/name).open('w') as f:subprocess.run([sys.executable,str(capture)],stdout=f,env=env,check=True)
(P/'paired').mkdir(exist_ok=True)
# All local build/oracle activity must also be finished before starting this driver.
lines=subprocess.check_output(['podman','top','pr240-coq','hpid','comm'],text=True).splitlines()[1:]
pids=[]
for name in ['make','coqc']:
 for line in lines:
  pid,comm=line.split()
  if comm==name and pid.isdigit():
   try:os.kill(int(pid),signal.SIGSTOP);pids.append(int(pid))
   except ProcessLookupError:pass
(P/'stopped-proofs.json').write_text(json.dumps(pids))
try:
 print('Owner authorized CPU 2 timing with unrelated-core load recorded; own proof work stopped; settling for 30 seconds.',flush=True)
 time.sleep(30)
 snapshot('calibration-before-host.json')
 subprocess.run([python,str(P/'paired.py'),'calibration'],env=env,check=True)
 snapshot('calibration-after-host.json')
 for process in range(10):
  if process==5:time.sleep(30)
  snapshot(f'{process}-before-host.json')
  subprocess.run([python,str(P/'paired.py'),str(process)],env=env,check=True)
  snapshot(f'{process}-after-host.json')
  print('Finished process',process,flush=True)
 print('All timing processes finished.',flush=True)
finally:
 for pid in pids:
  try:os.kill(pid,signal.SIGCONT)
  except ProcessLookupError:pass
