from pathlib import Path
import shutil,re
p=Path(__file__).resolve().parent;b=p/'proof-build';w=p/'source'
# Keep timestamps only for byte-identical sources, so make cannot reuse stale proofs.
for d in ['binary64','double-word','two-prod','q']:
 for f in (w/'formal'/d).glob('*.v'):
  dest=b/d/f.name
  if not dest.exists() or dest.read_bytes()!=f.read_bytes():shutil.copyfile(f,dest)
for d in (w/'formal').iterdir():
 if d.name in ['binary64','double-word','two-prod','q','audit','extraction']:continue
 for f in d.glob('*.v'):
  dest=b/'gappa'/f.name
  if not dest.exists() or dest.read_bytes()!=f.read_bytes():shutil.copyfile(f,dest)
for f in (p/'fast-gappa').glob('*.v'):
 s='From Coq Require Import Reals. Require Import Hints.\n'+re.sub(r'^Hypothesis (a[0-9]+) : (.*)\.$',r'Lemma \1 : \2.\nProof. hint. Qed.',f.read_text(),flags=re.M)
 assert not re.search(r'^Hypothesis',s,re.M)
 dest=b/'gappa'/f.name
 if not dest.exists() or dest.read_text()!=s:dest.write_text(s)
mappings='-R double-word Double\n-R two-prod ""\n-R binary64 Binary64\n-R q Q\n-R gappa ""\n'
files=sorted(str(f.relative_to(b)) for d in ['binary64','double-word','two-prod','q','gappa'] for f in (b/d).glob('*.v'))
(b/'_CoqProject').write_text(mappings+'\n'.join(files)+'\n')
