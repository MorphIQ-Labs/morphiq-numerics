# Exp matrix remediation decision

Source baseline: 5aa5d4a. The exploratory native screen (matrix-screen.csv, not qualification) finds 8/9-value AVX-512 calls and several AVX2 batch lengths slower than SLEEF; erfcx/CDF have no material losing cells in that screen. This changes the required performance investigation beyond the original 52-value packet.

Invariant: retain relative 2^-51 for abs(x)<704, identical scalar/SIMD bits within the selected evaluator, and strong fallback/special values. No new coefficients or weaker bound. The owner retired the 3% absolute timing gate; all declared comparable-reference cells still require upper95 paired ratio <=1.

Candidate A removes unnecessary vector remainder work and avoids general chunk-loop setup for exactly one vector. Small remainders use the existing scalar evaluator; larger AVX-512 remainders retain masked access. The outputs are identical by the existing scalar/lane operation contract. The crossover is a performance choice to verify across all required short lengths, not a numerical threshold.

Candidate B evaluates the same quartic as r + r*r*(0.5+r*(d3+r*d4)), removing one multiply while extending its dependency chain. Reprove IEEE evaluation and the existing 2^-59 reduced error before selecting it. Measure throughput and dependent latency independently; fewer operations alone is not sufficient evidence.

Candidate C reconstructs H*(1+u), avoiding a potentially subnormal H*u intermediate. Its extra rounding must fit the same 4u public budget using independent Gappa/Coq proof; sampled error alone cannot accept it. Do not attribute observed wide-domain cost to subnormal assists without profiling evidence.

Each candidate is retained with its binary/source and exploratory screen. Select only a candidate that passes both proof/oracle obligations and the expanded native cost matrix; retain losses and rejected structures. Strong APIs are unchanged. Native ARM is measured directly on the owner's host using the issue handoff, never inferred from x86 or emulation.

Candidate D: increase the fast-only reduction table from 512 to 2048 high words (4 KiB to 16 KiB), with exact power-of-two projections INV_N*4, S_L1/4 and S_L2D/4. The smaller residual permits the existing degree-three Taylor coefficients; discarded quartic error is about 3.5e-17 on |r|<=0.00016925. Keep the public relative 2^-51 bound and prove the entire revised reduction/table/evaluation budget before selection. This is an experimental numerical design, not a claim that sampled errors establish a bound. Compare the expanded workload/footprint cost before undertaking the larger proof update. Reject if short and large cost gaps remain. No FMA contraction, no changed strong APIs.
