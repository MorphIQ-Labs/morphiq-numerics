from pathlib import Path
import ctypes as C,json,os,struct,sys,time
P=Path(__file__).resolve().parent;os.sched_setaffinity(0,{2})
import scipy.special.cython_special as cy
native=C.CDLL(str(P/'bin/native-matrix.so'));D=C.POINTER(C.c_double)
for name in ['measure1','measure2']:
 m=getattr(native,name);m.argtypes=[C.c_void_p,D,D,C.c_size_t,C.c_uint64];m.restype=C.c_uint64
name=sys.argv[1]
if name=='scipy':
 obj=cy.__pyx_capi__['__pyx_fuse_1ndtr'];getname=C.pythonapi.PyCapsule_GetName;getname.argtypes=[C.py_object];getname.restype=C.c_char_p
 get=C.pythonapi.PyCapsule_GetPointer;get.argtypes=[C.py_object,C.c_char_p];get.restype=C.c_void_p
 ptr=get(obj,getname(obj));method=native.measure2
else:
 lib=C.CDLL(str(P/('final-bin/control.so' if name=='baseline' else 'candidates/short-blocks.so')))
 ptr=C.cast(lib.prod_norm_cdf,C.c_void_p).value;method=native.measure1
words=json.loads((P/'matrix-inputs/cdf-ordinary-52.json').read_text());values=[struct.unpack('>d',bytes.fromhex(w))[0] for w in words]
x=(C.c_double*52)(*values);y=(C.c_double*52)()
time.sleep(2)
n=100000000//52;elapsed=method(ptr,x,y,52,n)
print(json.dumps(dict(name=name,n=n,ns_per_packet=elapsed/n,input_address=C.addressof(x),output_address=C.addressof(y),function_address=ptr)))
