## Native ARM handoff — run directly on the host

The owner will run this work directly on the native ARM host. **No SSH credentials, remote connection, cloud provisioning or pause of another project's job is requested.** This issue is the handoff between machines. Use native AArch64 Linux or Apple Silicon macOS; record which. A Rosetta process, x86 container or emulated ARM run does not establish native ARM performance. CPU 2 / sibling 14 are instructions for the existing x86 host only, not ARM CPU numbers.

### Source and evidence to take to the host

- Current committed baseline: `5aa5d4a116c8f8da3835d46d1cef94687ab26646` on PR #240 (`perf/qdfp-fast-primitives`). It includes the optimized kernels, proof bindings, deliberately updated fast digest and the seven-pair x86 evidence. It is **not yet the final release-qualified candidate**. The exploratory x86 expansion found exp short-slice/AVX2 gaps; experimental dispatch/remainder changes are local and are not in this commit. Do not accidentally benchmark the old `0c5ece3` checkout or treat an uncommitted experiment as the released implementation.
- Read `AGENTS.md`, `docs/PROVENANCE.md`, `docs/fast.md`, the current acceptance decision above and the expanded matrix below. Changes to arithmetic, dispatch, compiler settings or the harness require affected cells to be remeasured and the exact revision/settings recorded. ARM preparation and baseline observations can start now; final acceptance must name the final committed implementation and its usable release tag.
- [Frozen x86 evidence](https://github.com/MorphIQ-Labs/morphiq-numerics/tree/5aa5d4a116c8f8da3835d46d1cef94687ab26646/docs/fast-evidence/native-parity-20261028) includes `README.md`, `summary.json`, `manifest.json`, `SHA256SUMS` and `observations.tar.gz`. Archive SHA-256: `cd89aab5ae35fb47e929d8131d93beea87818cc0a139293ada6b97c0b63dd630`. Inside it, `original-inputs/timed-input-bits.csv` has SHA-256 `0859a015fa53943c2c5375cd56c31fd48ba8d027d3fcd16207013763e5c59087`. Reuse those exact bits, not decimal reconstructions. The archive also contains public Rust wrapper source, reference pins, C timing wrappers, raw paired samples, independent accuracy observations and proof receipts.
- [CI for this baseline](https://github.com/MorphIQ-Labs/morphiq-numerics/actions/runs/40743487102): at handoff, 29 of 30 PR checks are successful; `formal (coq)` is still running. Query the live result before calling it green. Native ARM correctness in CI is already successful; it is not an ARM speed measurement.

Preparation in an existing clean native checkout (Bash):

```bash
set -euo pipefail
git fetch origin perf/qdfp-fast-primitives
bench_revision=5aa5d4a116c8f8da3835d46d1cef94687ab26646
test -z "$(git status --porcelain)"
git switch --detach "$bench_revision"
case "$(uname -m)" in
  aarch64|arm64) ;;
  *) echo 'Use a native ARM shell and toolchain'; exit 1 ;;
esac
bench_out="$PWD/target/arm-194-$(date -u +%Y%m%dT%H%M%SZ)"
mkdir -p "$bench_out/evidence"
git rev-parse HEAD > "$bench_out/revision.txt"
git status --porcelain > "$bench_out/worktree-status.txt"
rustc -vV > "$bench_out/rustc.txt"
cargo -V > "$bench_out/cargo.txt"
uname -a > "$bench_out/kernel.txt"
tar -xzf docs/fast-evidence/native-parity-20261028/observations.tar.gz \
  -C "$bench_out/evidence"
python3 - "$bench_out/evidence" <<'PY'
import hashlib, pathlib, sys
p = pathlib.Path(sys.argv[1]) / 'original-inputs/timed-input-bits.csv'
assert hashlib.sha256(p.read_bytes()).hexdigest() == \
    '0859a015fa53943c2c5375cd56c31fd48ba8d027d3fcd16207013763e5c59087'
PY
env RUSTFLAGS= CARGO_ENCODED_RUSTFLAGS= RUSTC_WRAPPER= RUSTC_WORKSPACE_WRAPPER= \
  CARGO_TARGET_DIR="$bench_out/build" \
  cargo build --locked --release -p morphiq-numerics-reference \
    --features simd,std --bin bench-fast-primitives \
    > "$bench_out/build.log" 2>&1
```

Check that `rustc -vV` also reports an AArch64 host and that no Cargo target override produces a non-native executable. Capture the executable architecture and SHA-256. Rust is pinned by `rust-toolchain.toml` to 1.97.1. Record any necessary host-specific build change; do not enable fast-math or implicit contraction. The commands above prepare the **baseline** and do not run a qualification campaign.

### Harness work needed before final ARM timings

The archived external-comparison scripts are executed x86 evidence, **not a turnkey ARM runner**. Their absolute library paths, Linux CPU-2 affinity, `.so` names and AVX2/AVX-512 wrappers must be adapted explicitly. The repository's `bench-fast-primitives` runner is portable but only compares strong/fast implementations on 52 values; it cannot establish external-reference parity or the expanded matrix by itself. Do not run the historical 3% script below as the current acceptance gate.

1. Rebuild the pinned references listed in the expanded matrix on the ARM host. Keep their native compiler, CMake configuration, build logs and binary hashes. Use native SLEEF binary64 NEON exp-u10 and erfc-u15 entry points, verified against the pinned installed header/exported symbols; do not guess an x86 symbol rename. Use native scalar remainder calls, and include them in the timing. Preserve the CDF composition `0.5 * erfc(x * -0x1.6a09e667f3bcdp-1)` and its rounding order. If a pinned comparator cannot be built, report that cell as unavailable; do not silently substitute platform libm or count it as passed.
2. Adapt the archived Rust cdylib's dependency path to this clean checkout and use the native shared-library extension. Keep `simd,std`, release thin LTO and one codegen unit for the external-wrapper comparison. Both sides use the archived C timer interface, with allocations/input construction outside the clock. SciPy ndtr uses its native Cython capsule with its extra integer argument fixed to one; timing a Python ufunc call would be a different comparison.
3. Materialize and hash every exact input-bit bank and the complete per-cell manifest before qualification. Include the ordinary bank, accelerated-domain coverage, reduction/table boundaries, CDF cancellation/tails, special values and mixed strong-fallback populations. Include the declared public lengths, scalar throughput and dependent latency. Record compiler output showing the dependency chain survives optimization; keep its added arithmetic/call overhead visible. Record dispatch, scalar remainders, empty calls, allocations, code/table footprint, cache competition and intermediate passes separately. The current standalone fast erfcx slice is an inlined scalar loop; do not label it a NEON kernel.
4. Check scalar/slice bit identity and independent 256-bit oracle observations on the actual timed banks/binaries **outside timing windows**. Keep proved bounds separate from observed errors and rounding uncertainty. Full tests, lint and the determinism matrix remain in GitHub CI; focused proof/generator checks are permitted when changed kernels need them, also outside timing windows.
5. Use the expanded paired protocol below, not the historical repeatability campaign. Freeze calibrated counts, retain every attempt, and report every required cell independently. For each process, take the median of its two paired log time ratios; across ten process values compute `exp(mean + t(0.95,9)*sample_stddev/sqrt(10))`. The one-sided 95% upper ratio must be at most 1.0 for each selected comparable-contract cost cell. An upper bound above 1.0 means meet-or-beat is not established; it is not permission to discard data or relax the numerical contract. The 3% absolute-spread criterion is retired.

Use AC power and record power mode, thermal conditions, SoC/core topology and contention. On Linux select a suitable physical core from that host's topology and use `taskset`; record siblings if present. On macOS record the actual scheduling controls and limitations—do not claim Linux-style hard affinity. Run builds, profiling and independent oracle work before or after the timing windows. Do not stop unrelated jobs without authorization. No local full CI is required for this handoff.

### What remains open and what to return

The seven original 52-value x86 pairs passed the paired cost rule. A later short exploratory screen found fast exp slower for automatic 8/9-element slices (about 1.40/1.55 times SLEEF on the ordinary bank) and some AVX2/large wide-domain batches. Those short screen measurements are diagnostic, not a new qualification result. Remainder/dispatch work is being investigated; a complete root cause or a successful fix has not been established. Erfcx/CDF looking competitive in that screen does not replace their required matrix measurements. Do not infer ARM performance from either x86 result.

Return an evidence archive linked from this issue with: clean commit and eventual release tag; source/harness/binary hashes; Rust/C and reference versions/settings; host/conditions/scheduling records; exact input banks and cell manifest; per-cell frozen counts; all calibration, warmup, raw timings, rejected attempts and interruptions; paired confidence summaries; independent accuracy/identity outputs; profiles/allocation/footprint observations collected separately; and all failed or unavailable comparisons. Include executable hashes even if executables are omitted. Preserve meaningful contention/thermal information when redacting private identifiers. Remove throwaway reference clones, worktrees and build output after packaging and verifying the retained evidence; preserve uncommitted work first.

ARM evidence remains open until returned and evaluated. The known x86 gaps, expanded measurements, final assurance checks, normal owner-merged release PR/tag and capability/adoption handoff to #91/#155 also remain open. Recording this handoff does not close #194 or narrow its acceptance criteria.
