
### Host condition clarification before calibration

The owner explicitly directed this campaign to proceed on clear CPU 2 while unrelated CI uses other cores. CPU 14 remains the idle SMT sibling. The strict no-local-build condition applies to this experiment’s builds/proofs/oracles; unrelated-core activity is retained in host snapshots and is not a reason to defer timing. The numerical, duration, no-slowdown and 3% absolute-repeatability rules remain unchanged. No calibration or timing sample had been taken before this clarification. Final source is `ca3fce4`; the two lint-only fixes leave the public wrapper binary SHA-256 identical to the frozen binary above.
