"""Outside timing: observe each selected reference on its exact timed inputs."""
from pathlib import Path
import ctypes as C,csv,gzip,json,math,os,struct
import mpmath as mp
P=Path(__file__).resolve().parent;E=P.parent/'pr240-external-20261028/bin';os.sched_setaffinity(0,{0});mp.mp.prec=256
D=C.POINTER(C.c_double);word=lambda x:struct.pack('>d',float(x)).hex();value=lambda w:struct.unpack('>d',bytes.fromhex(w))[0]
out=P/'qualification-reference-observations';out.mkdir(exist_ok=False)
native=C.CDLL(str(P/'bin/native-matrix.so'));libs={name:C.CDLL(str(E/file)) for name,file in [('core','libcoreexp.so'),('sleef','libsleef.so.3'),('cerf','libcerf.so')]}
import scipy.special.cython_special as cy
obj=cy.__pyx_capi__['__pyx_fuse_1ndtr'];get=C.pythonapi.PyCapsule_GetPointer;get.argtypes=[C.py_object,C.c_char_p];get.restype=C.c_void_p
ndtr=C.CFUNCTYPE(C.c_double,C.c_double,C.c_int)(get(obj,b'double (double, int __pyx_skip_dispatch)'))
manifest=json.loads((P/'qualification-manifest.json').read_text());results=[]
for primitive in ['exp','erfcx','cdf']:
 with gzip.open(P/'qualification-observations'/(primitive+'.csv.gz'),'rt') as f:oracles={r['input_bits']:mp.mpf(r['reference_256bit']) for r in csv.DictReader(f)}
 refs=sorted({c['reference'] for c in manifest['cells'] if c['primitive']==primitive and not c['control']})
 for ref in refs:
  paths=sorted({c['input']['file'] for c in manifest['cells'] if c['primitive']==primitive and c['reference']==ref});packet=ref.startswith('sleef_') and ref!='sleef_exp_scalar_fma'
  if packet:fn=getattr(native,ref);fn.argtypes=[D,D,C.c_size_t];fn.restype=None
  elif ref=='scipy_ndtr':fn=lambda x:ndtr(x,1)
  else:
   lib,symbol={'core_math_exp':('core','cr_exp'),'sleef_exp_scalar_fma':('sleef','Sleef_expd1_u10purecfma'),'libcerf_erfcx':('cerf','erfcx')}[ref];fn=getattr(libs[lib],symbol);fn.argtypes=[C.c_double];fn.restype=C.c_double
  seen={};over=[];worst=mp.mpf(0);witness=None;budget=mp.mpf(2)**(-49 if primitive=='cdf' else -51)
  with gzip.open(out/(ref+'.csv.gz'),'wt') as stream:
   writer=csv.writer(stream);writer.writerow(['input_bits','output_bits','error'])
   for path in paths:
    words=json.loads(Path(path).read_text());xs=[value(w) for w in words]
    if packet:
     x=(C.c_double*max(1,len(xs)))(*xs);y=(C.c_double*max(1,len(xs)))();fn(x,y,len(xs));ys=list(y)[:len(xs)]
    else:ys=[fn(x) for x in xs]
    for w,y in zip(words,ys):
     if w not in oracles:continue
     output=word(y)
     if (w,output) in seen:continue
     seen[w,output]=True;oracle=oracles[w];error=abs(mp.mpf(y)-oracle)/(1 if primitive=='cdf' else abs(oracle))
     writer.writerow([w,output,mp.nstr(error,30)])
     if error>worst:worst=error;witness=dict(input=w,output=output)
     if not math.isfinite(y) or error>budget:over.append(w)
  row=dict(primitive=primitive,reference=ref,observed_outputs=len(seen),max_error=float(worst),product_budget=float(budget),exceeds_product_bound=over,witness=witness)
  results.append(row);(out/'summary.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(row),flush=True)
