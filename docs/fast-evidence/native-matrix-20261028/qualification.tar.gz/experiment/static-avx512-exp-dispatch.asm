
target/benchmarks/pr240-parity-next-20261028/qualification-bin/avx512.so:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .text:

000000000002b5e0 <prod_exp_slice>:
   2b5e0:	55                   	push   %rbp
   2b5e1:	41 57                	push   %r15
   2b5e3:	41 56                	push   %r14
   2b5e5:	41 55                	push   %r13
   2b5e7:	41 54                	push   %r12
   2b5e9:	53                   	push   %rbx
   2b5ea:	48 83 ec 38          	sub    $0x38,%rsp
   2b5ee:	49 89 d7             	mov    %rdx,%r15
   2b5f1:	48 89 f5             	mov    %rsi,%rbp
   2b5f4:	49 89 fe             	mov    %rdi,%r14
   2b5f7:	48 83 fa 02          	cmp    $0x2,%rdx
   2b5fb:	0f 83 a7 00 00 00    	jae    2b6a8 <prod_exp_slice+0xc8>
   2b601:	49 83 ff 01          	cmp    $0x1,%r15
   2b605:	0f 85 4d 10 00 00    	jne    2c658 <prod_exp_slice+0x1078>
   2b60b:	c4 c1 7b 10 06       	vmovsd (%r14),%xmm0
   2b610:	c5 f9 54 0d 68 a5 fd 	vandpd -0x25a98(%rip),%xmm0,%xmm1        # 5b80 <anon.06f69dd73d1c6fac5f9aa7f3913dfdf6.31.llvm.17030290209220970773+0x1f0>
   2b617:	ff 
   2b618:	c5 fb 10 15 80 ad fd 	vmovsd -0x25280(%rip),%xmm2        # 63a0 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x1c0>
   2b61f:	ff 
   2b620:	c5 f9 2e d1          	vucomisd %xmm1,%xmm2
   2b624:	0f 86 a3 02 00 00    	jbe    2b8cd <prod_exp_slice+0x2ed>
   2b62a:	c5 fb 59 0d ae b0 fd 	vmulsd -0x24f52(%rip),%xmm0,%xmm1        # 66e0 <anon.02ffda8f51e6076a26652e0a4fd6fa8d.746.llvm.5406940975955002095+0x180>
   2b631:	ff 
   2b632:	c5 f3 58 0d f6 af fd 	vaddsd -0x2500a(%rip),%xmm1,%xmm1        # 6630 <anon.02ffda8f51e6076a26652e0a4fd6fa8d.746.llvm.5406940975955002095+0xd0>
   2b639:	ff 
   2b63a:	c4 e1 f9 7e c8       	vmovq  %xmm1,%rax
   2b63f:	89 c1                	mov    %eax,%ecx
   2b641:	81 e1 ff 03 00 00    	and    $0x3ff,%ecx
   2b647:	c5 f3 58 0d b9 af fd 	vaddsd -0x25047(%rip),%xmm1,%xmm1        # 6608 <anon.02ffda8f51e6076a26652e0a4fd6fa8d.746.llvm.5406940975955002095+0xa8>
   2b64e:	ff 
   2b64f:	48 8d 15 72 c2 fd ff 	lea    -0x23d8e(%rip),%rdx        # 78c8 <anon.ee651107ab5319c6bc273e1a29320aaf.386.llvm.14746981713632465754+0x1d4>
   2b656:	48 c1 e0 2a          	shl    $0x2a,%rax
   2b65a:	48 03 04 ca          	add    (%rdx,%rcx,8),%rax
   2b65e:	c4 e1 f9 6e d0       	vmovq  %rax,%xmm2
   2b663:	c5 f3 59 1d 95 ae fd 	vmulsd -0x2516b(%rip),%xmm1,%xmm3        # 6500 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x320>
   2b66a:	ff 
   2b66b:	c5 f3 59 0d 35 ad fd 	vmulsd -0x252cb(%rip),%xmm1,%xmm1        # 63a8 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x1c8>
   2b672:	ff 
   2b673:	c5 fb 58 c3          	vaddsd %xmm3,%xmm0,%xmm0
   2b677:	c5 f3 58 c0          	vaddsd %xmm0,%xmm1,%xmm0
   2b67b:	c5 fb 59 0d 65 ae fd 	vmulsd -0x2519b(%rip),%xmm0,%xmm1        # 64e8 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x308>
   2b682:	ff 
   2b683:	c5 fb 59 d8          	vmulsd %xmm0,%xmm0,%xmm3
   2b687:	c5 f3 58 0d 59 ad fd 	vaddsd -0x252a7(%rip),%xmm1,%xmm1        # 63e8 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x208>
   2b68e:	ff 
   2b68f:	c5 e3 59 c9          	vmulsd %xmm1,%xmm3,%xmm1
   2b693:	c5 fb 58 c1          	vaddsd %xmm1,%xmm0,%xmm0
   2b697:	c5 fb 58 05 91 ae fd 	vaddsd -0x2516f(%rip),%xmm0,%xmm0        # 6530 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x350>
   2b69e:	ff 
   2b69f:	c5 fb 59 c2          	vmulsd %xmm2,%xmm0,%xmm0
   2b6a3:	e9 2b 02 00 00       	jmp    2b8d3 <prod_exp_slice+0x2f3>
   2b6a8:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
   2b6ad:	4c 89 7c 24 18       	mov    %r15,0x18(%rsp)
   2b6b2:	48 89 6c 24 20       	mov    %rbp,0x20(%rsp)
   2b6b7:	4c 89 7c 24 28       	mov    %r15,0x28(%rsp)
   2b6bc:	49 83 ff 07          	cmp    $0x7,%r15
   2b6c0:	0f 86 ac 01 00 00    	jbe    2b872 <prod_exp_slice+0x292>
   2b6c6:	49 83 ff 40          	cmp    $0x40,%r15
   2b6ca:	0f 87 d2 01 00 00    	ja     2b8a2 <prod_exp_slice+0x2c2>
   2b6d0:	49 8d 47 ff          	lea    -0x1(%r15),%rax
   2b6d4:	4c 21 f8             	and    %r15,%rax
   2b6d7:	0f 85 c5 01 00 00    	jne    2b8a2 <prod_exp_slice+0x2c2>
   2b6dd:	f3 49 0f bc c7       	tzcnt  %r15,%rax
   2b6e2:	48 ff c8             	dec    %rax
   2b6e5:	48 83 f8 05          	cmp    $0x5,%rax
   2b6e9:	0f 87 fe 01 00 00    	ja     2b8ed <prod_exp_slice+0x30d>
   2b6ef:	48 8d 0d ba c1 fd ff 	lea    -0x23e46(%rip),%rcx        # 78b0 <anon.ee651107ab5319c6bc273e1a29320aaf.386.llvm.14746981713632465754+0x1bc>
   2b6f6:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
   2b6fa:	48 01 c8             	add    %rcx,%rax
   2b6fd:	ff e0                	jmp    *%rax
   2b6ff:	49 83 ff 08          	cmp    $0x8,%r15
   2b703:	0f 85 9f 0f 00 00    	jne    2c6a8 <prod_exp_slice+0x10c8>
   2b709:	62 f2 fd 48 19 0d 8d 	vbroadcastsd -0x25373(%rip),%zmm1        # 63a0 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x1c0>
   2b710:	ac fd ff 
   2b713:	c5 f9 57 c0          	vxorpd %xmm0,%xmm0,%xmm0
   2b717:	62 f1 fd 48 c2 c1 11 	vcmplt_oqpd %zmm1,%zmm0,%k0
   2b71e:	62 d1 fe 48 6f 06    	vmovdqu64 (%r14),%zmm0
   2b724:	62 f1 fd 58 db 15 fa 	vpandq -0x25206(%rip){1to8},%zmm0,%zmm2        # 6528 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x348>
   2b72b:	ad fd ff 
   2b72e:	62 f1 ed 48 c2 c9 11 	vcmplt_oqpd %zmm1,%zmm2,%k1
   2b735:	c5 fc 41 c1          	kandw  %k1,%k0,%k0
   2b739:	c5 f8 93 c0          	kmovw  %k0,%eax
   2b73d:	3c ff                	cmp    $0xff,%al
   2b73f:	0f 85 6c 0f 00 00    	jne    2c6b1 <prod_exp_slice+0x10d1>
   2b745:	62 f1 fd 58 59 0d 91 	vmulpd -0x2506f(%rip){1to8},%zmm0,%zmm1        # 66e0 <anon.02ffda8f51e6076a26652e0a4fd6fa8d.746.llvm.5406940975955002095+0x180>
   2b74c:	af fd ff 
   2b74f:	62 f1 f5 58 58 0d d7 	vaddpd -0x25129(%rip){1to8},%zmm1,%zmm1        # 6630 <anon.02ffda8f51e6076a26652e0a4fd6fa8d.746.llvm.5406940975955002095+0xd0>
   2b756:	ae fd ff 
   2b759:	62 f1 f5 58 db 15 5d 	vpandq -0x253a3(%rip){1to8},%zmm1,%zmm2        # 63c0 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x1e0>
   2b760:	ac fd ff 
   2b763:	c4 e1 f9 7e d0       	vmovq  %xmm2,%rax
   2b768:	48 8d 0d 59 c1 fd ff 	lea    -0x23ea7(%rip),%rcx        # 78c8 <anon.ee651107ab5319c6bc273e1a29320aaf.386.llvm.14746981713632465754+0x1d4>
   2b76f:	c4 e3 f9 16 d2 01    	vpextrq $0x1,%xmm2,%rdx
   2b775:	c4 e3 7d 39 d3 01    	vextracti128 $0x1,%ymm2,%xmm3
   2b77b:	c4 e1 f9 7e de       	vmovq  %xmm3,%rsi
   2b780:	c4 e3 f9 16 df 01    	vpextrq $0x1,%xmm3,%rdi
   2b786:	62 f3 7d 48 39 d3 02 	vextracti32x4 $0x2,%zmm2,%xmm3
   2b78d:	c4 c1 f9 7e d8       	vmovq  %xmm3,%r8
   2b792:	c4 c3 f9 16 d9 01    	vpextrq $0x1,%xmm3,%r9
   2b798:	62 f3 7d 48 39 d2 03 	vextracti32x4 $0x3,%zmm2,%xmm2
   2b79f:	c4 c1 f9 7e d2       	vmovq  %xmm2,%r10
   2b7a4:	c4 c3 f9 16 d3 01    	vpextrq $0x1,%xmm2,%r11
   2b7aa:	c4 a1 7a 7e 14 d9    	vmovq  (%rcx,%r11,8),%xmm2
   2b7b0:	c4 a1 7a 7e 1c d1    	vmovq  (%rcx,%r10,8),%xmm3
   2b7b6:	c5 e1 6c d2          	vpunpcklqdq %xmm2,%xmm3,%xmm2
   2b7ba:	c4 a1 7a 7e 1c c9    	vmovq  (%rcx,%r9,8),%xmm3
   2b7c0:	c4 a1 7a 7e 24 c1    	vmovq  (%rcx,%r8,8),%xmm4
   2b7c6:	c5 d9 6c db          	vpunpcklqdq %xmm3,%xmm4,%xmm3
   2b7ca:	c4 e3 65 38 d2 01    	vinserti128 $0x1,%xmm2,%ymm3,%ymm2
   2b7d0:	c5 fa 7e 1c f9       	vmovq  (%rcx,%rdi,8),%xmm3
   2b7d5:	c5 fa 7e 24 f1       	vmovq  (%rcx,%rsi,8),%xmm4
   2b7da:	c5 d9 6c db          	vpunpcklqdq %xmm3,%xmm4,%xmm3
   2b7de:	c5 fa 7e 24 d1       	vmovq  (%rcx,%rdx,8),%xmm4
   2b7e3:	c5 fa 7e 2c c1       	vmovq  (%rcx,%rax,8),%xmm5
   2b7e8:	c5 d1 6c e4          	vpunpcklqdq %xmm4,%xmm5,%xmm4
   2b7ec:	c4 e3 5d 38 db 01    	vinserti128 $0x1,%xmm3,%ymm4,%ymm3
   2b7f2:	62 f1 f5 58 58 25 0c 	vaddpd -0x251f4(%rip){1to8},%zmm1,%zmm4        # 6608 <anon.02ffda8f51e6076a26652e0a4fd6fa8d.746.llvm.5406940975955002095+0xa8>
   2b7f9:	ae fd ff 
   2b7fc:	62 f3 e5 48 3a d2 01 	vinserti64x4 $0x1,%ymm2,%zmm3,%zmm2
   2b803:	62 f1 f5 48 73 f1 2a 	vpsllq $0x2a,%zmm1,%zmm1
   2b80a:	62 f1 dd 58 59 1d ec 	vmulpd -0x25314(%rip){1to8},%zmm4,%zmm3        # 6500 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x320>
   2b811:	ac fd ff 
   2b814:	62 f1 ed 48 d4 c9    	vpaddq %zmm1,%zmm2,%zmm1
   2b81a:	62 f1 fd 48 58 c3    	vaddpd %zmm3,%zmm0,%zmm0
   2b820:	62 f1 dd 58 59 15 7e 	vmulpd -0x25482(%rip){1to8},%zmm4,%zmm2        # 63a8 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x1c8>
   2b827:	ab fd ff 
   2b82a:	62 f1 ed 48 58 c0    	vaddpd %zmm0,%zmm2,%zmm0
   2b830:	62 f1 fd 48 59 d0    	vmulpd %zmm0,%zmm0,%zmm2
   2b836:	62 f1 fd 58 59 1d a8 	vmulpd -0x25358(%rip){1to8},%zmm0,%zmm3        # 64e8 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x308>
   2b83d:	ac fd ff 
   2b840:	62 f1 e5 58 58 1d 9e 	vaddpd -0x25462(%rip){1to8},%zmm3,%zmm3        # 63e8 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x208>
   2b847:	ab fd ff 
   2b84a:	62 f1 ed 48 59 d3    	vmulpd %zmm3,%zmm2,%zmm2
   2b850:	62 f1 fd 48 58 c2    	vaddpd %zmm2,%zmm0,%zmm0
   2b856:	62 f1 fd 58 58 05 d0 	vaddpd -0x25330(%rip){1to8},%zmm0,%zmm0        # 6530 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x350>
   2b85d:	ac fd ff 
   2b860:	62 f1 fd 48 59 c1    	vmulpd %zmm1,%zmm0,%zmm0
   2b866:	62 f1 fd 48 11 45 00 	vmovupd %zmm0,0x0(%rbp)
   2b86d:	e9 e6 0d 00 00       	jmp    2c658 <prod_exp_slice+0x1078>
   2b872:	49 83 ff 03          	cmp    $0x3,%r15
   2b876:	76 65                	jbe    2b8dd <prod_exp_slice+0x2fd>
   2b878:	49 8d 47 ff          	lea    -0x1(%r15),%rax
   2b87c:	49 85 c7             	test   %rax,%r15
   2b87f:	0f 84 25 06 00 00    	je     2beaa <prod_exp_slice+0x8ca>
   2b885:	49 8d 47 fb          	lea    -0x5(%r15),%rax
   2b889:	48 83 f8 02          	cmp    $0x2,%rax
   2b88d:	0f 83 2f 06 00 00    	jae    2bec2 <prod_exp_slice+0x8e2>
   2b893:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
   2b898:	e8 b3 e5 ff ff       	call   29e50 <morphiq_numerics::exp::bounded::packet::<morphiq_numerics_arch::x86_64::Avx2, 4>>
   2b89d:	e9 b6 0d 00 00       	jmp    2c658 <prod_exp_slice+0x1078>
   2b8a2:	49 8d 47 f7          	lea    -0x9(%r15),%rax
   2b8a6:	48 83 f8 3a          	cmp    $0x3a,%rax
   2b8aa:	73 41                	jae    2b8ed <prod_exp_slice+0x30d>
   2b8ac:	73 3f                	jae    2b8ed <prod_exp_slice+0x30d>
   2b8ae:	48 8d 0d 13 bf fd ff 	lea    -0x240ed(%rip),%rcx        # 77c8 <anon.ee651107ab5319c6bc273e1a29320aaf.386.llvm.14746981713632465754+0xd4>
   2b8b5:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
   2b8b9:	48 01 c8             	add    %rcx,%rax
   2b8bc:	ff e0                	jmp    *%rax
   2b8be:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
   2b8c3:	e8 e8 ef ff ff       	call   2a8b0 <morphiq_numerics::exp::bounded::packet::<morphiq_numerics_arch::x86_64::Avx512, 8>>
   2b8c8:	e9 8b 0d 00 00       	jmp    2c658 <prod_exp_slice+0x1078>
   2b8cd:	ff 15 55 03 06 00    	call   *0x60355(%rip)        # 8bc28 <_DYNAMIC+0x4f8>
   2b8d3:	c5 fb 11 45 00       	vmovsd %xmm0,0x0(%rbp)
   2b8d8:	e9 7b 0d 00 00       	jmp    2c658 <prod_exp_slice+0x1078>
   2b8dd:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
   2b8e2:	ff 15 98 03 06 00    	call   *0x60398(%rip)        # 8bc80 <_DYNAMIC+0x550>
   2b8e8:	e9 6b 0d 00 00       	jmp    2c658 <prod_exp_slice+0x1078>
   2b8ed:	48 89 6c 24 08       	mov    %rbp,0x8(%rsp)
   2b8f2:	4c 89 fd             	mov    %r15,%rbp
   2b8f5:	48 c1 ed 04          	shr    $0x4,%rbp
   2b8f9:	0f 84 00 03 00 00    	je     2bbff <prod_exp_slice+0x61f>
   2b8ff:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   2b904:	4c 8d 60 40          	lea    0x40(%rax),%r12
   2b908:	4d 8d 6e 40          	lea    0x40(%r14),%r13
   2b90c:	48 8d 1d b5 bf fd ff 	lea    -0x2404b(%rip),%rbx        # 78c8 <anon.ee651107ab5319c6bc273e1a29320aaf.386.llvm.14746981713632465754+0x1d4>
   2b913:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   2b91a:	84 00 00 00 00 00 
   2b920:	49 8d 54 24 c0       	lea    -0x40(%r12),%rdx
   2b925:	62 d1 fe 48 6f 45 ff 	vmovdqu64 -0x40(%r13),%zmm0
   2b92c:	62 f1 fd 58 db 0d f2 	vpandq -0x2540e(%rip){1to8},%zmm0,%zmm1        # 6528 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x348>
   2b933:	ab fd ff 
   2b936:	62 f1 f5 58 c2 05 5f 	vcmplt_oqpd -0x255a1(%rip){1to8},%zmm1,%k0        # 63a0 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x1c0>
   2b93d:	aa fd ff 11 
   2b941:	c5 f8 93 c0          	kmovw  %k0,%eax
   2b945:	3c ff                	cmp    $0xff,%al
   2b947:	0f 85 7b 02 00 00    	jne    2bbc8 <prod_exp_slice+0x5e8>
   2b94d:	62 f1 fd 58 59 0d 89 	vmulpd -0x25277(%rip){1to8},%zmm0,%zmm1        # 66e0 <anon.02ffda8f51e6076a26652e0a4fd6fa8d.746.llvm.5406940975955002095+0x180>
   2b954:	ad fd ff 
   2b957:	62 f1 f5 58 58 0d cf 	vaddpd -0x25331(%rip){1to8},%zmm1,%zmm1        # 6630 <anon.02ffda8f51e6076a26652e0a4fd6fa8d.746.llvm.5406940975955002095+0xd0>
   2b95e:	ac fd ff 
   2b961:	62 f1 f5 58 db 15 55 	vpandq -0x255ab(%rip){1to8},%zmm1,%zmm2        # 63c0 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x1e0>
   2b968:	aa fd ff 
   2b96b:	c4 e1 f9 7e d0       	vmovq  %xmm2,%rax
   2b970:	c4 e3 f9 16 d1 01    	vpextrq $0x1,%xmm2,%rcx
   2b976:	c4 e3 7d 39 d3 01    	vextracti128 $0x1,%ymm2,%xmm3
   2b97c:	c4 e1 f9 7e de       	vmovq  %xmm3,%rsi
   2b981:	c4 e3 f9 16 df 01    	vpextrq $0x1,%xmm3,%rdi
   2b987:	62 f3 7d 48 39 d3 02 	vextracti32x4 $0x2,%zmm2,%xmm3
   2b98e:	c4 c1 f9 7e d8       	vmovq  %xmm3,%r8
   2b993:	c4 c3 f9 16 d9 01    	vpextrq $0x1,%xmm3,%r9
   2b999:	62 f3 7d 48 39 d2 03 	vextracti32x4 $0x3,%zmm2,%xmm2
   2b9a0:	c4 c1 f9 7e d2       	vmovq  %xmm2,%r10
   2b9a5:	c4 c3 f9 16 d3 01    	vpextrq $0x1,%xmm2,%r11
   2b9ab:	c4 a1 7a 7e 14 db    	vmovq  (%rbx,%r11,8),%xmm2
   2b9b1:	c4 a1 7a 7e 1c d3    	vmovq  (%rbx,%r10,8),%xmm3
   2b9b7:	c5 e1 6c d2          	vpunpcklqdq %xmm2,%xmm3,%xmm2
   2b9bb:	c4 a1 7a 7e 1c cb    	vmovq  (%rbx,%r9,8),%xmm3
   2b9c1:	c4 a1 7a 7e 24 c3    	vmovq  (%rbx,%r8,8),%xmm4
   2b9c7:	c5 d9 6c db          	vpunpcklqdq %xmm3,%xmm4,%xmm3
   2b9cb:	c4 e3 65 38 d2 01    	vinserti128 $0x1,%xmm2,%ymm3,%ymm2
   2b9d1:	c5 fa 7e 1c fb       	vmovq  (%rbx,%rdi,8),%xmm3
   2b9d6:	c5 fa 7e 24 f3       	vmovq  (%rbx,%rsi,8),%xmm4
   2b9db:	c5 d9 6c db          	vpunpcklqdq %xmm3,%xmm4,%xmm3
   2b9df:	c5 fa 7e 24 cb       	vmovq  (%rbx,%rcx,8),%xmm4
   2b9e4:	c5 fa 7e 2c c3       	vmovq  (%rbx,%rax,8),%xmm5
   2b9e9:	c5 d1 6c e4          	vpunpcklqdq %xmm4,%xmm5,%xmm4
   2b9ed:	c4 e3 5d 38 db 01    	vinserti128 $0x1,%xmm3,%ymm4,%ymm3
   2b9f3:	62 f3 e5 48 3a d2 01 	vinserti64x4 $0x1,%ymm2,%zmm3,%zmm2
   2b9fa:	62 f1 f5 58 58 1d 04 	vaddpd -0x253fc(%rip){1to8},%zmm1,%zmm3        # 6608 <anon.02ffda8f51e6076a26652e0a4fd6fa8d.746.llvm.5406940975955002095+0xa8>
   2ba01:	ac fd ff 
   2ba04:	62 f1 f5 48 73 f1 2a 	vpsllq $0x2a,%zmm1,%zmm1
   2ba0b:	62 f1 ed 48 d4 c9    	vpaddq %zmm1,%zmm2,%zmm1
   2ba11:	62 f1 e5 58 59 15 e5 	vmulpd -0x2551b(%rip){1to8},%zmm3,%zmm2        # 6500 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x320>
   2ba18:	aa fd ff 
   2ba1b:	62 f1 fd 48 58 c2    	vaddpd %zmm2,%zmm0,%zmm0
   2ba21:	62 f1 e5 58 59 15 7d 	vmulpd -0x25683(%rip){1to8},%zmm3,%zmm2        # 63a8 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x1c8>
   2ba28:	a9 fd ff 
   2ba2b:	62 f1 ed 48 58 c0    	vaddpd %zmm0,%zmm2,%zmm0
   2ba31:	62 f1 fd 48 59 d0    	vmulpd %zmm0,%zmm0,%zmm2
   2ba37:	62 f1 fd 58 59 1d a7 	vmulpd -0x25559(%rip){1to8},%zmm0,%zmm3        # 64e8 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x308>
   2ba3e:	aa fd ff 
   2ba41:	62 f1 e5 58 58 1d 9d 	vaddpd -0x25663(%rip){1to8},%zmm3,%zmm3        # 63e8 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x208>
   2ba48:	a9 fd ff 
   2ba4b:	62 f1 ed 48 59 d3    	vmulpd %zmm3,%zmm2,%zmm2
   2ba51:	62 f1 fd 48 58 c2    	vaddpd %zmm2,%zmm0,%zmm0
   2ba57:	62 f1 fd 58 58 05 cf 	vaddpd -0x25531(%rip){1to8},%zmm0,%zmm0        # 6530 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x350>
   2ba5e:	aa fd ff 
   2ba61:	62 f1 fd 48 59 c1    	vmulpd %zmm1,%zmm0,%zmm0
   2ba67:	62 f1 fd 48 11 02    	vmovupd %zmm0,(%rdx)
   2ba6d:	62 d1 fe 48 6f 45 00 	vmovdqu64 0x0(%r13),%zmm0
   2ba74:	62 f1 fd 58 db 0d aa 	vpandq -0x25556(%rip){1to8},%zmm0,%zmm1        # 6528 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x348>
   2ba7b:	aa fd ff 
   2ba7e:	62 f1 f5 58 c2 05 17 	vcmplt_oqpd -0x256e9(%rip){1to8},%zmm1,%k0        # 63a0 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x1c0>
   2ba85:	a9 fd ff 11 
   2ba89:	c5 f8 93 c0          	kmovw  %k0,%eax
   2ba8d:	3c ff                	cmp    $0xff,%al
   2ba8f:	0f 85 4f 01 00 00    	jne    2bbe4 <prod_exp_slice+0x604>
   2ba95:	62 f1 fd 58 59 0d 41 	vmulpd -0x253bf(%rip){1to8},%zmm0,%zmm1        # 66e0 <anon.02ffda8f51e6076a26652e0a4fd6fa8d.746.llvm.5406940975955002095+0x180>
   2ba9c:	ac fd ff 
   2ba9f:	62 f1 f5 58 58 0d 87 	vaddpd -0x25479(%rip){1to8},%zmm1,%zmm1        # 6630 <anon.02ffda8f51e6076a26652e0a4fd6fa8d.746.llvm.5406940975955002095+0xd0>
   2baa6:	ab fd ff 
   2baa9:	62 f1 f5 58 db 15 0d 	vpandq -0x256f3(%rip){1to8},%zmm1,%zmm2        # 63c0 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x1e0>
   2bab0:	a9 fd ff 
   2bab3:	c4 e1 f9 7e d0       	vmovq  %xmm2,%rax
   2bab8:	c4 e3 f9 16 d1 01    	vpextrq $0x1,%xmm2,%rcx
   2babe:	c4 e3 7d 39 d3 01    	vextracti128 $0x1,%ymm2,%xmm3
   2bac4:	c4 e1 f9 7e da       	vmovq  %xmm3,%rdx
   2bac9:	c4 e3 f9 16 de 01    	vpextrq $0x1,%xmm3,%rsi
   2bacf:	62 f3 7d 48 39 d3 02 	vextracti32x4 $0x2,%zmm2,%xmm3
   2bad6:	c4 e1 f9 7e df       	vmovq  %xmm3,%rdi
   2badb:	c4 c3 f9 16 d8 01    	vpextrq $0x1,%xmm3,%r8
   2bae1:	62 f3 7d 48 39 d2 03 	vextracti32x4 $0x3,%zmm2,%xmm2
   2bae8:	c4 c1 f9 7e d1       	vmovq  %xmm2,%r9
   2baed:	c4 c3 f9 16 d2 01    	vpextrq $0x1,%xmm2,%r10
   2baf3:	c4 a1 7a 7e 14 d3    	vmovq  (%rbx,%r10,8),%xmm2
   2baf9:	c4 a1 7a 7e 1c cb    	vmovq  (%rbx,%r9,8),%xmm3
   2baff:	c5 e1 6c d2          	vpunpcklqdq %xmm2,%xmm3,%xmm2
   2bb03:	c4 a1 7a 7e 1c c3    	vmovq  (%rbx,%r8,8),%xmm3
   2bb09:	c5 fa 7e 24 fb       	vmovq  (%rbx,%rdi,8),%xmm4
   2bb0e:	c5 d9 6c db          	vpunpcklqdq %xmm3,%xmm4,%xmm3
   2bb12:	c4 e3 65 38 d2 01    	vinserti128 $0x1,%xmm2,%ymm3,%ymm2
   2bb18:	c5 fa 7e 1c f3       	vmovq  (%rbx,%rsi,8),%xmm3
   2bb1d:	c5 fa 7e 24 d3       	vmovq  (%rbx,%rdx,8),%xmm4
   2bb22:	c5 d9 6c db          	vpunpcklqdq %xmm3,%xmm4,%xmm3
   2bb26:	c5 fa 7e 24 cb       	vmovq  (%rbx,%rcx,8),%xmm4
   2bb2b:	c5 fa 7e 2c c3       	vmovq  (%rbx,%rax,8),%xmm5
   2bb30:	c5 d1 6c e4          	vpunpcklqdq %xmm4,%xmm5,%xmm4
   2bb34:	c4 e3 5d 38 db 01    	vinserti128 $0x1,%xmm3,%ymm4,%ymm3
   2bb3a:	62 f3 e5 48 3a d2 01 	vinserti64x4 $0x1,%ymm2,%zmm3,%zmm2
   2bb41:	62 f1 f5 58 58 1d bd 	vaddpd -0x25543(%rip){1to8},%zmm1,%zmm3        # 6608 <anon.02ffda8f51e6076a26652e0a4fd6fa8d.746.llvm.5406940975955002095+0xa8>
   2bb48:	aa fd ff 
   2bb4b:	62 f1 f5 48 73 f1 2a 	vpsllq $0x2a,%zmm1,%zmm1
   2bb52:	62 f1 ed 48 d4 c9    	vpaddq %zmm1,%zmm2,%zmm1
   2bb58:	62 f1 e5 58 59 15 9e 	vmulpd -0x25662(%rip){1to8},%zmm3,%zmm2        # 6500 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x320>
   2bb5f:	a9 fd ff 
   2bb62:	62 f1 fd 48 58 c2    	vaddpd %zmm2,%zmm0,%zmm0
   2bb68:	62 f1 e5 58 59 15 36 	vmulpd -0x257ca(%rip){1to8},%zmm3,%zmm2        # 63a8 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x1c8>
   2bb6f:	a8 fd ff 
   2bb72:	62 f1 ed 48 58 c0    	vaddpd %zmm0,%zmm2,%zmm0
   2bb78:	62 f1 fd 48 59 d0    	vmulpd %zmm0,%zmm0,%zmm2
   2bb7e:	62 f1 fd 58 59 1d 60 	vmulpd -0x256a0(%rip){1to8},%zmm0,%zmm3        # 64e8 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x308>
   2bb85:	a9 fd ff 
   2bb88:	62 f1 e5 58 58 1d 56 	vaddpd -0x257aa(%rip){1to8},%zmm3,%zmm3        # 63e8 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x208>
   2bb8f:	a8 fd ff 
   2bb92:	62 f1 ed 48 59 d3    	vmulpd %zmm3,%zmm2,%zmm2
   2bb98:	62 f1 fd 48 58 c2    	vaddpd %zmm2,%zmm0,%zmm0
   2bb9e:	62 f1 fd 58 58 05 88 	vaddpd -0x25678(%rip){1to8},%zmm0,%zmm0        # 6530 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x350>
   2bba5:	a9 fd ff 
   2bba8:	62 f1 fd 48 59 c1    	vmulpd %zmm1,%zmm0,%zmm0
   2bbae:	62 d1 fd 48 11 04 24 	vmovupd %zmm0,(%r12)
   2bbb5:	49 83 ec 80          	sub    $0xffffffffffffff80,%r12
   2bbb9:	49 83 ed 80          	sub    $0xffffffffffffff80,%r13
   2bbbd:	48 ff cd             	dec    %rbp
   2bbc0:	0f 85 5a fd ff ff    	jne    2b920 <prod_exp_slice+0x340>
   2bbc6:	eb 37                	jmp    2bbff <prod_exp_slice+0x61f>
   2bbc8:	49 8d 7d c0          	lea    -0x40(%r13),%rdi
   2bbcc:	be 08 00 00 00       	mov    $0x8,%esi
   2bbd1:	b9 08 00 00 00       	mov    $0x8,%ecx
   2bbd6:	c5 f8 77             	vzeroupper
   2bbd9:	ff 15 41 00 06 00    	call   *0x60041(%rip)        # 8bc20 <_DYNAMIC+0x4f0>
   2bbdf:	e9 89 fe ff ff       	jmp    2ba6d <prod_exp_slice+0x48d>
   2bbe4:	be 08 00 00 00       	mov    $0x8,%esi
   2bbe9:	b9 08 00 00 00       	mov    $0x8,%ecx
   2bbee:	4c 89 ef             	mov    %r13,%rdi
   2bbf1:	4c 89 e2             	mov    %r12,%rdx
   2bbf4:	c5 f8 77             	vzeroupper
   2bbf7:	ff 15 23 00 06 00    	call   *0x60023(%rip)        # 8bc20 <_DYNAMIC+0x4f0>
   2bbfd:	eb b6                	jmp    2bbb5 <prod_exp_slice+0x5d5>
   2bbff:	4a 8d 04 fd 00 00 00 	lea    0x0(,%r15,8),%rax
   2bc06:	00 
   2bc07:	48 83 e0 80          	and    $0xffffffffffffff80,%rax
   2bc0b:	49 01 c6             	add    %rax,%r14
   2bc0e:	48 01 44 24 08       	add    %rax,0x8(%rsp)
   2bc13:	44 89 f8             	mov    %r15d,%eax
   2bc16:	83 e0 08             	and    $0x8,%eax
   2bc19:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
   2bc1e:	0f 85 e8 00 00 00    	jne    2bd0c <prod_exp_slice+0x72c>
   2bc24:	41 83 e7 07          	and    $0x7,%r15d
   2bc28:	48 8b 6c 24 08       	mov    0x8(%rsp),%rbp
   2bc2d:	0f 84 25 0a 00 00    	je     2c658 <prod_exp_slice+0x1078>
   2bc33:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
   2bc38:	c1 e0 03             	shl    $0x3,%eax
   2bc3b:	49 01 c6             	add    %rax,%r14
   2bc3e:	48 01 c5             	add    %rax,%rbp
   2bc41:	41 83 ff 02          	cmp    $0x2,%r15d
   2bc45:	0f 87 62 04 00 00    	ja     2c0ad <prod_exp_slice+0xacd>
   2bc4b:	31 db                	xor    %ebx,%ebx
   2bc4d:	4c 8d 25 74 bc fd ff 	lea    -0x2438c(%rip),%r12        # 78c8 <anon.ee651107ab5319c6bc273e1a29320aaf.386.llvm.14746981713632465754+0x1d4>
   2bc54:	4c 8b 2d cd ff 05 00 	mov    0x5ffcd(%rip),%r13        # 8bc28 <_DYNAMIC+0x4f8>
   2bc5b:	e9 84 00 00 00       	jmp    2bce4 <prod_exp_slice+0x704>
   2bc60:	c5 fb 59 0d 78 aa fd 	vmulsd -0x25588(%rip),%xmm0,%xmm1        # 66e0 <anon.02ffda8f51e6076a26652e0a4fd6fa8d.746.llvm.5406940975955002095+0x180>
   2bc67:	ff 
   2bc68:	c5 f3 58 0d c0 a9 fd 	vaddsd -0x25640(%rip),%xmm1,%xmm1        # 6630 <anon.02ffda8f51e6076a26652e0a4fd6fa8d.746.llvm.5406940975955002095+0xd0>
   2bc6f:	ff 
   2bc70:	c4 e1 f9 7e c8       	vmovq  %xmm1,%rax
   2bc75:	89 c1                	mov    %eax,%ecx
   2bc77:	81 e1 ff 03 00 00    	and    $0x3ff,%ecx
   2bc7d:	c5 f3 58 0d 83 a9 fd 	vaddsd -0x2567d(%rip),%xmm1,%xmm1        # 6608 <anon.02ffda8f51e6076a26652e0a4fd6fa8d.746.llvm.5406940975955002095+0xa8>
   2bc84:	ff 
   2bc85:	48 c1 e0 2a          	shl    $0x2a,%rax
   2bc89:	49 03 04 cc          	add    (%r12,%rcx,8),%rax
   2bc8d:	c4 e1 f9 6e d0       	vmovq  %rax,%xmm2
   2bc92:	c5 f3 59 1d 66 a8 fd 	vmulsd -0x2579a(%rip),%xmm1,%xmm3        # 6500 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x320>
   2bc99:	ff 
   2bc9a:	c5 fb 58 c3          	vaddsd %xmm3,%xmm0,%xmm0
   2bc9e:	c5 f3 59 0d 02 a7 fd 	vmulsd -0x258fe(%rip),%xmm1,%xmm1        # 63a8 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x1c8>
   2bca5:	ff 
   2bca6:	c5 f3 58 c0          	vaddsd %xmm0,%xmm1,%xmm0
   2bcaa:	c5 fb 59 c8          	vmulsd %xmm0,%xmm0,%xmm1
   2bcae:	c5 fb 59 1d 32 a8 fd 	vmulsd -0x257ce(%rip),%xmm0,%xmm3        # 64e8 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x308>
   2bcb5:	ff 
   2bcb6:	c5 e3 58 1d 2a a7 fd 	vaddsd -0x258d6(%rip),%xmm3,%xmm3        # 63e8 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x208>
   2bcbd:	ff 
   2bcbe:	c5 f3 59 cb          	vmulsd %xmm3,%xmm1,%xmm1
   2bcc2:	c5 fb 58 c1          	vaddsd %xmm1,%xmm0,%xmm0
   2bcc6:	c5 fb 58 05 62 a8 fd 	vaddsd -0x2579e(%rip),%xmm0,%xmm0        # 6530 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x350>
   2bccd:	ff 
   2bcce:	c5 fb 59 c2          	vmulsd %xmm2,%xmm0,%xmm0
   2bcd2:	c5 fb 11 44 dd 00    	vmovsd %xmm0,0x0(%rbp,%rbx,8)
   2bcd8:	48 ff c3             	inc    %rbx
   2bcdb:	49 39 df             	cmp    %rbx,%r15
   2bcde:	0f 84 74 09 00 00    	je     2c658 <prod_exp_slice+0x1078>
   2bce4:	c4 c1 7b 10 04 de    	vmovsd (%r14,%rbx,8),%xmm0
   2bcea:	c5 f9 54 0d 8e 9e fd 	vandpd -0x26172(%rip),%xmm0,%xmm1        # 5b80 <anon.06f69dd73d1c6fac5f9aa7f3913dfdf6.31.llvm.17030290209220970773+0x1f0>
   2bcf1:	ff 
   2bcf2:	c5 fb 10 15 a6 a6 fd 	vmovsd -0x2595a(%rip),%xmm2        # 63a0 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x1c0>
   2bcf9:	ff 
   2bcfa:	c5 f9 2e d1          	vucomisd %xmm1,%xmm2
   2bcfe:	0f 87 5c ff ff ff    	ja     2bc60 <prod_exp_slice+0x680>
   2bd04:	c5 f8 77             	vzeroupper
   2bd07:	41 ff d5             	call   *%r13
   2bd0a:	eb c6                	jmp    2bcd2 <prod_exp_slice+0x6f2>
   2bd0c:	44 89 fd             	mov    %r15d,%ebp
   2bd0f:	83 e5 08             	and    $0x8,%ebp
   2bd12:	48 f7 dd             	neg    %rbp
   2bd15:	48 8d 1d ac bb fd ff 	lea    -0x24454(%rip),%rbx        # 78c8 <anon.ee651107ab5319c6bc273e1a29320aaf.386.llvm.14746981713632465754+0x1d4>
   2bd1c:	4d 89 f4             	mov    %r14,%r12
   2bd1f:	4c 8b 6c 24 08       	mov    0x8(%rsp),%r13
   2bd24:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
   2bd2b:	00 00 00 00 00 
   2bd30:	62 d1 fe 48 6f 04 24 	vmovdqu64 (%r12),%zmm0
   2bd37:	62 f1 fd 58 db 0d e7 	vpandq -0x25819(%rip){1to8},%zmm0,%zmm1        # 6528 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x348>
   2bd3e:	a7 fd ff 
   2bd41:	62 f1 f5 58 c2 05 54 	vcmplt_oqpd -0x259ac(%rip){1to8},%zmm1,%k0        # 63a0 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x1c0>
   2bd48:	a6 fd ff 11 
   2bd4c:	c5 f8 93 c0          	kmovw  %k0,%eax
   2bd50:	3c ff                	cmp    $0xff,%al
   2bd52:	0f 85 37 01 00 00    	jne    2be8f <prod_exp_slice+0x8af>
   2bd58:	62 f1 fd 58 59 0d 7e 	vmulpd -0x25682(%rip){1to8},%zmm0,%zmm1        # 66e0 <anon.02ffda8f51e6076a26652e0a4fd6fa8d.746.llvm.5406940975955002095+0x180>
   2bd5f:	a9 fd ff 
   2bd62:	62 f1 f5 58 58 0d c4 	vaddpd -0x2573c(%rip){1to8},%zmm1,%zmm1        # 6630 <anon.02ffda8f51e6076a26652e0a4fd6fa8d.746.llvm.5406940975955002095+0xd0>
   2bd69:	a8 fd ff 
   2bd6c:	62 f1 f5 58 58 15 92 	vaddpd -0x2576e(%rip){1to8},%zmm1,%zmm2        # 6608 <anon.02ffda8f51e6076a26652e0a4fd6fa8d.746.llvm.5406940975955002095+0xa8>
   2bd73:	a8 fd ff 
   2bd76:	62 f1 f5 58 db 1d 40 	vpandq -0x259c0(%rip){1to8},%zmm1,%zmm3        # 63c0 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x1e0>
   2bd7d:	a6 fd ff 
   2bd80:	c4 e1 f9 7e d8       	vmovq  %xmm3,%rax
   2bd85:	c4 e3 f9 16 d9 01    	vpextrq $0x1,%xmm3,%rcx
   2bd8b:	c4 e3 7d 39 dc 01    	vextracti128 $0x1,%ymm3,%xmm4
   2bd91:	c4 e1 f9 7e e2       	vmovq  %xmm4,%rdx
   2bd96:	c4 e3 f9 16 e6 01    	vpextrq $0x1,%xmm4,%rsi
   2bd9c:	62 f3 7d 48 39 dc 02 	vextracti32x4 $0x2,%zmm3,%xmm4
   2bda3:	c4 e1 f9 7e e7       	vmovq  %xmm4,%rdi
   2bda8:	c4 c3 f9 16 e0 01    	vpextrq $0x1,%xmm4,%r8
   2bdae:	62 f3 7d 48 39 db 03 	vextracti32x4 $0x3,%zmm3,%xmm3
   2bdb5:	c4 c1 f9 7e d9       	vmovq  %xmm3,%r9
   2bdba:	c4 c3 f9 16 da 01    	vpextrq $0x1,%xmm3,%r10
   2bdc0:	c4 a1 7a 7e 1c d3    	vmovq  (%rbx,%r10,8),%xmm3
   2bdc6:	c4 a1 7a 7e 24 cb    	vmovq  (%rbx,%r9,8),%xmm4
   2bdcc:	c5 d9 6c db          	vpunpcklqdq %xmm3,%xmm4,%xmm3
   2bdd0:	c4 a1 7a 7e 24 c3    	vmovq  (%rbx,%r8,8),%xmm4
   2bdd6:	c5 fa 7e 2c fb       	vmovq  (%rbx,%rdi,8),%xmm5
   2bddb:	c5 d1 6c e4          	vpunpcklqdq %xmm4,%xmm5,%xmm4
   2bddf:	c4 e3 5d 38 db 01    	vinserti128 $0x1,%xmm3,%ymm4,%ymm3
   2bde5:	c5 fa 7e 24 f3       	vmovq  (%rbx,%rsi,8),%xmm4
   2bdea:	c5 fa 7e 2c d3       	vmovq  (%rbx,%rdx,8),%xmm5
   2bdef:	c5 d1 6c e4          	vpunpcklqdq %xmm4,%xmm5,%xmm4
   2bdf3:	c5 fa 7e 2c cb       	vmovq  (%rbx,%rcx,8),%xmm5
   2bdf8:	c5 fa 7e 34 c3       	vmovq  (%rbx,%rax,8),%xmm6
   2bdfd:	c5 c9 6c ed          	vpunpcklqdq %xmm5,%xmm6,%xmm5
   2be01:	c4 e3 55 38 e4 01    	vinserti128 $0x1,%xmm4,%ymm5,%ymm4
   2be07:	62 f3 dd 48 3a db 01 	vinserti64x4 $0x1,%ymm3,%zmm4,%zmm3
   2be0e:	62 f1 f5 48 73 f1 2a 	vpsllq $0x2a,%zmm1,%zmm1
   2be15:	62 f1 e5 48 d4 c9    	vpaddq %zmm1,%zmm3,%zmm1
   2be1b:	62 f1 ed 58 59 1d db 	vmulpd -0x25925(%rip){1to8},%zmm2,%zmm3        # 6500 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x320>
   2be22:	a6 fd ff 
   2be25:	62 f1 fd 48 58 c3    	vaddpd %zmm3,%zmm0,%zmm0
   2be2b:	62 f1 ed 58 59 15 73 	vmulpd -0x25a8d(%rip){1to8},%zmm2,%zmm2        # 63a8 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x1c8>
   2be32:	a5 fd ff 
   2be35:	62 f1 ed 48 58 c0    	vaddpd %zmm0,%zmm2,%zmm0
   2be3b:	62 f1 fd 48 59 d0    	vmulpd %zmm0,%zmm0,%zmm2
   2be41:	62 f1 fd 58 59 1d 9d 	vmulpd -0x25963(%rip){1to8},%zmm0,%zmm3        # 64e8 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x308>
   2be48:	a6 fd ff 
   2be4b:	62 f1 e5 58 58 1d 93 	vaddpd -0x25a6d(%rip){1to8},%zmm3,%zmm3        # 63e8 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x208>
   2be52:	a5 fd ff 
   2be55:	62 f1 ed 48 59 d3    	vmulpd %zmm3,%zmm2,%zmm2
   2be5b:	62 f1 fd 48 58 c2    	vaddpd %zmm2,%zmm0,%zmm0
   2be61:	62 f1 fd 58 58 05 c5 	vaddpd -0x2593b(%rip){1to8},%zmm0,%zmm0        # 6530 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x350>
   2be68:	a6 fd ff 
   2be6b:	62 f1 fd 48 59 c1    	vmulpd %zmm1,%zmm0,%zmm0
   2be71:	62 d1 fd 48 11 45 00 	vmovupd %zmm0,0x0(%r13)
   2be78:	49 83 c4 40          	add    $0x40,%r12
   2be7c:	49 83 c5 40          	add    $0x40,%r13
   2be80:	48 83 c5 08          	add    $0x8,%rbp
   2be84:	0f 85 a6 fe ff ff    	jne    2bd30 <prod_exp_slice+0x750>
   2be8a:	e9 95 fd ff ff       	jmp    2bc24 <prod_exp_slice+0x644>
   2be8f:	be 08 00 00 00       	mov    $0x8,%esi
   2be94:	b9 08 00 00 00       	mov    $0x8,%ecx
   2be99:	4c 89 e7             	mov    %r12,%rdi
   2be9c:	4c 89 ea             	mov    %r13,%rdx
   2be9f:	c5 f8 77             	vzeroupper
   2bea2:	ff 15 78 fd 05 00    	call   *0x5fd78(%rip)        # 8bc20 <_DYNAMIC+0x4f0>
   2bea8:	eb ce                	jmp    2be78 <prod_exp_slice+0x898>
   2beaa:	f3 49 0f bc c7       	tzcnt  %r15,%rax
   2beaf:	48 83 f8 02          	cmp    $0x2,%rax
   2beb3:	0f 84 4e 06 00 00    	je     2c507 <prod_exp_slice+0xf27>
   2beb9:	83 f8 01             	cmp    $0x1,%eax
   2bebc:	0f 84 4c 08 00 00    	je     2c70e <prod_exp_slice+0x112e>
   2bec2:	c4 c1 7d 10 06       	vmovupd (%r14),%ymm0
   2bec7:	c4 e2 7d 19 0d 58 a6 	vbroadcastsd -0x259a8(%rip),%ymm1        # 6528 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x348>
   2bece:	fd ff 
   2bed0:	c5 fd 54 c9          	vandpd %ymm1,%ymm0,%ymm1
   2bed4:	c4 e2 7d 19 15 c3 a4 	vbroadcastsd -0x25b3d(%rip),%ymm2        # 63a0 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x1c0>
   2bedb:	fd ff 
   2bedd:	c5 f5 c2 ca 11       	vcmplt_oqpd %ymm2,%ymm1,%ymm1
   2bee2:	c5 ed 76 d2          	vpcmpeqd %ymm2,%ymm2,%ymm2
   2bee6:	62 f2 f5 48 37 c2    	vpcmpgtq %zmm2,%zmm1,%k0
   2beec:	c5 f8 93 c0          	kmovw  %k0,%eax
   2bef0:	a8 0f                	test   $0xf,%al
   2bef2:	0f 85 72 07 00 00    	jne    2c66a <prod_exp_slice+0x108a>
   2bef8:	c4 e2 7d 19 0d df a7 	vbroadcastsd -0x25821(%rip),%ymm1        # 66e0 <anon.02ffda8f51e6076a26652e0a4fd6fa8d.746.llvm.5406940975955002095+0x180>
   2beff:	fd ff 
   2bf01:	c5 fd 59 c9          	vmulpd %ymm1,%ymm0,%ymm1
   2bf05:	c4 e2 7d 19 15 22 a7 	vbroadcastsd -0x258de(%rip),%ymm2        # 6630 <anon.02ffda8f51e6076a26652e0a4fd6fa8d.746.llvm.5406940975955002095+0xd0>
   2bf0c:	fd ff 
   2bf0e:	c4 e2 7d 19 1d a9 a4 	vbroadcastsd -0x25b57(%rip),%ymm3        # 63c0 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x1e0>
   2bf15:	fd ff 
   2bf17:	c5 f5 58 ca          	vaddpd %ymm2,%ymm1,%ymm1
   2bf1b:	c5 f5 54 d3          	vandpd %ymm3,%ymm1,%ymm2
   2bf1f:	c4 e1 f9 7e d0       	vmovq  %xmm2,%rax
   2bf24:	48 8d 0d 9d b9 fd ff 	lea    -0x24663(%rip),%rcx        # 78c8 <anon.ee651107ab5319c6bc273e1a29320aaf.386.llvm.14746981713632465754+0x1d4>
   2bf2b:	c4 e3 f9 16 d2 01    	vpextrq $0x1,%xmm2,%rdx
   2bf31:	c4 e3 7d 39 d2 01    	vextracti128 $0x1,%ymm2,%xmm2
   2bf37:	c4 e1 f9 7e d6       	vmovq  %xmm2,%rsi
   2bf3c:	c4 e3 f9 16 d7 01    	vpextrq $0x1,%xmm2,%rdi
   2bf42:	c5 fa 7e 14 f9       	vmovq  (%rcx,%rdi,8),%xmm2
   2bf47:	c5 fa 7e 1c f1       	vmovq  (%rcx,%rsi,8),%xmm3
   2bf4c:	c5 e1 6c d2          	vpunpcklqdq %xmm2,%xmm3,%xmm2
   2bf50:	c5 fa 7e 1c d1       	vmovq  (%rcx,%rdx,8),%xmm3
   2bf55:	c5 fa 7e 24 c1       	vmovq  (%rcx,%rax,8),%xmm4
   2bf5a:	c5 d9 6c db          	vpunpcklqdq %xmm3,%xmm4,%xmm3
   2bf5e:	c4 e3 65 38 d2 01    	vinserti128 $0x1,%xmm2,%ymm3,%ymm2
   2bf64:	c4 e2 7d 19 1d 9b a6 	vbroadcastsd -0x25965(%rip),%ymm3        # 6608 <anon.02ffda8f51e6076a26652e0a4fd6fa8d.746.llvm.5406940975955002095+0xa8>
   2bf6b:	fd ff 
   2bf6d:	c5 f5 58 db          	vaddpd %ymm3,%ymm1,%ymm3
   2bf71:	c5 f5 73 f1 2a       	vpsllq $0x2a,%ymm1,%ymm1
   2bf76:	c5 ed d4 c9          	vpaddq %ymm1,%ymm2,%ymm1
   2bf7a:	c4 e2 7d 19 15 7d a5 	vbroadcastsd -0x25a83(%rip),%ymm2        # 6500 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x320>
   2bf81:	fd ff 
   2bf83:	c5 e5 59 d2          	vmulpd %ymm2,%ymm3,%ymm2
   2bf87:	c5 fd 58 c2          	vaddpd %ymm2,%ymm0,%ymm0
   2bf8b:	c4 e2 7d 19 15 14 a4 	vbroadcastsd -0x25bec(%rip),%ymm2        # 63a8 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x1c8>
   2bf92:	fd ff 
   2bf94:	c5 e5 59 d2          	vmulpd %ymm2,%ymm3,%ymm2
   2bf98:	c5 ed 58 c0          	vaddpd %ymm0,%ymm2,%ymm0
   2bf9c:	c4 e2 7d 19 15 43 a5 	vbroadcastsd -0x25abd(%rip),%ymm2        # 64e8 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x308>
   2bfa3:	fd ff 
   2bfa5:	c5 fd 59 d8          	vmulpd %ymm0,%ymm0,%ymm3
   2bfa9:	c5 fd 59 d2          	vmulpd %ymm2,%ymm0,%ymm2
   2bfad:	c4 e2 7d 19 25 32 a4 	vbroadcastsd -0x25bce(%rip),%ymm4        # 63e8 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x208>
   2bfb4:	fd ff 
   2bfb6:	c5 ed 58 d4          	vaddpd %ymm4,%ymm2,%ymm2
   2bfba:	c5 e5 59 d2          	vmulpd %ymm2,%ymm3,%ymm2
   2bfbe:	c4 e2 7d 19 1d 69 a5 	vbroadcastsd -0x25a97(%rip),%ymm3        # 6530 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x350>
   2bfc5:	fd ff 
   2bfc7:	c5 fd 58 c2          	vaddpd %ymm2,%ymm0,%ymm0
   2bfcb:	c5 fd 58 c3          	vaddpd %ymm3,%ymm0,%ymm0
   2bfcf:	c5 fd 59 c1          	vmulpd %ymm1,%ymm0,%ymm0
   2bfd3:	c5 fd 11 45 00       	vmovupd %ymm0,0x0(%rbp)
   2bfd8:	41 83 e7 03          	and    $0x3,%r15d
   2bfdc:	0f 84 76 06 00 00    	je     2c658 <prod_exp_slice+0x1078>
   2bfe2:	31 db                	xor    %ebx,%ebx
   2bfe4:	4c 8d 25 dd b8 fd ff 	lea    -0x24723(%rip),%r12        # 78c8 <anon.ee651107ab5319c6bc273e1a29320aaf.386.llvm.14746981713632465754+0x1d4>
   2bfeb:	4c 8b 2d 36 fc 05 00 	mov    0x5fc36(%rip),%r13        # 8bc28 <_DYNAMIC+0x4f8>
   2bff2:	e9 8d 00 00 00       	jmp    2c084 <prod_exp_slice+0xaa4>
   2bff7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
   2bffe:	00 00 
   2c000:	c5 fb 59 0d d8 a6 fd 	vmulsd -0x25928(%rip),%xmm0,%xmm1        # 66e0 <anon.02ffda8f51e6076a26652e0a4fd6fa8d.746.llvm.5406940975955002095+0x180>
   2c007:	ff 
   2c008:	c5 f3 58 0d 20 a6 fd 	vaddsd -0x259e0(%rip),%xmm1,%xmm1        # 6630 <anon.02ffda8f51e6076a26652e0a4fd6fa8d.746.llvm.5406940975955002095+0xd0>
   2c00f:	ff 
   2c010:	c4 e1 f9 7e c8       	vmovq  %xmm1,%rax
   2c015:	89 c1                	mov    %eax,%ecx
   2c017:	81 e1 ff 03 00 00    	and    $0x3ff,%ecx
   2c01d:	c5 f3 58 0d e3 a5 fd 	vaddsd -0x25a1d(%rip),%xmm1,%xmm1        # 6608 <anon.02ffda8f51e6076a26652e0a4fd6fa8d.746.llvm.5406940975955002095+0xa8>
   2c024:	ff 
   2c025:	48 c1 e0 2a          	shl    $0x2a,%rax
   2c029:	49 03 04 cc          	add    (%r12,%rcx,8),%rax
   2c02d:	c4 e1 f9 6e d0       	vmovq  %rax,%xmm2
   2c032:	c5 f3 59 1d c6 a4 fd 	vmulsd -0x25b3a(%rip),%xmm1,%xmm3        # 6500 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x320>
   2c039:	ff 
   2c03a:	c5 fb 58 c3          	vaddsd %xmm3,%xmm0,%xmm0
   2c03e:	c5 f3 59 0d 62 a3 fd 	vmulsd -0x25c9e(%rip),%xmm1,%xmm1        # 63a8 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x1c8>
   2c045:	ff 
   2c046:	c5 f3 58 c0          	vaddsd %xmm0,%xmm1,%xmm0
   2c04a:	c5 fb 59 c8          	vmulsd %xmm0,%xmm0,%xmm1
   2c04e:	c5 fb 59 1d 92 a4 fd 	vmulsd -0x25b6e(%rip),%xmm0,%xmm3        # 64e8 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x308>
   2c055:	ff 
   2c056:	c5 e3 58 1d 8a a3 fd 	vaddsd -0x25c76(%rip),%xmm3,%xmm3        # 63e8 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x208>
   2c05d:	ff 
   2c05e:	c5 f3 59 cb          	vmulsd %xmm3,%xmm1,%xmm1
   2c062:	c5 fb 58 c1          	vaddsd %xmm1,%xmm0,%xmm0
   2c066:	c5 fb 58 05 c2 a4 fd 	vaddsd -0x25b3e(%rip),%xmm0,%xmm0        # 6530 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x350>
   2c06d:	ff 
   2c06e:	c5 fb 59 c2          	vmulsd %xmm2,%xmm0,%xmm0
   2c072:	c5 fb 11 44 dd 20    	vmovsd %xmm0,0x20(%rbp,%rbx,8)
   2c078:	48 ff c3             	inc    %rbx
   2c07b:	49 39 df             	cmp    %rbx,%r15
   2c07e:	0f 84 d4 05 00 00    	je     2c658 <prod_exp_slice+0x1078>
   2c084:	c4 c1 7b 10 44 de 20 	vmovsd 0x20(%r14,%rbx,8),%xmm0
   2c08b:	c5 f9 54 0d ed 9a fd 	vandpd -0x26513(%rip),%xmm0,%xmm1        # 5b80 <anon.06f69dd73d1c6fac5f9aa7f3913dfdf6.31.llvm.17030290209220970773+0x1f0>
   2c092:	ff 
   2c093:	c5 fb 10 15 05 a3 fd 	vmovsd -0x25cfb(%rip),%xmm2        # 63a0 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x1c0>
   2c09a:	ff 
   2c09b:	c5 f9 2e d1          	vucomisd %xmm1,%xmm2
   2c09f:	0f 87 5b ff ff ff    	ja     2c000 <prod_exp_slice+0xa20>
   2c0a5:	c5 f8 77             	vzeroupper
   2c0a8:	41 ff d5             	call   *%r13
   2c0ab:	eb c5                	jmp    2c072 <prod_exp_slice+0xa92>
   2c0ad:	b0 ff                	mov    $0xff,%al
   2c0af:	44 89 f9             	mov    %r15d,%ecx
   2c0b2:	d2 e0                	shl    %cl,%al
   2c0b4:	f6 d0                	not    %al
   2c0b6:	c5 f8 92 c8          	kmovw  %eax,%k1
   2c0ba:	62 d1 fd c9 10 06    	vmovupd (%r14),%zmm0{%k1}{z}
   2c0c0:	62 f1 fd 58 db 0d 5e 	vpandq -0x25ba2(%rip){1to8},%zmm0,%zmm1        # 6528 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x348>
   2c0c7:	a4 fd ff 
   2c0ca:	62 f1 f5 58 c2 05 cb 	vcmplt_oqpd -0x25d35(%rip){1to8},%zmm1,%k0        # 63a0 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x1c0>
   2c0d1:	a2 fd ff 11 
   2c0d5:	c5 f8 93 c0          	kmovw  %k0,%eax
   2c0d9:	3c ff                	cmp    $0xff,%al
   2c0db:	0f 85 a7 05 00 00    	jne    2c688 <prod_exp_slice+0x10a8>
   2c0e1:	62 f1 fd 58 59 0d f5 	vmulpd -0x25a0b(%rip){1to8},%zmm0,%zmm1        # 66e0 <anon.02ffda8f51e6076a26652e0a4fd6fa8d.746.llvm.5406940975955002095+0x180>
   2c0e8:	a5 fd ff 
   2c0eb:	62 f1 f5 58 58 0d 3b 	vaddpd -0x25ac5(%rip){1to8},%zmm1,%zmm1        # 6630 <anon.02ffda8f51e6076a26652e0a4fd6fa8d.746.llvm.5406940975955002095+0xd0>
   2c0f2:	a5 fd ff 
   2c0f5:	62 f1 f5 58 58 15 09 	vaddpd -0x25af7(%rip){1to8},%zmm1,%zmm2        # 6608 <anon.02ffda8f51e6076a26652e0a4fd6fa8d.746.llvm.5406940975955002095+0xa8>
   2c0fc:	a5 fd ff 
   2c0ff:	62 f1 f5 58 db 1d b7 	vpandq -0x25d49(%rip){1to8},%zmm1,%zmm3        # 63c0 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x1e0>
   2c106:	a2 fd ff 
   2c109:	c4 e1 f9 7e d8       	vmovq  %xmm3,%rax
   2c10e:	48 8d 0d b3 b7 fd ff 	lea    -0x2484d(%rip),%rcx        # 78c8 <anon.ee651107ab5319c6bc273e1a29320aaf.386.llvm.14746981713632465754+0x1d4>
   2c115:	c4 e3 f9 16 da 01    	vpextrq $0x1,%xmm3,%rdx
   2c11b:	c4 e3 7d 39 dc 01    	vextracti128 $0x1,%ymm3,%xmm4
   2c121:	c4 e1 f9 7e e6       	vmovq  %xmm4,%rsi
   2c126:	c4 e3 f9 16 e7 01    	vpextrq $0x1,%xmm4,%rdi
   2c12c:	62 f3 7d 48 39 dc 02 	vextracti32x4 $0x2,%zmm3,%xmm4
   2c133:	c4 c1 f9 7e e0       	vmovq  %xmm4,%r8
   2c138:	c4 c3 f9 16 e1 01    	vpextrq $0x1,%xmm4,%r9
   2c13e:	62 f3 7d 48 39 db 03 	vextracti32x4 $0x3,%zmm3,%xmm3
   2c145:	c4 c1 f9 7e da       	vmovq  %xmm3,%r10
   2c14a:	c4 c3 f9 16 db 01    	vpextrq $0x1,%xmm3,%r11
   2c150:	c4 a1 7a 7e 1c d9    	vmovq  (%rcx,%r11,8),%xmm3
   2c156:	c4 a1 7a 7e 24 d1    	vmovq  (%rcx,%r10,8),%xmm4
   2c15c:	c5 d9 6c db          	vpunpcklqdq %xmm3,%xmm4,%xmm3
   2c160:	c4 a1 7a 7e 24 c9    	vmovq  (%rcx,%r9,8),%xmm4
   2c166:	c4 a1 7a 7e 2c c1    	vmovq  (%rcx,%r8,8),%xmm5
   2c16c:	c5 d1 6c e4          	vpunpcklqdq %xmm4,%xmm5,%xmm4
   2c170:	c4 e3 5d 38 db 01    	vinserti128 $0x1,%xmm3,%ymm4,%ymm3
   2c176:	c5 fa 7e 24 f9       	vmovq  (%rcx,%rdi,8),%xmm4
   2c17b:	c5 fa 7e 2c f1       	vmovq  (%rcx,%rsi,8),%xmm5
   2c180:	c5 d1 6c e4          	vpunpcklqdq %xmm4,%xmm5,%xmm4
   2c184:	c5 fa 7e 2c d1       	vmovq  (%rcx,%rdx,8),%xmm5
   2c189:	c5 fa 7e 34 c1       	vmovq  (%rcx,%rax,8),%xmm6
   2c18e:	c5 c9 6c ed          	vpunpcklqdq %xmm5,%xmm6,%xmm5
   2c192:	c4 e3 55 38 e4 01    	vinserti128 $0x1,%xmm4,%ymm5,%ymm4
   2c198:	62 f3 dd 48 3a db 01 	vinserti64x4 $0x1,%ymm3,%zmm4,%zmm3
   2c19f:	62 f1 f5 48 73 f1 2a 	vpsllq $0x2a,%zmm1,%zmm1
   2c1a6:	62 f1 ed 58 59 25 50 	vmulpd -0x25cb0(%rip){1to8},%zmm2,%zmm4        # 6500 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x320>
   2c1ad:	a3 fd ff 
   2c1b0:	62 f1 e5 48 d4 c9    	vpaddq %zmm1,%zmm3,%zmm1
   2c1b6:	62 f1 fd 48 58 c4    	vaddpd %zmm4,%zmm0,%zmm0
   2c1bc:	62 f1 ed 58 59 15 e2 	vmulpd -0x25e1e(%rip){1to8},%zmm2,%zmm2        # 63a8 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x1c8>
   2c1c3:	a1 fd ff 
   2c1c6:	62 f1 ed 48 58 c0    	vaddpd %zmm0,%zmm2,%zmm0
   2c1cc:	62 f1 fd 48 59 d0    	vmulpd %zmm0,%zmm0,%zmm2
   2c1d2:	62 f1 fd 58 59 1d 0c 	vmulpd -0x25cf4(%rip){1to8},%zmm0,%zmm3        # 64e8 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x308>
   2c1d9:	a3 fd ff 
   2c1dc:	62 f1 e5 58 58 1d 02 	vaddpd -0x25dfe(%rip){1to8},%zmm3,%zmm3        # 63e8 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x208>
   2c1e3:	a2 fd ff 
   2c1e6:	62 f1 ed 48 59 d3    	vmulpd %zmm3,%zmm2,%zmm2
   2c1ec:	62 f1 fd 48 58 c2    	vaddpd %zmm2,%zmm0,%zmm0
   2c1f2:	62 f1 fd 58 58 05 34 	vaddpd -0x25ccc(%rip){1to8},%zmm0,%zmm0        # 6530 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x350>
   2c1f9:	a3 fd ff 
   2c1fc:	62 f1 fd 48 59 c1    	vmulpd %zmm1,%zmm0,%zmm0
   2c202:	62 f1 fd 49 11 45 00 	vmovupd %zmm0,0x0(%rbp){%k1}
   2c209:	e9 4a 04 00 00       	jmp    2c658 <prod_exp_slice+0x1078>
   2c20e:	49 83 ff 20          	cmp    $0x20,%r15
   2c212:	0f 85 75 04 00 00    	jne    2c68d <prod_exp_slice+0x10ad>
   2c218:	4c 89 f7             	mov    %r14,%rdi
   2c21b:	48 89 ee             	mov    %rbp,%rsi
   2c21e:	e8 8d d1 ff ff       	call   293b0 <morphiq_numerics_arch::x86_64::avx512_run::<morphiq_numerics::exp::bounded::Packet<32>>>
   2c223:	e9 30 04 00 00       	jmp    2c658 <prod_exp_slice+0x1078>
   2c228:	49 83 ff 40          	cmp    $0x40,%r15
   2c22c:	0f 85 64 04 00 00    	jne    2c696 <prod_exp_slice+0x10b6>
   2c232:	4c 89 f7             	mov    %r14,%rdi
   2c235:	48 89 ee             	mov    %rbp,%rsi
   2c238:	e8 83 d6 ff ff       	call   298c0 <morphiq_numerics_arch::x86_64::avx512_run::<morphiq_numerics::exp::bounded::Packet<64>>>
   2c23d:	e9 16 04 00 00       	jmp    2c658 <prod_exp_slice+0x1078>
   2c242:	49 83 ff 10          	cmp    $0x10,%r15
   2c246:	0f 85 53 04 00 00    	jne    2c69f <prod_exp_slice+0x10bf>
   2c24c:	62 f2 fd 48 19 15 4a 	vbroadcastsd -0x25eb6(%rip),%zmm2        # 63a0 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x1c0>
   2c253:	a1 fd ff 
   2c256:	c5 f9 57 c0          	vxorpd %xmm0,%xmm0,%xmm0
   2c25a:	62 f1 fd 48 c2 c2 11 	vcmplt_oqpd %zmm2,%zmm0,%k0
   2c261:	62 d1 fe 48 6f 0e    	vmovdqu64 (%r14),%zmm1
   2c267:	62 d1 fe 48 6f 46 01 	vmovdqu64 0x40(%r14),%zmm0
   2c26e:	62 f2 fd 48 59 1d b0 	vpbroadcastq -0x25d50(%rip),%zmm3        # 6528 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x348>
   2c275:	a2 fd ff 
   2c278:	62 f1 f5 48 db e3    	vpandq %zmm3,%zmm1,%zmm4
   2c27e:	62 f1 dd 48 c2 ca 11 	vcmplt_oqpd %zmm2,%zmm4,%k1
   2c285:	c5 fc 41 c1          	kandw  %k1,%k0,%k0
   2c289:	62 f1 fd 48 db db    	vpandq %zmm3,%zmm0,%zmm3
   2c28f:	62 f1 e5 48 c2 ca 11 	vcmplt_oqpd %zmm2,%zmm3,%k1
   2c296:	c5 fc 41 c1          	kandw  %k1,%k0,%k0
   2c29a:	c5 f8 93 c0          	kmovw  %k0,%eax
   2c29e:	3c ff                	cmp    $0xff,%al
   2c2a0:	0f 85 16 04 00 00    	jne    2c6bc <prod_exp_slice+0x10dc>
   2c2a6:	62 f2 fd 48 19 15 30 	vbroadcastsd -0x25bd0(%rip),%zmm2        # 66e0 <anon.02ffda8f51e6076a26652e0a4fd6fa8d.746.llvm.5406940975955002095+0x180>
   2c2ad:	a4 fd ff 
   2c2b0:	62 f1 f5 48 59 da    	vmulpd %zmm2,%zmm1,%zmm3
   2c2b6:	62 f2 fd 48 19 25 70 	vbroadcastsd -0x25c90(%rip),%zmm4        # 6630 <anon.02ffda8f51e6076a26652e0a4fd6fa8d.746.llvm.5406940975955002095+0xd0>
   2c2bd:	a3 fd ff 
   2c2c0:	62 f2 fd 48 59 2d f6 	vpbroadcastq -0x25f0a(%rip),%zmm5        # 63c0 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x1e0>
   2c2c7:	a0 fd ff 
   2c2ca:	62 f1 e5 48 58 dc    	vaddpd %zmm4,%zmm3,%zmm3
   2c2d0:	62 f1 e5 48 db f5    	vpandq %zmm5,%zmm3,%zmm6
   2c2d6:	c4 e1 f9 7e f1       	vmovq  %xmm6,%rcx
   2c2db:	48 8d 05 e6 b5 fd ff 	lea    -0x24a1a(%rip),%rax        # 78c8 <anon.ee651107ab5319c6bc273e1a29320aaf.386.llvm.14746981713632465754+0x1d4>
   2c2e2:	c4 e3 f9 16 f2 01    	vpextrq $0x1,%xmm6,%rdx
   2c2e8:	c4 e3 7d 39 f7 01    	vextracti128 $0x1,%ymm6,%xmm7
   2c2ee:	c4 e1 f9 7e fe       	vmovq  %xmm7,%rsi
   2c2f3:	c4 e3 f9 16 ff 01    	vpextrq $0x1,%xmm7,%rdi
   2c2f9:	62 f3 7d 48 39 f7 02 	vextracti32x4 $0x2,%zmm6,%xmm7
   2c300:	c4 c1 f9 7e f8       	vmovq  %xmm7,%r8
   2c305:	c4 c3 f9 16 f9 01    	vpextrq $0x1,%xmm7,%r9
   2c30b:	62 f3 7d 48 39 f6 03 	vextracti32x4 $0x3,%zmm6,%xmm6
   2c312:	c4 c1 f9 7e f2       	vmovq  %xmm6,%r10
   2c317:	c4 c3 f9 16 f3 01    	vpextrq $0x1,%xmm6,%r11
   2c31d:	c4 a1 7a 7e 34 d8    	vmovq  (%rax,%r11,8),%xmm6
   2c323:	c4 a1 7a 7e 3c d0    	vmovq  (%rax,%r10,8),%xmm7
   2c329:	c5 c1 6c f6          	vpunpcklqdq %xmm6,%xmm7,%xmm6
   2c32d:	c4 a1 7a 7e 3c c8    	vmovq  (%rax,%r9,8),%xmm7
   2c333:	c4 21 7a 7e 04 c0    	vmovq  (%rax,%r8,8),%xmm8
   2c339:	c5 b9 6c ff          	vpunpcklqdq %xmm7,%xmm8,%xmm7
   2c33d:	c4 e3 45 38 f6 01    	vinserti128 $0x1,%xmm6,%ymm7,%ymm6
   2c343:	c5 fa 7e 3c f8       	vmovq  (%rax,%rdi,8),%xmm7
   2c348:	c5 7a 7e 04 f0       	vmovq  (%rax,%rsi,8),%xmm8
   2c34d:	c5 b9 6c ff          	vpunpcklqdq %xmm7,%xmm8,%xmm7
   2c351:	c5 7a 7e 04 d0       	vmovq  (%rax,%rdx,8),%xmm8
   2c356:	c5 7a 7e 0c c8       	vmovq  (%rax,%rcx,8),%xmm9
   2c35b:	c4 41 31 6c c0       	vpunpcklqdq %xmm8,%xmm9,%xmm8
   2c360:	c4 e3 3d 38 ff 01    	vinserti128 $0x1,%xmm7,%ymm8,%ymm7
   2c366:	62 f3 c5 48 3a f6 01 	vinserti64x4 $0x1,%ymm6,%zmm7,%zmm6
   2c36d:	62 f2 fd 48 19 3d 91 	vbroadcastsd -0x25d6f(%rip),%zmm7        # 6608 <anon.02ffda8f51e6076a26652e0a4fd6fa8d.746.llvm.5406940975955002095+0xa8>
   2c374:	a2 fd ff 
   2c377:	62 71 e5 48 58 c7    	vaddpd %zmm7,%zmm3,%zmm8
   2c37d:	62 f1 e5 48 73 f3 2a 	vpsllq $0x2a,%zmm3,%zmm3
   2c384:	62 f1 cd 48 d4 db    	vpaddq %zmm3,%zmm6,%zmm3
   2c38a:	62 f2 fd 48 19 35 04 	vbroadcastsd -0x25bfc(%rip),%zmm6        # 6798 <anon.02ffda8f51e6076a26652e0a4fd6fa8d.746.llvm.5406940975955002095+0x238>
   2c391:	a4 fd ff 
   2c394:	62 71 bd 48 59 ce    	vmulpd %zmm6,%zmm8,%zmm9
   2c39a:	62 d1 f5 48 5c c9    	vsubpd %zmm9,%zmm1,%zmm1
   2c3a0:	62 72 fd 48 19 0d fe 	vbroadcastsd -0x26002(%rip),%zmm9        # 63a8 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x1c8>
   2c3a7:	9f fd ff 
   2c3aa:	62 51 bd 48 59 c1    	vmulpd %zmm9,%zmm8,%zmm8
   2c3b0:	62 f1 bd 48 58 c9    	vaddpd %zmm1,%zmm8,%zmm1
   2c3b6:	62 72 fd 48 19 05 28 	vbroadcastsd -0x25ed8(%rip),%zmm8        # 64e8 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x308>
   2c3bd:	a1 fd ff 
   2c3c0:	62 71 f5 48 59 d1    	vmulpd %zmm1,%zmm1,%zmm10
   2c3c6:	62 51 f5 48 59 d8    	vmulpd %zmm8,%zmm1,%zmm11
   2c3cc:	62 72 fd 48 19 25 12 	vbroadcastsd -0x25fee(%rip),%zmm12        # 63e8 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x208>
   2c3d3:	a0 fd ff 
   2c3d6:	62 51 a5 48 58 dc    	vaddpd %zmm12,%zmm11,%zmm11
   2c3dc:	62 51 ad 48 59 d3    	vmulpd %zmm11,%zmm10,%zmm10
   2c3e2:	62 72 fd 48 19 1d 44 	vbroadcastsd -0x25ebc(%rip),%zmm11        # 6530 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x350>
   2c3e9:	a1 fd ff 
   2c3ec:	62 d1 f5 48 58 ca    	vaddpd %zmm10,%zmm1,%zmm1
   2c3f2:	62 d1 f5 48 58 cb    	vaddpd %zmm11,%zmm1,%zmm1
   2c3f8:	62 f1 f5 48 59 cb    	vmulpd %zmm3,%zmm1,%zmm1
   2c3fe:	62 f1 fd 48 11 4d 00 	vmovupd %zmm1,0x0(%rbp)
   2c405:	62 f1 fd 48 59 ca    	vmulpd %zmm2,%zmm0,%zmm1
   2c40b:	62 f1 f5 48 58 cc    	vaddpd %zmm4,%zmm1,%zmm1
   2c411:	62 f1 f5 48 db d5    	vpandq %zmm5,%zmm1,%zmm2
   2c417:	c4 e1 f9 7e d1       	vmovq  %xmm2,%rcx
   2c41c:	c4 e3 f9 16 d2 01    	vpextrq $0x1,%xmm2,%rdx
   2c422:	c4 e3 7d 39 d3 01    	vextracti128 $0x1,%ymm2,%xmm3
   2c428:	c4 e1 f9 7e de       	vmovq  %xmm3,%rsi
   2c42d:	c4 e3 f9 16 df 01    	vpextrq $0x1,%xmm3,%rdi
   2c433:	62 f3 7d 48 39 d3 02 	vextracti32x4 $0x2,%zmm2,%xmm3
   2c43a:	c4 c1 f9 7e d8       	vmovq  %xmm3,%r8
   2c43f:	c4 c3 f9 16 d9 01    	vpextrq $0x1,%xmm3,%r9
   2c445:	62 f3 7d 48 39 d2 03 	vextracti32x4 $0x3,%zmm2,%xmm2
   2c44c:	c4 c1 f9 7e d2       	vmovq  %xmm2,%r10
   2c451:	c4 c3 f9 16 d3 01    	vpextrq $0x1,%xmm2,%r11
   2c457:	c4 a1 7a 7e 14 d8    	vmovq  (%rax,%r11,8),%xmm2
   2c45d:	c4 a1 7a 7e 1c d0    	vmovq  (%rax,%r10,8),%xmm3
   2c463:	c5 e1 6c d2          	vpunpcklqdq %xmm2,%xmm3,%xmm2
   2c467:	c4 a1 7a 7e 1c c8    	vmovq  (%rax,%r9,8),%xmm3
   2c46d:	c4 a1 7a 7e 24 c0    	vmovq  (%rax,%r8,8),%xmm4
   2c473:	c5 d9 6c db          	vpunpcklqdq %xmm3,%xmm4,%xmm3
   2c477:	c4 e3 65 38 d2 01    	vinserti128 $0x1,%xmm2,%ymm3,%ymm2
   2c47d:	c5 fa 7e 1c f8       	vmovq  (%rax,%rdi,8),%xmm3
   2c482:	c5 fa 7e 24 f0       	vmovq  (%rax,%rsi,8),%xmm4
   2c487:	c5 d9 6c db          	vpunpcklqdq %xmm3,%xmm4,%xmm3
   2c48b:	c5 fa 7e 24 d0       	vmovq  (%rax,%rdx,8),%xmm4
   2c490:	c5 fa 7e 2c c8       	vmovq  (%rax,%rcx,8),%xmm5
   2c495:	c5 d1 6c e4          	vpunpcklqdq %xmm4,%xmm5,%xmm4
   2c499:	c4 e3 5d 38 db 01    	vinserti128 $0x1,%xmm3,%ymm4,%ymm3
   2c49f:	62 f3 e5 48 3a d2 01 	vinserti64x4 $0x1,%ymm2,%zmm3,%zmm2
   2c4a6:	62 f1 f5 48 58 df    	vaddpd %zmm7,%zmm1,%zmm3
   2c4ac:	62 f1 f5 48 73 f1 2a 	vpsllq $0x2a,%zmm1,%zmm1
   2c4b3:	62 f1 ed 48 d4 c9    	vpaddq %zmm1,%zmm2,%zmm1
   2c4b9:	62 f1 e5 48 59 d6    	vmulpd %zmm6,%zmm3,%zmm2
   2c4bf:	62 f1 fd 48 5c c2    	vsubpd %zmm2,%zmm0,%zmm0
   2c4c5:	62 d1 e5 48 59 d1    	vmulpd %zmm9,%zmm3,%zmm2
   2c4cb:	62 f1 ed 48 58 c0    	vaddpd %zmm0,%zmm2,%zmm0
   2c4d1:	62 f1 fd 48 59 d0    	vmulpd %zmm0,%zmm0,%zmm2
   2c4d7:	62 d1 fd 48 59 d8    	vmulpd %zmm8,%zmm0,%zmm3
   2c4dd:	62 d1 e5 48 58 dc    	vaddpd %zmm12,%zmm3,%zmm3
   2c4e3:	62 f1 ed 48 59 d3    	vmulpd %zmm3,%zmm2,%zmm2
   2c4e9:	62 f1 fd 48 58 c2    	vaddpd %zmm2,%zmm0,%zmm0
   2c4ef:	62 d1 fd 48 58 c3    	vaddpd %zmm11,%zmm0,%zmm0
   2c4f5:	62 f1 fd 48 59 c1    	vmulpd %zmm1,%zmm0,%zmm0
   2c4fb:	62 f1 fd 48 11 45 01 	vmovupd %zmm0,0x40(%rbp)
   2c502:	e9 51 01 00 00       	jmp    2c658 <prod_exp_slice+0x1078>
   2c507:	49 83 ff 04          	cmp    $0x4,%r15
   2c50b:	0f 85 b6 01 00 00    	jne    2c6c7 <prod_exp_slice+0x10e7>
   2c511:	c4 e2 7d 19 0d 86 9e 	vbroadcastsd -0x2617a(%rip),%ymm1        # 63a0 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x1c0>
   2c518:	fd ff 
   2c51a:	c5 f9 57 c0          	vxorpd %xmm0,%xmm0,%xmm0
   2c51e:	c5 fd c2 d1 11       	vcmplt_oqpd %ymm1,%ymm0,%ymm2
   2c523:	c4 e2 7d 19 1d fc 9f 	vbroadcastsd -0x26004(%rip),%ymm3        # 6528 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x348>
   2c52a:	fd ff 
   2c52c:	c4 c1 7d 10 06       	vmovupd (%r14),%ymm0
   2c531:	c5 fd 54 db          	vandpd %ymm3,%ymm0,%ymm3
   2c535:	c5 e5 c2 c9 11       	vcmplt_oqpd %ymm1,%ymm3,%ymm1
   2c53a:	c5 f5 54 ca          	vandpd %ymm2,%ymm1,%ymm1
   2c53e:	c5 ed 76 d2          	vpcmpeqd %ymm2,%ymm2,%ymm2
   2c542:	62 f2 f5 48 37 c2    	vpcmpgtq %zmm2,%zmm1,%k0
   2c548:	c5 f8 93 c0          	kmovw  %k0,%eax
   2c54c:	a8 0f                	test   $0xf,%al
   2c54e:	0f 85 9a 01 00 00    	jne    2c6ee <prod_exp_slice+0x110e>
   2c554:	c4 e2 7d 19 0d 83 a1 	vbroadcastsd -0x25e7d(%rip),%ymm1        # 66e0 <anon.02ffda8f51e6076a26652e0a4fd6fa8d.746.llvm.5406940975955002095+0x180>
   2c55b:	fd ff 
   2c55d:	c5 fd 59 c9          	vmulpd %ymm1,%ymm0,%ymm1
   2c561:	c4 e2 7d 19 15 c6 a0 	vbroadcastsd -0x25f3a(%rip),%ymm2        # 6630 <anon.02ffda8f51e6076a26652e0a4fd6fa8d.746.llvm.5406940975955002095+0xd0>
   2c568:	fd ff 
   2c56a:	c4 e2 7d 19 1d 4d 9e 	vbroadcastsd -0x261b3(%rip),%ymm3        # 63c0 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x1e0>
   2c571:	fd ff 
   2c573:	c5 f5 58 ca          	vaddpd %ymm2,%ymm1,%ymm1
   2c577:	c5 f5 54 d3          	vandpd %ymm3,%ymm1,%ymm2
   2c57b:	c4 e1 f9 7e d0       	vmovq  %xmm2,%rax
   2c580:	48 8d 0d 41 b3 fd ff 	lea    -0x24cbf(%rip),%rcx        # 78c8 <anon.ee651107ab5319c6bc273e1a29320aaf.386.llvm.14746981713632465754+0x1d4>
   2c587:	c4 e3 f9 16 d2 01    	vpextrq $0x1,%xmm2,%rdx
   2c58d:	c4 e3 7d 39 d2 01    	vextracti128 $0x1,%ymm2,%xmm2
   2c593:	c4 e1 f9 7e d6       	vmovq  %xmm2,%rsi
   2c598:	c4 e3 f9 16 d7 01    	vpextrq $0x1,%xmm2,%rdi
   2c59e:	c5 fa 7e 14 f9       	vmovq  (%rcx,%rdi,8),%xmm2
   2c5a3:	c5 fa 7e 1c f1       	vmovq  (%rcx,%rsi,8),%xmm3
   2c5a8:	c5 e1 6c d2          	vpunpcklqdq %xmm2,%xmm3,%xmm2
   2c5ac:	c5 fa 7e 1c d1       	vmovq  (%rcx,%rdx,8),%xmm3
   2c5b1:	c5 fa 7e 24 c1       	vmovq  (%rcx,%rax,8),%xmm4
   2c5b6:	c5 d9 6c db          	vpunpcklqdq %xmm3,%xmm4,%xmm3
   2c5ba:	c4 e3 65 38 d2 01    	vinserti128 $0x1,%xmm2,%ymm3,%ymm2
   2c5c0:	c4 e2 7d 19 1d 3f a0 	vbroadcastsd -0x25fc1(%rip),%ymm3        # 6608 <anon.02ffda8f51e6076a26652e0a4fd6fa8d.746.llvm.5406940975955002095+0xa8>
   2c5c7:	fd ff 
   2c5c9:	c5 f5 58 db          	vaddpd %ymm3,%ymm1,%ymm3
   2c5cd:	c5 f5 73 f1 2a       	vpsllq $0x2a,%ymm1,%ymm1
   2c5d2:	c5 ed d4 c9          	vpaddq %ymm1,%ymm2,%ymm1
   2c5d6:	c4 e2 7d 19 15 21 9f 	vbroadcastsd -0x260df(%rip),%ymm2        # 6500 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x320>
   2c5dd:	fd ff 
   2c5df:	c5 e5 59 d2          	vmulpd %ymm2,%ymm3,%ymm2
   2c5e3:	c5 fd 58 c2          	vaddpd %ymm2,%ymm0,%ymm0
   2c5e7:	c4 e2 7d 19 15 b8 9d 	vbroadcastsd -0x26248(%rip),%ymm2        # 63a8 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x1c8>
   2c5ee:	fd ff 
   2c5f0:	c5 e5 59 d2          	vmulpd %ymm2,%ymm3,%ymm2
   2c5f4:	c5 ed 58 c0          	vaddpd %ymm0,%ymm2,%ymm0
   2c5f8:	c4 e2 7d 19 15 e7 9e 	vbroadcastsd -0x26119(%rip),%ymm2        # 64e8 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x308>
   2c5ff:	fd ff 
   2c601:	c5 fd 59 d8          	vmulpd %ymm0,%ymm0,%ymm3
   2c605:	c5 fd 59 d2          	vmulpd %ymm2,%ymm0,%ymm2
   2c609:	c4 e2 7d 19 25 d6 9d 	vbroadcastsd -0x2622a(%rip),%ymm4        # 63e8 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x208>
   2c610:	fd ff 
   2c612:	c5 ed 58 d4          	vaddpd %ymm4,%ymm2,%ymm2
   2c616:	c5 e5 59 d2          	vmulpd %ymm2,%ymm3,%ymm2
   2c61a:	c4 e2 7d 19 1d 0d 9f 	vbroadcastsd -0x260f3(%rip),%ymm3        # 6530 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x350>
   2c621:	fd ff 
   2c623:	c5 fd 58 c2          	vaddpd %ymm2,%ymm0,%ymm0
   2c627:	c5 fd 58 c3          	vaddpd %ymm3,%ymm0,%ymm0
   2c62b:	c5 fd 59 c1          	vmulpd %ymm1,%ymm0,%ymm0
   2c62f:	c5 fd 11 45 00       	vmovupd %ymm0,0x0(%rbp)
   2c634:	eb 22                	jmp    2c658 <prod_exp_slice+0x1078>
   2c636:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
   2c63b:	e8 e0 e0 ff ff       	call   2a720 <morphiq_numerics::exp::bounded::packet::<morphiq_numerics_arch::x86_64::Avx512, 64>>
   2c640:	eb 16                	jmp    2c658 <prod_exp_slice+0x1078>
   2c642:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
   2c647:	e8 44 df ff ff       	call   2a590 <morphiq_numerics::exp::bounded::packet::<morphiq_numerics_arch::x86_64::Avx512, 32>>
   2c64c:	eb 0a                	jmp    2c658 <prod_exp_slice+0x1078>
   2c64e:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
   2c653:	e8 c8 da ff ff       	call   2a120 <morphiq_numerics::exp::bounded::packet::<morphiq_numerics_arch::x86_64::Avx512, 16>>
   2c658:	48 83 c4 38          	add    $0x38,%rsp
   2c65c:	5b                   	pop    %rbx
   2c65d:	41 5c                	pop    %r12
   2c65f:	41 5d                	pop    %r13
   2c661:	41 5e                	pop    %r14
   2c663:	41 5f                	pop    %r15
   2c665:	5d                   	pop    %rbp
   2c666:	c5 f8 77             	vzeroupper
   2c669:	c3                   	ret
   2c66a:	be 04 00 00 00       	mov    $0x4,%esi
   2c66f:	b9 04 00 00 00       	mov    $0x4,%ecx
   2c674:	4c 89 f7             	mov    %r14,%rdi
   2c677:	48 89 ea             	mov    %rbp,%rdx
   2c67a:	c5 f8 77             	vzeroupper
   2c67d:	ff 15 9d f5 05 00    	call   *0x5f59d(%rip)        # 8bc20 <_DYNAMIC+0x4f0>
   2c683:	e9 50 f9 ff ff       	jmp    2bfd8 <prod_exp_slice+0x9f8>
   2c688:	48 89 ea             	mov    %rbp,%rdx
   2c68b:	eb 6a                	jmp    2c6f7 <prod_exp_slice+0x1117>
   2c68d:	4c 8d 05 c4 da 05 00 	lea    0x5dac4(%rip),%r8        # 8a158 <anon.02ffda8f51e6076a26652e0a4fd6fa8d.1766.llvm.5406940975955002095+0x78>
   2c694:	eb 38                	jmp    2c6ce <prod_exp_slice+0x10ee>
   2c696:	4c 8d 05 d3 da 05 00 	lea    0x5dad3(%rip),%r8        # 8a170 <anon.02ffda8f51e6076a26652e0a4fd6fa8d.1766.llvm.5406940975955002095+0x90>
   2c69d:	eb 2f                	jmp    2c6ce <prod_exp_slice+0x10ee>
   2c69f:	4c 8d 05 9a da 05 00 	lea    0x5da9a(%rip),%r8        # 8a140 <anon.02ffda8f51e6076a26652e0a4fd6fa8d.1766.llvm.5406940975955002095+0x60>
   2c6a6:	eb 26                	jmp    2c6ce <prod_exp_slice+0x10ee>
   2c6a8:	4c 8d 05 79 da 05 00 	lea    0x5da79(%rip),%r8        # 8a128 <anon.02ffda8f51e6076a26652e0a4fd6fa8d.1766.llvm.5406940975955002095+0x48>
   2c6af:	eb 1d                	jmp    2c6ce <prod_exp_slice+0x10ee>
   2c6b1:	48 89 ea             	mov    %rbp,%rdx
   2c6b4:	41 bf 08 00 00 00    	mov    $0x8,%r15d
   2c6ba:	eb 3b                	jmp    2c6f7 <prod_exp_slice+0x1117>
   2c6bc:	48 89 ea             	mov    %rbp,%rdx
   2c6bf:	41 bf 10 00 00 00    	mov    $0x10,%r15d
   2c6c5:	eb 30                	jmp    2c6f7 <prod_exp_slice+0x1117>
   2c6c7:	4c 8d 05 42 da 05 00 	lea    0x5da42(%rip),%r8        # 8a110 <anon.02ffda8f51e6076a26652e0a4fd6fa8d.1766.llvm.5406940975955002095+0x30>
   2c6ce:	48 8d 3d f3 d1 fd ff 	lea    -0x22e0d(%rip),%rdi        # 98c8 <anon.ee651107ab5319c6bc273e1a29320aaf.386.llvm.14746981713632465754+0x21d4>
   2c6d5:	48 8d 0d dc da 05 00 	lea    0x5dadc(%rip),%rcx        # 8a1b8 <anon.02ffda8f51e6076a26652e0a4fd6fa8d.1766.llvm.5406940975955002095+0xd8>
   2c6dc:	48 8d 54 24 07       	lea    0x7(%rsp),%rdx
   2c6e1:	be 0c 00 00 00       	mov    $0xc,%esi
   2c6e6:	ff 15 bc f3 05 00    	call   *0x5f3bc(%rip)        # 8baa8 <_DYNAMIC+0x378>
   2c6ec:	0f 0b                	ud2
   2c6ee:	48 89 ea             	mov    %rbp,%rdx
   2c6f1:	41 bf 04 00 00 00    	mov    $0x4,%r15d
   2c6f7:	4c 89 f7             	mov    %r14,%rdi
   2c6fa:	4c 89 fe             	mov    %r15,%rsi
   2c6fd:	4c 89 f9             	mov    %r15,%rcx
   2c700:	c5 f8 77             	vzeroupper
   2c703:	ff 15 17 f5 05 00    	call   *0x5f517(%rip)        # 8bc20 <_DYNAMIC+0x4f0>
   2c709:	e9 4a ff ff ff       	jmp    2c658 <prod_exp_slice+0x1078>
   2c70e:	4c 8d 05 e3 d9 05 00 	lea    0x5d9e3(%rip),%r8        # 8a0f8 <anon.02ffda8f51e6076a26652e0a4fd6fa8d.1766.llvm.5406940975955002095+0x18>
   2c715:	eb b7                	jmp    2c6ce <prod_exp_slice+0x10ee>
   2c717:	ff 15 bb f3 05 00    	call   *0x5f3bb(%rip)        # 8bad8 <_DYNAMIC+0x3a8>
   2c71d:	ff 15 b5 f3 05 00    	call   *0x5f3b5(%rip)        # 8bad8 <_DYNAMIC+0x3a8>
   2c723:	ff 15 af f3 05 00    	call   *0x5f3af(%rip)        # 8bad8 <_DYNAMIC+0x3a8>
   2c729:	ff 15 a9 f3 05 00    	call   *0x5f3a9(%rip)        # 8bad8 <_DYNAMIC+0x3a8>
   2c72f:	ff 15 a3 f3 05 00    	call   *0x5f3a3(%rip)        # 8bad8 <_DYNAMIC+0x3a8>

Disassembly of section .plt:
