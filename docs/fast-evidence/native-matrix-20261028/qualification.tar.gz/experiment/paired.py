import pathlib,sys,ctypes as C,os,json,math,csv,hashlib
P=pathlib.Path(__file__).resolve().parent
sys.path.insert(0,str(P.parent/'pr240-external-20261028'))
import external as E
os.sched_setaffinity(0,{2})
lib=C.CDLL(str(P/'wrapper-build/release/libproduction_bench_wrapper.so'))
entries={r['name']:r for r in E.REG}
for primitive,symbol in [('exp','exp'),('erfcx','erfcx'),('cdf','norm_cdf')]:
 for suffix,kind in [('', 'scalar'),('_slice','vector')]:
  name='prod_'+symbol+suffix
  entries[name]=dict(name=name,primitive=primitive,kind=kind,ptr=C.cast(getattr(lib,name),C.c_void_p).value)
pairs=[('prod_exp','core_math_exp'),('prod_exp','sleef_exp_scalar_fma'),('prod_exp_slice','sleef_exp_avx512'),('prod_erfcx','libcerf_erfcx'),('prod_erfcx_slice','libcerf_erfcx'),('prod_norm_cdf','scipy_ndtr'),('prod_norm_cdf_slice','sleef_cdf_avx512')]
names=list(dict.fromkeys(n for pair in pairs for n in pair))
def measure(name,count):
 r=entries[name];x=E.PACKETS[r['primitive']];y=E.np.empty_like(x)
 m=E.NATIVE.measure_packet if r['kind']=='vector' else E.NATIVE.measure2 if r['kind']=='scalar_capsule' else E.NATIVE.measure1
 elapsed=m(r['ptr'],x.ctypes.data_as(E.D),y.ctypes.data_as(E.D),len(x),count)
 assert E.np.isfinite(y).all()
 return elapsed
label=sys.argv[1];out=P/'paired'/label;out.mkdir(parents=True)
if label=='calibration':
 counts={};rows=[]
 for name in names:
  first=measure(name,10000)
  count=max(1,math.ceil(500000000/(first/10000)/1000)*1000)
  warm=measure(name,max(1,count//2));elapsed=measure(name,count)
  counts[name]=max(1,math.ceil(count*500000000/elapsed/1000)*1000)
  rows.append(dict(name=name,initial_ns=first,warmup_ns=warm,count=count,elapsed_ns=elapsed,frozen_count=counts[name]))
 (P/'paired/counts.json').write_text(json.dumps(counts,indent=2)+'\n')
 (out/'samples.json').write_text(json.dumps(rows,indent=2)+'\n')
else:
 counts=json.loads((P/'paired/counts.json').read_text());process=int(label)
 with (out/'samples.csv').open('w',buffering=1) as f:
  writer=csv.DictWriter(f,fieldnames=['process','pair','round','name','kind','iterations','elapsed_ns','ns_per_52']);writer.writeheader()
  for round in range(4):
   order=list(enumerate(pairs));order=order if (process+round)%2==0 else order[::-1]
   for pair_index,pair in order:
    for name in pair if (process+round)%2==0 else pair[::-1]:
     for kind,count in [('warmup',max(1,counts[name]//2)),('timed',counts[name])]:
      elapsed=measure(name,count)
      writer.writerow(dict(process=process,pair=pair_index,round=round,name=name,kind=kind,iterations=count,elapsed_ns=elapsed,ns_per_52=elapsed/count))
 (out/'metadata.json').write_text(json.dumps(dict(affinity=sorted(os.sched_getaffinity(0)),scipy=E.scipy.__version__,numpy=E.np.__version__,pairs=pairs,counts=counts),indent=2)+'\n')
