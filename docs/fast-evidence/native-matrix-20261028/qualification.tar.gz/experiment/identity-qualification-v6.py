"""Independent observations and bit identity for every frozen timed input bank."""
from pathlib import Path
import ctypes as C, gzip, csv, hashlib, json, math, os, struct, sys
import mpmath as mp
P=Path(__file__).resolve().parent;os.sched_setaffinity(0,{0});mp.mp.prec=256
D=C.POINTER(C.c_double);word=lambda x:struct.pack('>d',float(x)).hex();value=lambda w:struct.unpack('>d',bytes.fromhex(w))[0]
manifest=json.loads((P/'qualification-manifest.json').read_text());out=P/'qualification-v6-identity';out.mkdir(exist_ok=False)
libs={name:C.CDLL(str(P/'qualification-v6-bin'/f'{name}.so')) for name in ['auto','sse2','avx2','avx512']}
control=C.CDLL(str(P/'final-bin/control.so'));results=[]
for primitive,symbol in [('exp','exp'),('erfcx','erfcx'),('cdf','norm_cdf')]:
 paths=sorted({c['input']['file'] for c in manifest['cells'] if c['primitive']==primitive});banks={path:json.loads(Path(path).read_text()) for path in paths}
 words=sorted(set(w for bank in banks.values() for w in bank));xs={w:value(w) for w in words}
 functions={}
 for name,lib in libs.items():
  for prefix in ['prod_','control_']:
   scalar=getattr(lib,prefix+symbol);scalar.argtypes=[C.c_double];scalar.restype=C.c_double
   vector=getattr(lib,prefix+symbol+'_slice');vector.argtypes=[D,D,C.c_size_t];vector.restype=None
   functions[name,prefix]=scalar,vector
 old=getattr(control,'control_'+symbol);old.argtypes=[C.c_double];old.restype=C.c_double
 base=C.CDLL(str(P/'qualification-bin/auto.so'));basefn=getattr(base,'prod_'+symbol);basefn.argtypes=[C.c_double];basefn.restype=C.c_double
 expected={w:word(basefn(x)) for w,x in xs.items()};strong={w:word(old(x)) for w,x in xs.items()}
 mismatches=[];checks=0
 for (backend,prefix),(scalar,vector) in functions.items():
  reference=expected if prefix=='prod_' else strong
  for w,x in xs.items():
   actual=word(scalar(x));checks+=1
   if actual!=reference[w]:mismatches.append(dict(kind='scalar',backend=backend,prefix=prefix,input=w,actual=actual,expected=reference[w]))
  for path,bank in banks.items():
   x=(C.c_double*max(1,len(bank)))(*(xs[w] for w in bank));y=(C.c_double*max(1,len(bank)))();vector(x,y,len(bank))
   for w,actual in zip(bank,y):
    checks+=1
    if word(actual)!=reference[w]:mismatches.append(dict(kind='slice',backend=backend,prefix=prefix,bank=path,input=w,actual=word(actual),expected=reference[w]))
 row=dict(primitive=primitive,unique_inputs=len(words),banks=len(banks),identity_checks=checks,mismatches=mismatches)
 results.append(row);(out/'summary.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(row),flush=True)
assert not any(r['mismatches'] for r in results)
