from pathlib import Path
W=Path(__file__).resolve().parent/'source'
p=W/'crates/morphiq-numerics-arch/src/lib.rs';s=p.read_text();needle='    /// `a = b`.\n    fn eq_u'
insert='''    /// `a + b`, wrapping independently in each lane.
    #[inline(always)]
    fn add_u(self, a: Self::U, b: Self::U) -> Self::U {
        self.sub_u(a, self.sub_u(self.splat_bits(0), b))
    }
    /// `a << n`, with zero for `n >= 64`.
    #[inline(always)]
    fn shl_u(self, a: Self::U, n: u32) -> Self::U {
        let a = self.store(self.to_float(a));
        let mut out = Self::Words::default();
        for (out, a) in out.as_mut().iter_mut().zip(a.as_ref()) {
            *out = a.to_bits().checked_shl(n).unwrap_or(0);
        }
        self.load_bits(out)
    }
    /// Load `table[index % N]` as binary64 bits in each lane.
    ///
    /// # Panics
    /// If `N` is not a positive power of two. Masking inside this owner
    /// bounds every memory access, including arbitrary caller indices.
    #[inline(always)]
    fn gather_wrapped<const N: usize>(self, table: &[u64; N], index: Self::U) -> Self::F {
        assert!(N.is_power_of_two(), "gather table length must be a positive power of two");
        let index = self.store(self.to_float(index));
        let mut out = Self::Array::default();
        for (out, index) in out.as_mut().iter_mut().zip(index.as_ref()) {
            *out = f64::from_bits(table[(index.to_bits() as usize) & (N - 1)]);
        }
        self.load(out)
    }
    /// Load a prefix of at most `LANES` values; remaining lanes are positive zero.
    ///
    /// # Panics
    /// If the slice is longer than `LANES`.
    #[inline(always)]
    fn load_partial(self, values: &[f64]) -> Self::F {
        assert!(values.len() <= Self::LANES, "partial load exceeds lane width");
        let mut a = Self::Array::default();
        a.as_mut()[..values.len()].copy_from_slice(values);
        self.load(a)
    }
    /// Store only the prefix selected by the output slice's length.
    ///
    /// # Panics
    /// If the slice is longer than `LANES`.
    #[inline(always)]
    fn store_partial(self, value: Self::F, out: &mut [f64]) {
        assert!(out.len() <= Self::LANES, "partial store exceeds lane width");
        out.copy_from_slice(&self.store(value).as_ref()[..out.len()]);
    }
'''
assert needle in s;s=s.replace(needle,insert+needle);p.write_text(s)
p=W/'crates/morphiq-numerics-arch/src/x86_64.rs';s=p.read_text()
for backend,width,ty in [('sse2',128,'__m128i'),('avx2',256,'__m256i'),('avx512',512,'__m512i')]:
 needle=f'        fn sub_u(a: {ty}, b: {ty}) -> {ty};'
 s=s.replace(needle,needle+f'\n        fn add_u(a: {ty}, b: {ty}) -> {ty};\n        fn shl_u(a: {ty}, n: u32) -> {ty};')
 tag='' if backend=='sse2' else f'        #[target_feature(enable = "{"avx2,fma" if backend=="avx2" else "avx512f"}")]\n'
 prefix='_mm' if width==128 else f'_mm{width}'
 pos=s.index('        #[inline]',s.index(f'pub(in super::super) fn sub_u(a: {ty}')) if backend=='sse2' else s.index('        #[target_feature',s.index(f'pub(in super::super) fn sub_u(a: {ty}'))
 extra=tag+f'''        #[inline]
        pub(in super::super) fn add_u(a: {ty}, b: {ty}) -> {ty} {{
            {prefix}_add_epi64(a, b)
        }}
'''+tag+f'''        #[inline]
        pub(in super::super) fn shl_u(a: {ty}, n: u32) -> {ty} {{
            {prefix}_sll_epi64(a, _mm_cvtsi64_si128(i64::from(n)))
        }}
'''
 s=s[:pos]+extra+s[pos:]
# Generic gather methods cannot use the non-generic forwarding macro.
for name,backend,ity,fty in [('Avx2','avx2','__m256i','__m256d'),('Avx512','avx512','__m512i','__m512d')]:
 pos=s.index('    forward!',s.index(f'impl Simd for {name}'))
 extra=f'''    #[inline(always)]
    fn gather_wrapped<const N: usize>(self, table: &[u64; N], index: {ity}) -> {fty} {{
        // SAFETY: this token establishes the helper's CPU features. The helper
        // checks the table shape and masks indices before every memory access.
        unsafe {{ {backend}::gather_wrapped(table, index) }}
    }}
'''
 if name=='Avx512':extra+='''    #[inline(always)]
    fn load_partial(self, values: &[f64]) -> __m512d {
        // SAFETY: this token establishes AVX-512F; the helper checks the length
        // and enables memory accesses only for the supplied slice elements.
        unsafe { avx512::load_partial(values) }
    }
    #[inline(always)]
    fn store_partial(self, value: __m512d, out: &mut [f64]) {
        // SAFETY: this token establishes AVX-512F; the helper checks the length
        // and stores only to the supplied slice elements.
        unsafe { avx512::store_partial(value, out) }
    }
'''
 s=s[:pos]+extra+s[pos:]
 pos=s.index('        #[target_feature',s.index(f'    pub(super) mod {backend}')) if f'    pub(super) mod {backend}' in s else -1
 # Locate the backend helper module without depending on its visibility spelling.
 if pos<0:
  import re
  match=re.search(r'\bmod '+backend+r' \{',s);assert match,backend
  pos=s.index('        #[target_feature',match.end())
 width=256 if backend=='avx2' else 512;feature='avx2,fma' if width==256 else 'avx512f'
 gather=f'_mm{width}_i64gather_epi64::<8>(table.as_ptr().cast(), index)' if width==256 else '_mm512_i64gather_epi64::<8>(index, table.as_ptr().cast())'
 extra=f'''        #[target_feature(enable = "{feature}")]
        #[inline]
        pub(in super::super) fn gather_wrapped<const N: usize>(table: &[u64; N], index: {ity}) -> {fty} {{
            assert!(N.is_power_of_two(), "gather table length must be a positive power of two");
            #[allow(clippy::cast_possible_wrap)] // a Rust array cannot exceed isize::MAX bytes
            let index = _mm{width}_and_si{width}(index, _mm{width}_set1_epi64{'x' if width==256 else ''}((N - 1) as i64));
            // SAFETY: masked indices are in 0..N; scale eight addresses exactly
            // the u64 elements of the live array. This helper has the CPU feature.
            unsafe {{ _mm{width}_castsi{width}_pd({gather}) }}
        }}
'''
 if width==512:extra+='''        #[target_feature(enable = "avx512f")]
        #[inline]
        pub(in super::super) fn load_partial(values: &[f64]) -> __m512d {
            assert!(values.len() <= 8, "partial load exceeds lane width");
            #[allow(clippy::cast_possible_truncation)] // len <= 8, so the mask fits u8
            let mask = ((1_u16 << values.len()) - 1) as u8;
            // SAFETY: only the first values.len() lanes are enabled, each in
            // the live slice; disabled lanes perform no memory access.
            unsafe { _mm512_maskz_loadu_pd(mask, values.as_ptr()) }
        }
        #[target_feature(enable = "avx512f")]
        #[inline]
        pub(in super::super) fn store_partial(value: __m512d, out: &mut [f64]) {
            assert!(out.len() <= 8, "partial store exceeds lane width");
            #[allow(clippy::cast_possible_truncation)] // len <= 8, so the mask fits u8
            let mask = ((1_u16 << out.len()) - 1) as u8;
            // SAFETY: enabled lanes are exactly the elements of the exclusive
            // output slice; disabled lanes perform no memory access.
            unsafe { _mm512_mask_storeu_pd(out.as_mut_ptr(), mask, value) }
        }
'''
 s=s[:pos]+extra+s[pos:]
p.write_text(s)
