
target/benchmarks/pr240-parity-next-20261028/qualification-v7-bin/avx512.so:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .text:

0000000000027e90 <prod_exp_slice>:
   27e90:	50                   	push   %rax
   27e91:	48 89 d1             	mov    %rdx,%rcx
   27e94:	48 89 f2             	mov    %rsi,%rdx
   27e97:	48 8d 41 f8          	lea    -0x8(%rcx),%rax
   27e9b:	48 83 f8 03          	cmp    $0x3,%rax
   27e9f:	73 11                	jae    27eb2 <prod_exp_slice+0x22>
   27ea1:	48 83 f9 08          	cmp    $0x8,%rcx
   27ea5:	75 16                	jne    27ebd <prod_exp_slice+0x2d>
   27ea7:	48 89 d6             	mov    %rdx,%rsi
   27eaa:	ff 15 80 17 06 00    	call   *0x61780(%rip)        # 89630 <_DYNAMIC+0x550>
   27eb0:	eb 14                	jmp    27ec6 <prod_exp_slice+0x36>
   27eb2:	48 89 ce             	mov    %rcx,%rsi
   27eb5:	ff 15 7d 17 06 00    	call   *0x6177d(%rip)        # 89638 <_DYNAMIC+0x558>
   27ebb:	eb 09                	jmp    27ec6 <prod_exp_slice+0x36>
   27ebd:	48 89 ce             	mov    %rcx,%rsi
   27ec0:	ff 15 7a 17 06 00    	call   *0x6177a(%rip)        # 89640 <_DYNAMIC+0x560>
   27ec6:	58                   	pop    %rax
   27ec7:	c3                   	ret
   27ec8:	ff 15 ba 15 06 00    	call   *0x615ba(%rip)        # 89488 <_DYNAMIC+0x3a8>

Disassembly of section .plt:
