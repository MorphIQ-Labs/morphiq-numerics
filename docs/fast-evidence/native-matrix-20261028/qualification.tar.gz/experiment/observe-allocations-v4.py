from pathlib import Path
import ctypes as C,json,os,struct,re
P=Path(__file__).resolve().parent;os.sched_setaffinity(0,{0});D=C.POINTER(C.c_double)
out=P/'qualification-v4-allocations';out.mkdir(exist_ok=False)
lib=C.CDLL(str(P/'qualification-bin/auto.so'));probe=C.CDLL(str(P/'bin/allocation-probe.so'))
probe.observe_control.argtypes=[C.c_char_p];probe.observe_control.restype=None
probe.observe_allocations.argtypes=[C.c_void_p,D,D,C.c_size_t,C.c_int,C.c_char_p];probe.observe_allocations.restype=None
def profile(prefix):
 files=list(out.glob(prefix.name+'.*.heap'));assert len(files)==1,files
 text=files[0].read_text();counts=re.search(r'heap profile:\s+(\d+):\s+(\d+)\s+\[\s*(\d+):\s+(\d+)\]',text)
 assert counts,text[:200]
 return [int(v) for v in counts.groups()]
control=out/'positive-control';probe.observe_control(str(control).encode());assert profile(control)[2:]==[1,71]
rows=[]
for primitive,name in [('exp','exp'),('erfcx','erfcx'),('cdf','norm_cdf')]:
 for pop in ['ordinary','mixed','fallback']:
  words=json.loads((P/'qualification-inputs'/f'{primitive}-{pop}-52.json').read_text());x=(C.c_double*len(words))(*(struct.unpack('>d',bytes.fromhex(w))[0] for w in words));y=(C.c_double*len(words))()
  for scalar in [True,False]:
   symbol='prod_'+name+('' if scalar else '_slice');path=out/f'{symbol}-{pop}.trace';probe.observe_allocations(C.cast(getattr(lib,symbol),C.c_void_p),x,y,len(words),int(scalar),str(path).encode())
   counts=profile(path);events=[] if counts==[0,0,0,0] else counts;rows.append(dict(symbol=symbol,population=pop,calls=10001*(len(words) if scalar else 1),events=events))
(out/'summary.json').write_text(json.dumps(dict(positive_control=profile(control),cells=rows),indent=2)+'\n');assert not any(r['events'] for r in rows)
print('Positive allocation control detected; all 18 public-call populations have zero allocation events.')
