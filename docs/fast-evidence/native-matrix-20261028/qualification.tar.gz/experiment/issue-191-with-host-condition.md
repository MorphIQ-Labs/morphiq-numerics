## Purpose
First implementation prerequisite of fast-tier epic #178. Define explicit bounded-approximation contracts before selecting kernels. Strong APIs retain their existing guarantees; this work does not change them.

## Deliverables
- [ ] Inventory the initial normal and elementary primitives from actual consumer error budgets. Record per-function/domain absolute, relative or ULP bounds; zeros, cancellation, tails, underflow/overflow, NaNs and infinities. Faithful rounding is a candidate, not a crate-wide assumption.
- [ ] Specify scalar and slice signatures under `morphiq_numerics::fast::{normal,elementary}` in the existing crate. No accuracy-changing feature flag; no duplicate public `fast_exp` naming scheme. Share internals only where their contracts apply.
- [ ] Pin comparator versions and document accuracy, domain, special-value semantics, determinism, native backends, flags and calling interfaces. Distinguish comparable-guarantee parity candidates from weaker diagnostic references and independent oracles. Explain unmatched guarantees; no universal competitive claim follows from a sampled error table.
- [ ] Freeze public representative and adversarial workloads, scalar throughput/dependency latency, short/remainder/large batches and composition controls. Define repetitions, stability controls, uncertainty/equivalence treatment and per-cell versus justified aggregate acceptance before declaring parity. Do not silently introduce a global slowdown allowance or accuracy budget.
- [ ] Map each proposed contract to proof/certificate, generated-constant, independent-oracle and cross-target/scalar-SIMD enforcement. Identify prerequisite arithmetic work.

Reuse #150's methodology and existing harnesses. This initial fast-tier work need not wait for #149's complete-baseline campaign. Publish the decision matrix on this issue; source documentation describes APIs only when implemented. Consumer adoption and composed error-budget approval remain consumer-owned (#91/#155).

## Native comparison decision record — 2026-10-28

This freezes the next external-reference campaign before its measurements. It qualifies the existing 52-value exact-bit workload on this x86 host only; it does not close the broader workload, ARM, consumer or release obligations in #194. Earlier exploratory screens and failed repeatability attempts remain retained.

The selected contracts remain relative 2^-51 for accelerated exp/erfcx and absolute 2^-49 for accelerated normal CDF, with strong fallback outside their documented screens. No strong API changes. The intended use is an explicitly selected primitive budget; derivative, inverse and end-to-end consumer qualification remain separate.

| Public implementation | Same-host cost targets | Reference contract/interface |
| --- | --- | --- |
| fast exp scalar | CORE-MATH exp; SLEEF scalar FMA exp | correctly rounded CORE-MATH; SLEEF u10 (1 ULP), C scalar calls |
| fast exp slice | SLEEF AVX-512 exp | u10, public packet wrapper including remainder |
| fast erfcx scalar and slice | libcerf erfcx | native scalar function; slice comparison includes the reference scalar loop |
| fast normal CDF scalar | SciPy ndtr | Cython native capsule, dispatch argument fixed to 1 |
| fast normal CDF slice | SLEEF AVX-512 erfc composition | 0.5*erfc(-x/sqrt(2)), erfc u15, rounded scaling included |

CORE-MATH c7100a07428584639defdd64409e3621884c362b; SLEEF 3.9.0 / 906ca7512ee483296780a81a21b9ca715d40dfe1; libcerf 3.3 / 7e6b637031b5c6cbc89a5f7220bf4ef07518d035; SciPy 1.16.3 / NumPy 2.3.4. Reference binaries, flags, compiler metadata, exact inputs and original measurements are retained in `target/benchmarks/pr240-external-20261028`. These reference libraries do not establish our cross-target identity, NaN payload preservation, or proved whole-domain bounds. Libcerf/SciPy/composed SLEEF are practical cost targets with independent error observations, not substitutes for our certificates. SciPy erfcx is diagnostic only: retained observations exceed our 4u relative budget (including the 52-value packet).

Host: i9-10920X, Linux, CPU 2 pinned, sibling 14 idle, performance governor, turbo enabled; frequency/thermal/contention snapshots before and after each process. Public Rust simd+std build, release thin LTO, one codegen unit; C timers have contraction disabled. No builds, proof checks, or oracle work during timings. Wrapper SHA-256: `6ec6667f31f938b72e05d611f35a3bd5374a14d1f79f4f672dd64c6e29ee9198`. Exact runner and source patch are retained with the packet.

Protocol: one excluded calibration freezes per-entry iteration counts targeting 500 ms. Each sample gets an excluded warmup at half that count (approximately 250 ms), explicitly addressing ISA/frequency settling rather than the old 100-call warmup. Ten fresh processes, two blocks of five separated by 30 seconds, four alternating paired rounds per process. Pair order and implementation order alternate. Every timed sample must last at least 250 ms; retain all raw samples, warmups, host snapshots and failed attempts. The minimum is a measurement-resolution/stability control, not a mathematical validity threshold or an accuracy bound.

Decision: every listed pair must meet or beat. For each process take the median paired log time ratio; across ten processes report geometric mean ratio, median/spread and a one-sided 95% Student-t upper confidence bound (9 degrees of freedom). Require upper bound <= 1.00, with no permitted slowdown and no aggregation that hides a losing pair. Report absolute process-median range and inter-block drift against the existing 3% rule separately; failing that rule leaves absolute repeatability unestablished and prevents calling the full #194 exercise complete. Paired uncertainty does not retroactively waive that gate. A single retained campaign decides this candidate; a new attempt needs a documented implementation or host/protocol change.

Evidence couples these timings to the actual public outputs: 256-bit mpmath observations over representative, grid, reduction-boundary and fixture populations; all 11,413 independent rounded fixtures; scalar/slice special values and remainder lengths. These are finite observations. Whole-domain IEEE/Gappa/Coq proofs and source bindings are required separately, with full tests/lint/generator/determinism/assurance CI on GitHub. Focused local proof and generator checks are explicitly authorized.

### Host condition clarification before calibration

The owner explicitly directed this campaign to proceed on clear CPU 2 while unrelated CI uses other cores. CPU 14 remains the idle SMT sibling. The strict no-local-build condition applies to this experiment’s builds/proofs/oracles; unrelated-core activity is retained in host snapshots and is not a reason to defer timing. The numerical, duration, no-slowdown and 3% absolute-repeatability rules remain unchanged. No calibration or timing sample had been taken before this clarification. Final source is `ca3fce4`; the two lint-only fixes leave the public wrapper binary SHA-256 identical to the frozen binary above.
