from pathlib import Path
import ctypes as C,hashlib,json,os,struct,sys
P=Path(__file__).resolve().parent;os.sched_setaffinity(0,{0})
label=sys.argv[1];lib=C.CDLL(str(P/'candidates'/f'{label}.so'));base=C.CDLL(str(P/'final-bin/auto.so'));D=C.POINTER(C.c_double)
words_to_values=lambda words:[struct.unpack('>d',bytes.fromhex(w))[0] for w in words]
bits=lambda x:struct.pack('>d',x).hex()
records=[]
for primitive,name in [('exp','exp'),('erfcx','erfcx'),('cdf','norm_cdf')]:
 scalar=getattr(lib,'prod_'+name);scalar.argtypes=[C.c_double];scalar.restype=C.c_double
 reference=getattr(base,'prod_'+name);reference.argtypes=[C.c_double];reference.restype=C.c_double
 vector=getattr(lib,'prod_'+name+'_slice');vector.argtypes=[D,D,C.c_size_t];vector.restype=None
 count=0;fail=[]
 for path in sorted((P/'matrix-inputs').glob(primitive+'-*.json')):
  words=json.loads(path.read_text());values=words_to_values(words);n=len(values)
  x=(C.c_double*max(1,n))(*values);y=(C.c_double*max(1,n))();vector(x,y,n)
  for i,xv in enumerate(values):
   a=bits(scalar(xv));b=bits(reference(xv));v=bits(y[i]);count+=1
   if a!=b or a!=v:fail.append(dict(file=path.name,index=i,input=words[i],scalar=a,baseline=b,vector=v))
 records.append(dict(primitive=primitive,checks=count,failures=fail))
result=dict(candidate=label,sha256=hashlib.sha256((P/'candidates'/f'{label}.so').read_bytes()).hexdigest(),scope='Exact matrix banks: scalar bits versus ec1eb1c and scalar/slice identity, not an independent error-bound proof',records=records)
(P/f'candidates/{label}-identity.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2));assert not any(r['failures'] for r in records)
