import pathlib,sys,ctypes as C,os,json,struct,csv,math,random
P=pathlib.Path(__file__).resolve().parent;sys.path.insert(0,str(P.parent/'pr240-external-20261028'))
import external as E
import mpmath as mp
os.sched_setaffinity(0,{0});mp.mp.prec=256
lib=C.CDLL(str(P/'selected.so'));rng=random.Random(194240)
def bits(x):return struct.pack('>d',float(x)).hex()
def val(w):return struct.unpack('>d',bytes.fromhex(w))[0]
fixture=json.loads((E.BASE/'observations/fast-reference-expected.json').read_text());results=[]
for f,name in [('exp','quartic_exp'),('erfcx','split_erfcx'),('cdf','quartic_cdf')]:
 words={key.split()[1] for key in fixture if key.startswith(f+' ')}
 lo,hi=(-704,704) if f=='exp' else (-.5,16) if f=='erfcx' else (-8,8)
 words.update(bits(lo+(hi-lo)*i/8192) for i in range(8193));words.update(bits(x) for x in E.PACKETS[f])
 if f=='cdf':
  for x in [-1,1,-8,8]:words.update(bits(y) for y in [x,math.nextafter(x,-math.inf),math.nextafter(x,math.inf)])
 if f=='exp':
  words.update(bits(rng.uniform(-704,704)) for _ in range(8192))
  for n in range(-520000,520001,127):
   x=float(mp.mpf(n)*mp.log(2)/512)
   words.update(bits(y) for y in [x,math.nextafter(x,-math.inf),math.nextafter(x,math.inf)])
 xs=sorted([val(w) for w in words if math.isfinite(val(w)) and (abs(val(w))<704 if f=='exp' else -.5<=val(w)<16 and abs(val(w))>=2**-33 if f=='erfcx' else 2**-33<=abs(val(w))<=8)])
 fn=getattr(lib,name);fn.argtypes=[C.c_double];fn.restype=C.c_double
 worst=mp.mpf(0);fail=[];witness=None;budget=mp.mpf(2)**(-49 if f=='cdf' else -51)
 with (P/(name+'-observations.csv')).open('w') as stream:
  w=csv.writer(stream);w.writerow(['input_bits','output_bits','reference_256bit','error'])
  for x in xs:
   a=mp.mpf(x);ref=mp.exp(a) if f=='exp' else mp.exp(a*a)*mp.erfc(a) if f=='erfcx' else mp.erfc(-a/mp.sqrt(2))/2
   y=fn(x);error=abs(mp.mpf(y)-ref)/(1 if f=='cdf' else abs(ref))
   w.writerow([bits(x),bits(y),mp.nstr(ref,85),mp.nstr(error,30)])
   if error>worst:worst=error;witness=dict(input=bits(x),output=bits(y),reference=mp.nstr(ref,85))
   if error>budget:fail.append(bits(x))
 results.append(dict(name=name,cases=len(xs),max_error=float(worst),budget=float(budget),metric='absolute' if f=='cdf' else 'relative',failures=fail,witness=witness))
(P/'accuracy-summary.json').write_text(json.dumps(dict(scope='Independent finite observations, not whole-domain proof',cells=results),indent=2)+'\n')
# Kernel identity: same selected scalar operation sequence including screened lanes.
fn=C.CFUNCTYPE(None,E.D,E.D,C.c_size_t)(C.cast(lib.compact_exp_slice,C.c_void_p).value)
scalar=lib.quartic_exp;scalar.argtypes=[C.c_double];scalar.restype=C.c_double
words=[key.split()[1] for key in fixture if key.startswith('exp ')];xs=[val(w) for w in words]+[rng.uniform(-704,704) for _ in range(8192)]+[float('inf'),-float('inf'),float('nan'),0.,-0.]
fail=[];checked=0
for x in [E.np.array(xs)]+[E.np.array(xs[:n]) for n in range(66)]:
 y=E.np.empty_like(x);fn(x.ctypes.data_as(E.D),y.ctypes.data_as(E.D),len(x))
 for a,b in zip(x,y):
  c=scalar(a)
  if bits(b)!=bits(c):fail.append(dict(input=bits(a),scalar=bits(c),vector=bits(b)))
 checked+=len(x)
(P/'identity-summary.json').write_text(json.dumps(dict(cases=checked,mismatches=fail),indent=2)+'\n')
print(json.dumps(results,indent=2));print('identity',checked,'mismatches',len(fail));assert not fail and not any(r['failures'] for r in results)
