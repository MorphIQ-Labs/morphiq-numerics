import pathlib,sys,ctypes as C,os,csv,math
P=pathlib.Path(__file__).resolve().parent;sys.path.insert(0,str(P.parent/'pr240-external-20261028'))
import external as E
os.sched_setaffinity(0,{2});label=sys.argv[1];lib=C.CDLL(str(P/'candidates'/f'{label}.so'));baseline=C.CDLL(str(P/'bin/auto.so'))
entries=[dict(name=label,kind='vector',ptr=C.cast(lib.prod_exp_slice,C.c_void_p).value),dict(name='baseline',kind='vector',ptr=C.cast(baseline.prod_exp_slice,C.c_void_p).value),next(r for r in E.REG if r['name']=='sleef_exp_avx512')]
def measure(r,x,n):
 y=E.np.empty_like(x);return E.NATIVE.measure_packet(r['ptr'],x.ctypes.data_as(E.D),y.ctypes.data_as(E.D),len(x),n)
with (P/'candidates'/f'{label}.csv').open('w',buffering=1) as f:
 writer=csv.writer(f);writer.writerow(['population','length','round','name','count','elapsed_ns','ns_per_call'])
 for population in ['ordinary','wide']:
  for n in list(range(1,18))+[31,32,33,51,52,53,63,64,65,256,4096,65536]:
   x=E.np.resize(E.PACKETS['exp'],n) if population=='ordinary' else E.np.array([-703.999+1407.998*(i+.5)/n for i in range(n)])
   counts={r['name']:max(1,math.ceil(40000000/(measure(r,x,1000)/1000))) for r in entries}
   for rep in range(2):
    for r in entries if rep==0 else entries[::-1]:
     count=counts[r['name']];elapsed=measure(r,x,count);writer.writerow([population,n,rep,r['name'],count,elapsed,elapsed/count])
