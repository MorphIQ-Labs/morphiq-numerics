from pathlib import Path
W=Path(__file__).resolve().parent/'source';R=W/'crates/morphiq-numerics/src'
p=R/'exp/mod.rs';s=p.read_text();s='pub(crate) mod bounded;\n'+s if not s.startswith('//!') else s.replace('\n', '\npub(crate) mod bounded;\n',1)
# Module inner documentation must stay before all items.
s=p.read_text();lines=s.splitlines(True);i=0
while i<len(lines) and (lines[i].startswith('//!') or not lines[i].strip()):i+=1
lines.insert(i,'pub(crate) mod bounded;\n');p.write_text(''.join(lines))
(R/'exp/bounded.rs').write_text('''//! Explicit bounded exponential: high-word table and quartic local polynomial.
//! The strong exponential retains its own compensated evaluator.
use super::tables::{INV_N, POLY_S, SHIFTER, S_L1, S_L2D, S_T};

// A layout projection of the existing generated table, not new coefficients.
const HIGH: [u64; 512] = {
    let mut high = [0; 512];
    let mut i = 0;
    while i < 512 { high[i] = S_T[i].0; i += 1; }
    high
};
const SCALE_MASK: u64 = 0xfff0_0000_0000_0000;

#[inline]
pub(crate) fn exp(x: f64) -> f64 {
    if !(x.abs() < 704.0) { return super::exp(x); }
    let t = x * INV_N + SHIFTER;
    let n = t - SHIFTER;
    let bits = t.to_bits();
    #[allow(clippy::cast_possible_truncation)] // masked index is at most 511
    let index = (bits & 511) as usize;
    // Bits 9..20 encode the signed scale modulo 4096. Adding this field to
    // the normal table word is exact for this screened exponent domain.
    let high = f64::from_bits(HIGH[index].wrapping_add((bits << 43) & SCALE_MASK));
    let r = (x - n * S_L1) - n * S_L2D;
    let [d3, d4, _] = POLY_S;
    let p = d3 + r * d4;
    let u = r + (r * r) * (0.5 + r * p);
    high + high * u
}

#[cfg(feature = "simd")]
#[inline(always)]
pub(crate) fn lanes<K: morphiq_numerics_arch::Simd>(k: K, input: K::F) -> K::F {
    let active = k.lt(k.abs(input), k.splat(704.0));
    let x = k.select(active, input, k.splat(0.0));
    let t = k.add(k.mul(x, k.splat(INV_N)), k.splat(SHIFTER));
    let n = k.sub(t, k.splat(SHIFTER));
    let bits = k.to_bits(t);
    let high = k.gather_wrapped(&HIGH, bits);
    let scale = k.and_u(k.shl_u(bits, 43), k.splat_bits(SCALE_MASK));
    let high = k.to_float(k.add_u(k.to_bits(high), scale));
    let r = k.sub(k.sub(x, k.mul(n, k.splat(S_L1))), k.mul(n, k.splat(S_L2D)));
    let [d3, d4, _] = POLY_S;
    let p = k.add(k.splat(d3), k.mul(r, k.splat(d4)));
    let u = k.add(r, k.mul(k.mul(r, r), k.add(k.splat(0.5), k.mul(r, p))));
    let result = k.add(high, k.mul(high, u));
    let active = k.mask_bits(active);
    if active == (1 << K::LANES) - 1 { return result; }
    let x = k.store(input);
    let mut out = k.store(result);
    for (i, y) in out.as_mut().iter_mut().enumerate() {
        if active >> i & 1 == 0 { *y = super::exp(x.as_ref()[i]); }
    }
    k.load(out)
}

#[cfg(feature = "simd")]
struct Slice<'a> { input: &'a [f64], output: &'a mut [f64] }
#[cfg(feature = "simd")]
impl morphiq_numerics_arch::WithSimd for Slice<'_> {
    type Output = ();
    #[inline(always)]
    fn with<K: morphiq_numerics_arch::Simd>(self, k: K) {
        let mut done = 0;
        while self.input.len() - done >= K::LANES {
            let mut x = K::Array::default();
            x.as_mut().copy_from_slice(&self.input[done..done + K::LANES]);
            let y = lanes(k, k.load(x));
            self.output[done..done + K::LANES].copy_from_slice(k.store(y).as_ref());
            done += K::LANES;
        }
        if done < self.input.len() {
            let y = lanes(k, k.load_partial(&self.input[done..]));
            k.store_partial(y, &mut self.output[done..]);
        }
    }
}

#[cfg(feature = "simd")]
pub(crate) fn slice(input: &[f64], output: &mut [f64]) {
    use morphiq_numerics_arch::Simd;
    if input.len() <= 1 {
        if let Some(&x) = input.first() { output[0] = exp(x); }
        return;
    }
    let op = Slice { input, output };
    #[cfg(all(target_arch = "x86_64", target_feature = "sse2"))]
    {
        use morphiq_numerics_arch::{Avx2, Avx512, Sse2};
        if input.len() >= 8 && let Some(k) = Avx512::try_new() { return k.vectorize(op); }
        if input.len() >= 4 && let Some(k) = Avx2::try_new() { return k.vectorize(op); }
        Sse2::new().vectorize(op);
    }
    #[cfg(not(all(target_arch = "x86_64", target_feature = "sse2")))]
    morphiq_numerics_arch::dispatch(op);
}
''')
p=R/'fast/elementary.rs';s=p.read_text();start=s.index('    if x.abs() < 704.0 {');end=s.index('\n}\n',start);s=s[:start]+'    crate::exp::bounded::exp(x)'+s[end:];s=s.replace('crate::lanes::map::<super::lanes::Exp>(x, out);','crate::exp::bounded::slice(x, out);');p.write_text(s)
p=R/'erfcx/mod.rs';s=p.read_text();lines=s.splitlines(True);i=0
while i<len(lines) and (lines[i].startswith('//!') or not lines[i].strip()):i+=1
lines.insert(i,'pub(crate) mod bounded;\n');p.write_text(''.join(lines))
(R/'erfcx/bounded.rs').write_text('''//! High-word table evaluation for the explicit bounded Gaussian APIs.
use super::{T, f, t_reduce};

#[inline]
pub(crate) fn table(x: f64) -> f64 {
    let (i, _, h, _) = t_reduce(x);
    let a = &T[i];
    let h2 = h * h;
    let p0 = f(a[0]) + h * f(a[2]);
    let p1 = f(a[4]) + h * f(a[6]);
    let p2 = f(a[7]) + h * f(a[8]);
    let p3 = f(a[9]) + h * f(a[10]);
    let p4 = f(a[11]) + h * f(a[12]);
    p0 + h2 * (p1 + h2 * (p2 + h2 * (p3 + h2 * p4)))
}

#[cfg(feature = "simd")]
#[inline(always)]
pub(crate) fn lanes<K: morphiq_numerics_arch::Simd>(k: K, input: K::F) -> K::F {
    let words = k.store(input);
    let mut coefficients = [K::Array::default(); 10];
    let mut h = K::Array::default();
    for (i, &x) in words.as_ref().iter().enumerate() {
        let (index, _, residual, _) = t_reduce(x);
        h.as_mut()[i] = residual;
        for (out, j) in coefficients.iter_mut().zip([0, 2, 4, 6, 7, 8, 9, 10, 11, 12]) {
            out.as_mut()[i] = f(T[index][j]);
        }
    }
    let a = |j: usize| k.load(coefficients[j]);
    let h = k.load(h);
    let h2 = k.mul(h, h);
    let p0 = k.add(a(0), k.mul(h, a(1)));
    let p1 = k.add(a(2), k.mul(h, a(3)));
    let p2 = k.add(a(4), k.mul(h, a(5)));
    let p3 = k.add(a(6), k.mul(h, a(7)));
    let p4 = k.add(a(8), k.mul(h, a(9)));
    k.add(p0, k.mul(h2, k.add(p1, k.mul(h2, k.add(p2, k.mul(h2, k.add(p3, k.mul(h2, p4))))))))
}
''')
p=R/'normal_distribution/mod.rs';s=p.read_text();needle='pub(crate) const INV_SQRT2_HIGH: f64 = tables::INV_SQRT2.0;';s=s.replace(needle,needle+'''
/// Existing generated central coefficients, projected to their high words.
pub(crate) const CENTER_HIGH: [f64; 13] = {
    let mut a = [0.0; 13]; let mut i = 0;
    while i < 13 { a[i] = tables::CENTER[i].0; i += 1; }
    a
};
pub(crate) const DENSITY_HIGH: f64 = tables::DENSITY.0;
''');p.write_text(s)
p=R/'fast/normal.rs';s=p.read_text();s=s.replace('        let (hi, lo) = crate::erfcx::t_eval(x);\n        hi + lo','        crate::erfcx::bounded::table(x)');s=s.replace('    let exponential = super::elementary::exp((-0.5 * a) * a);','    if a <= 1.0 { return central(x); }\n    let exponential = super::elementary::exp((-0.5 * a) * a);');s=s.replace('    let (hi, lo) = crate::erfcx::t_eval(scaled);\n    let lower = (0.5 * exponential) * (hi + lo);','    let lower = (0.5 * exponential) * crate::erfcx::bounded::table(scaled);')
pos=s.index('/// Apply [`erfcx`]')
s=s[:pos]+'''/// Degree-25 integrated Gaussian Taylor polynomial on |x| <= 1.
#[inline]
pub(super) fn central(x: f64) -> f64 {
    use crate::normal_distribution::{CENTER_HIGH as A, DENSITY_HIGH};
    let z = x * x;
    let zz = z * z;
    let p0 = A[0] + z * A[1];
    let p1 = A[2] + z * A[3];
    let p2 = A[4] + z * A[5];
    let p3 = A[6] + z * A[7];
    let p4 = A[8] + z * A[9];
    let p5 = A[10] + z * A[11];
    let p = p0 + zz * (p1 + zz * (p2 + zz * (p3 + zz * (p4 + zz * (p5 + zz * A[12])))));
    0.5 + (x * DENSITY_HIGH) * p
}

'''+s[pos:];p.write_text(s)
p=R/'fast/lanes.rs';s=p.read_text();s=s.replace('pub(super) struct Exp;\n','');start=s.index('impl Kernel for Exp {');end=s.index('impl Kernel for Erfcx {');s=s[:start]+s[end:];s=s.replace('        let (hi, lo) = crate::erfcx::lanes::table(k, safe);\n        let mut out = k.store(k.add(hi, lo));','        let mut out = k.store(crate::erfcx::bounded::lanes(k, safe));')
start=s.index('impl Kernel for Cdf {');s=s[:start]+'''impl Kernel for Cdf {
    fn scalar(x: f64) -> f64 { super::normal::norm_cdf(x) }
    #[inline(always)]
    fn lanes<K: Simd>(k: K, input: K::Array) -> K::Array {
        let x = k.load(input);
        let a = k.abs(x);
        let active = k.and_m(k.le(k.splat(super::normal::MIN_MAGNITUDE), a), k.le(a, k.splat(8.0)));
        let central = k.and_m(active, k.le(a, k.splat(1.0)));
        let tail = k.and_m(active, k.not_m(central));
        let mut y = k.splat(0.0);
        if k.mask_bits(central) != 0 {
            y = center(k, k.select(central, x, k.splat(0.0)));
        }
        if k.mask_bits(tail) != 0 {
            let safe = k.select(tail, a, k.splat(1.0));
            let exponential = crate::exp::bounded::lanes(k, k.mul(k.mul(k.splat(-0.5), safe), safe));
            let scaled = k.mul(safe, k.splat(crate::normal_distribution::INV_SQRT2_HIGH));
            let lower = k.mul(k.mul(k.splat(0.5), exponential), crate::erfcx::bounded::lanes(k, scaled));
            let value = k.select(k.lt(x, k.splat(0.0)), lower, k.sub(k.splat(1.0), lower));
            y = k.select(tail, value, y);
        }
        let mut out = k.store(y);
        let active_bits = k.mask_bits(active);
        if active_bits != lanes_mask::<K>() {
            for (i, value) in out.as_mut().iter_mut().enumerate() {
                if active_bits >> i & 1 == 0 { *value = crate::normal::norm_cdf(input.as_ref()[i]); }
            }
        }
        out
    }
}

#[inline(always)]
fn center<K: Simd>(k: K, x: K::F) -> K::F {
    use crate::normal_distribution::{CENTER_HIGH as A, DENSITY_HIGH};
    let z = k.mul(x, x);
    let zz = k.mul(z, z);
    let pair = |j: usize| k.add(k.splat(A[j]), k.mul(z, k.splat(A[j + 1])));
    let p0 = pair(0); let p1 = pair(2); let p2 = pair(4);
    let p3 = pair(6); let p4 = pair(8); let p5 = pair(10);
    let mut p = k.add(p5, k.mul(zz, k.splat(A[12])));
    for q in [p4, p3, p2, p1, p0] { p = k.add(q, k.mul(zz, p)); }
    k.add(k.splat(0.5), k.mul(k.mul(x, k.splat(DENSITY_HIGH)), p))
}
''';p.write_text(s)
