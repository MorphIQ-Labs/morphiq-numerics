"""Render the completed source-bound measurement, including any failures."""
from pathlib import Path
from collections import defaultdict
import json
import os

P = Path(__file__).resolve().parent
os.sched_setaffinity(0, {0})
m = json.loads((P/'qualification-v8-manifest.json').read_text())
a = json.loads((P/'qualification-final-audit.json').read_text())
r = json.loads((P/'qualification-final/result.json').read_text())
rows = {row['id']:row for row in json.loads((P/'qualification-final/summary.json').read_text())}
destination = P/'source/docs/fast-evidence/native-matrix-20261028'
destination.mkdir(parents=True, exist_ok=True)
lines = ['# Native x86 matrix, 28 October 2026', '',
    f"Measured source: `{m['source_revision']}`. "
    f"All {r['cells']} declared cases completed; "
    f"{r['required']-len(r['failures'])}/{r['required']} individually required parity cases pass "
    'the predeclared one-sided 95% upper paired-time-ratio criterion of <=1.0. '
    'The historical 3% absolute-spread gate is retired. '
    'No samples are deleted and no average across cases hides a loss.', '',
    f"The raw-data audit checks {a['timed_samples']:,} timed samples, frozen counts, alternating order, "
    f"source/input/binary identities and CPU-2 affinity. The shortest timed sample is "
    f"{a['minimum_timed_ns']/1e6:.3f} ms; {a['invalid_duration_samples']} are below the 250 ms minimum. "
    f"CPU 14, the SMT sibling, has recorded busy ticks in {len(a['sibling_active_windows'])} process windows. "
    'The host is an Intel i9-10920X on Fedora 44; performance governor and turbo are enabled. '
    'Other-core Anvil CI activity is recorded and owner-authorized. All experiment builds, '
    'proofs, accuracy observations and profiling run outside uninstrumented timing windows.', '',
    'Each row below reports the worst upper ratio among its required cases. Ratios below one favor Numerics. '
    'The full per-case results, raw samples and descriptive spread are retained in the archives.', '',
    '| Build | Primitive | Required cases | Failed | Worst upper ratio |',
    '| --- | --- | ---: | ---: | ---: |']
groups = defaultdict(list)
for c in m['cells']:
    if c['required_parity']:
        groups[(c['backend'], c['primitive'])].append(rows[c['id']])
for (backend, primitive), values in sorted(groups.items()):
    lines.append(f"| {backend} | {primitive} | {len(values)} | {sum(not x['passes'] for x in values)} | {max(x['upper95'] for x in values):.6f} |")
lines += ['', 'Selected ordinary 52-value calls through the automatic build:', '',
    '| Primitive/interface | Reference | Median ns/call (ours / reference) | Paired geometric mean ratio | Upper 95% ratio |',
    '| --- | --- | ---: | ---: | ---: |']
for c in m['cells']:
    if c['backend']=='auto' and c['length']==52 and c['population']=='ordinary' and c['reference'] != 'strong-control' and not c.get('cache_slots',1)>1:
        x = rows[c['id']]
        lines.append(f"| {c['primitive']}/{c['kind']} | {c['reference']} | {x['ours_median_ns']:.3f} / {x['reference_median_ns']:.3f} | {x['ratio']:.6f} | {x['upper95']:.6f} |")
lines += ['', 'The independent medians are descriptive. The decision uses paired log ratios; '
    'dividing those medians is not the reported statistic. The ordinary erfcx bank includes zero, which invokes the strong owner, so its rows are diagnostic. Dependency-chain calls include '
    'the same two floating-point dependency operations for both implementations.', '',
    'Unchanged strong-API controls compare against the retained `5aa5d4a` binary:', '',
    '| Control | Paired geometric mean ratio | Lower / upper one-sided 95% endpoints |',
    '| --- | ---: | ---: |']
for x in a['controls']:
    lines.append(f"| {x['id']} | {x['ratio']:.6f} | {x['lower95']:.6f} / {x['upper95']:.6f} |")
lines += ['', 'Controls and screened/strong-fallback populations are diagnostic comparisons; '
    'they are not weaker-contract parity gates for the strong owners. Their complete '
    'timings and intervals are in `qualification-final-audit.json`. Screen/fallback counts are '
    'recorded per exact input bank in the manifest; these adversarial populations do not '
    'claim to represent consumer frequencies.', '']
if r['failures']:
    lines += ['Required parity is **not established** for:', '']
    for name in r['failures']:
        x=rows[name]
        lines.append(f"- `{name}`: mean ratio {x['ratio']:.6f}, upper {x['upper95']:.6f}, valid duration {x['valid_duration']}.")
    lines.append('')
lines += [(P/'qualification-evidence-guide.md').read_text().split('\n',2)[2],
    '\nThe unchanged numerical arithmetic passed all 30 GitHub checks at predecessor `a8cc587`, including '
    '[the full CI run](https://github.com/MorphIQ-Labs/morphiq-numerics/actions/runs/40794501939). '
    'Full-source checks for the final dispatch and evidence revision are attached to [PR #240](https://github.com/MorphIQ-Labs/morphiq-numerics/pull/240/checks). Evidence-only commits after the measured revision do not change its runtime. '
    'The owning qualification and native ARM handoff remain in '
    '[#194](https://github.com/MorphIQ-Labs/morphiq-numerics/issues/194).', '',
    '`qualification.tar.gz` retains the final campaign, exact inputs, observations, '
    'executed harness/build scripts, source and binary hashes, CI/proof receipts, '
    'reference pins/notices and host records. `diagnostics.tar.gz` retains rejected '
    'candidates, pilots, exploratory screens and their raw measurements; it also '
    'contains historical footprint measurements. Final footprints are in the qualification archive. These historical attempts are not '
    'substitutes for the final qualification. Both archives contain a `SHA256SUMS` '
    'and binary inventory. No external implementation source, executable or build '
    'directory is bundled. `archives.json` binds the compressed artifacts.', '',
    'The executed scripts retain their original absolute paths. To reproduce, rebuild '
    'the pinned public libraries and the four wrapper variants, relocate those paths '
    'explicitly, verify exact input hashes, and freeze a new manifest and counts on '
    'the new native host. Do not overwrite this campaign or expect byte-identical '
    'binaries after path/toolchain changes. The x86 wrappers need explicit NEON/platform '
    'adaptation for the separate ARM campaign described in #194.', '']
(destination/'README.md').write_text('\n'.join(lines))
(destination/'summary.csv').write_bytes((P/'qualification-final/summary.csv').read_bytes())
print(destination)
