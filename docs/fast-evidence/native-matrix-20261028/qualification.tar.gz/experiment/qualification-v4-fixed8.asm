
target/benchmarks/pr240-parity-next-20261028/qualification-v4-bin/avx512.so:     file format elf64-x86-64


Disassembly of section .text:

0000000000028330 <morphiq_numerics::exp::bounded::fixed::<morphiq_numerics_arch::x86_64::Avx512, 8>>:
   28330:	48 89 f2             	mov    %rsi,%rdx
   28333:	62 f1 fe 48 6f 07    	vmovdqu64 (%rdi),%zmm0
   28339:	62 f1 fd 58 db 0d 65 	vpandq -0x21d9b(%rip){1to8},%zmm0,%zmm1        # 65a8 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x348>
   28340:	e2 fd ff 
   28343:	62 f1 f5 58 c2 05 d2 	vcmplt_oqpd -0x21f2e(%rip){1to8},%zmm1,%k0        # 6420 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x1c0>
   2834a:	e0 fd ff 11 
   2834e:	c5 f8 93 c0          	kmovw  %k0,%eax
   28352:	3c ff                	cmp    $0xff,%al
   28354:	0f 85 2d 01 00 00    	jne    28487 <morphiq_numerics::exp::bounded::fixed::<morphiq_numerics_arch::x86_64::Avx512, 8>+0x157>
   2835a:	53                   	push   %rbx
   2835b:	62 f1 fd 58 59 0d fb 	vmulpd -0x21c05(%rip){1to8},%zmm0,%zmm1        # 6760 <anon.02ffda8f51e6076a26652e0a4fd6fa8d.746.llvm.5406940975955002095+0x180>
   28362:	e3 fd ff 
   28365:	62 f1 f5 58 58 0d 41 	vaddpd -0x21cbf(%rip){1to8},%zmm1,%zmm1        # 66b0 <anon.02ffda8f51e6076a26652e0a4fd6fa8d.746.llvm.5406940975955002095+0xd0>
   2836c:	e3 fd ff 
   2836f:	62 f1 f5 58 db 15 c7 	vpandq -0x21f39(%rip){1to8},%zmm1,%zmm2        # 6440 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x1e0>
   28376:	e0 fd ff 
   28379:	c4 e1 f9 7e d0       	vmovq  %xmm2,%rax
   2837e:	48 8b 0d 8b 0a 06 00 	mov    0x60a8b(%rip),%rcx        # 88e10 <_DYNAMIC+0x4f0>
   28385:	c4 e3 f9 16 d6 01    	vpextrq $0x1,%xmm2,%rsi
   2838b:	c4 e3 7d 39 d3 01    	vextracti128 $0x1,%ymm2,%xmm3
   28391:	c4 e1 f9 7e df       	vmovq  %xmm3,%rdi
   28396:	c4 c3 f9 16 d8 01    	vpextrq $0x1,%xmm3,%r8
   2839c:	62 f3 7d 48 39 d3 02 	vextracti32x4 $0x2,%zmm2,%xmm3
   283a3:	c4 c1 f9 7e d9       	vmovq  %xmm3,%r9
   283a8:	c4 c3 f9 16 da 01    	vpextrq $0x1,%xmm3,%r10
   283ae:	62 f3 7d 48 39 d2 03 	vextracti32x4 $0x3,%zmm2,%xmm2
   283b5:	c4 c1 f9 7e d3       	vmovq  %xmm2,%r11
   283ba:	c4 e3 f9 16 d3 01    	vpextrq $0x1,%xmm2,%rbx
   283c0:	c5 fa 7e 14 d9       	vmovq  (%rcx,%rbx,8),%xmm2
   283c5:	c4 a1 7a 7e 1c d9    	vmovq  (%rcx,%r11,8),%xmm3
   283cb:	c5 e1 6c d2          	vpunpcklqdq %xmm2,%xmm3,%xmm2
   283cf:	c4 a1 7a 7e 1c d1    	vmovq  (%rcx,%r10,8),%xmm3
   283d5:	c4 a1 7a 7e 24 c9    	vmovq  (%rcx,%r9,8),%xmm4
   283db:	c5 d9 6c db          	vpunpcklqdq %xmm3,%xmm4,%xmm3
   283df:	c4 e3 65 38 d2 01    	vinserti128 $0x1,%xmm2,%ymm3,%ymm2
   283e5:	c4 a1 7a 7e 1c c1    	vmovq  (%rcx,%r8,8),%xmm3
   283eb:	c5 fa 7e 24 f9       	vmovq  (%rcx,%rdi,8),%xmm4
   283f0:	c5 d9 6c db          	vpunpcklqdq %xmm3,%xmm4,%xmm3
   283f4:	c5 fa 7e 24 f1       	vmovq  (%rcx,%rsi,8),%xmm4
   283f9:	c5 fa 7e 2c c1       	vmovq  (%rcx,%rax,8),%xmm5
   283fe:	c5 d1 6c e4          	vpunpcklqdq %xmm4,%xmm5,%xmm4
   28402:	c4 e3 5d 38 db 01    	vinserti128 $0x1,%xmm3,%ymm4,%ymm3
   28408:	62 f1 f5 58 58 25 76 	vaddpd -0x21d8a(%rip){1to8},%zmm1,%zmm4        # 6688 <anon.02ffda8f51e6076a26652e0a4fd6fa8d.746.llvm.5406940975955002095+0xa8>
   2840f:	e2 fd ff 
   28412:	62 f3 e5 48 3a d2 01 	vinserti64x4 $0x1,%ymm2,%zmm3,%zmm2
   28419:	62 f1 f5 48 73 f1 2a 	vpsllq $0x2a,%zmm1,%zmm1
   28420:	62 f1 dd 58 59 1d 56 	vmulpd -0x21eaa(%rip){1to8},%zmm4,%zmm3        # 6580 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x320>
   28427:	e1 fd ff 
   2842a:	62 f1 ed 48 d4 c9    	vpaddq %zmm1,%zmm2,%zmm1
   28430:	62 f1 fd 48 58 c3    	vaddpd %zmm3,%zmm0,%zmm0
   28436:	62 f1 dd 58 59 15 e8 	vmulpd -0x22018(%rip){1to8},%zmm4,%zmm2        # 6428 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x1c8>
   2843d:	df fd ff 
   28440:	62 f1 ed 48 58 c0    	vaddpd %zmm0,%zmm2,%zmm0
   28446:	62 f1 fd 48 59 d0    	vmulpd %zmm0,%zmm0,%zmm2
   2844c:	62 f1 fd 58 59 1d 12 	vmulpd -0x21eee(%rip){1to8},%zmm0,%zmm3        # 6568 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x308>
   28453:	e1 fd ff 
   28456:	62 f1 e5 58 58 1d 08 	vaddpd -0x21ff8(%rip){1to8},%zmm3,%zmm3        # 6468 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x208>
   2845d:	e0 fd ff 
   28460:	62 f1 ed 48 59 d3    	vmulpd %zmm3,%zmm2,%zmm2
   28466:	62 f1 fd 48 58 c2    	vaddpd %zmm2,%zmm0,%zmm0
   2846c:	62 f1 fd 58 58 05 3a 	vaddpd -0x21ec6(%rip){1to8},%zmm0,%zmm0        # 65b0 <anon.ee651107ab5319c6bc273e1a29320aaf.1.llvm.14746981713632465754+0x350>
   28473:	e1 fd ff 
   28476:	62 f1 fd 48 59 c1    	vmulpd %zmm1,%zmm0,%zmm0
   2847c:	62 f1 fd 48 11 02    	vmovupd %zmm0,(%rdx)
   28482:	5b                   	pop    %rbx
   28483:	c5 f8 77             	vzeroupper
   28486:	c3                   	ret
   28487:	be 08 00 00 00       	mov    $0x8,%esi
   2848c:	b9 08 00 00 00       	mov    $0x8,%ecx
   28491:	c5 f8 77             	vzeroupper
   28494:	ff 25 7e 09 06 00    	jmp    *0x6097e(%rip)        # 88e18 <_DYNAMIC+0x4f8>
   2849a:	cc                   	int3
   2849b:	cc                   	int3
   2849c:	cc                   	int3
   2849d:	cc                   	int3
   2849e:	cc                   	int3
   2849f:	cc                   	int3
