from pathlib import Path
import json,struct,sys
import mpmath as mp
P=Path(__file__).resolve().parent;mp.mp.prec=600
f=P/'source/crates/morphiq-numerics/src/exp/bounded.rs';original=f.read_text();(P/'candidates/screened-kernels.rs').write_text(original)
# Constrain the correction polynomial to vanish at zero. For t in [0,1],
# min_alpha max |t^2-alpha*t| occurs when 1-alpha=alpha^2/4:
# alpha=2*(sqrt(2)-1), maximum 3-2*sqrt(2).
R=mp.mpf('0.000338451');alpha=2*(mp.sqrt(2)-1);c2=float(mp.mpf('.5')+alpha*R**2/24)
bits=lambda x:struct.unpack('>Q',struct.pack('>d',float(x)))[0]
words=[(bits(mp.exp(mp.log(2)*j/1024))-(j<<42))%(1<<64) for j in range(1024)]
s=original.replace('S_L2D, S_T, SHIFTER','S_L2D, SHIFTER')
a=s.index('// Project the generated high words');b=s.index('\n#[inline]',a)
s=s[:a]+'// Experimental generated 1024-way cubic: see prototype-cubic.py, 600 bits.\nconst C2: f64 = f64::from_bits(0x%016x);\nconst HIGH: [u64; 1024] = [\n'%bits(c2)+''.join('    0x%016x,\n'%w for w in words)+'];\n'+s[b:]
s=s.replace('x * INV_N + SHIFTER','x * (INV_N * 2.0) + SHIFTER').replace('bits & 511','bits & 1023').replace('bits << 43','bits << 42').replace('n * S_L1','n * (S_L1 * 0.5)').replace('n * S_L2D','n * (S_L2D * 0.5)')
s=s.replace('''    let [d3, d4, _] = POLY_S;
    let r2 = r * r;
    let left = r + 0.5 * r2;
    let p = d3 + r * d4;
    let u = left + (r2 * r) * p;''','''    let [d3, _, _] = POLY_S;
    let r2 = r * r;
    let u = r + r2 * (C2 + r * d3);''')
s=s.replace('k.splat(INV_N)','k.splat(INV_N * 2.0)').replace('k.shl_u(bits, 43)','k.shl_u(bits, 42)').replace('k.splat(S_L1)','k.splat(S_L1 * 0.5)').replace('k.splat(S_L2D)','k.splat(S_L2D * 0.5)')
s=s.replace('''    let [d3, d4, _] = POLY_S;
    let r2 = k.mul(r, r);
    let left = k.add(r, k.mul(k.splat(0.5), r2));
    let p = k.add(k.splat(d3), k.mul(r, k.splat(d4)));
    let u = k.add(left, k.mul(k.mul(r2, r), p));''','''    let [d3, _, _] = POLY_S;
    let r2 = k.mul(r, r);
    let u = k.add(r, k.mul(r2, k.add(k.splat(C2), k.mul(r, k.splat(d3)))));''')
f.write_text(s)
(P/'candidates/cubic-decision.json').write_text(json.dumps(dict(table_entries=1024,table_bytes=8192,precision=600,reduction_radius=str(R),c2_bits='%016x'%bits(c2),analytic_quartic_residual=float((3-2*mp.sqrt(2))*R**4/24),target_reduced_error=float(7*mp.mpf(2)**-56),public_relative_bound=float(mp.mpf(2)**-51),status='Exploratory only; independent proof and complete measurement required'),indent=2)+'\n')
