from pathlib import Path
import subprocess,os
P=Path(__file__).resolve().parent;os.sched_setaffinity(0,{0});(P/'aslr-probe').mkdir(exist_ok=True)
env=dict(os.environ,PYTHONHASHSEED='0',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
for i in range(5):
 for mode in ['on','off'] if i%2==0 else ['off','on']:
  cmd=[str(P/'venv/bin/python'),str(P/'aslr-probe.py'),f'{mode}-{i}']
  if mode=='off':cmd=['setarch','x86_64','-R']+cmd
  subprocess.run(cmd,env=env,check=True)
print('Address-randomization diagnostic complete.')
