"""Preserve completed campaign and rejected attempts, excluding build products."""
from pathlib import Path
import hashlib
import io
import json
import os
import tarfile

P = Path(__file__).resolve().parent
os.sched_setaffinity(0, {0})
assert (P/'qualification-final/result.json').exists(), 'Do not package live timings'
assert (P/'qualification-final-audit.json').exists(), 'Audit raw evidence first'
destination = P/'source/docs/fast-evidence/native-matrix-20261028'
destination.mkdir(parents=True, exist_ok=True)
# Only experiment-owned evidence trees are traversed. No reference implementation
# source, environment, proof-build or Rust target directory is bundled.
trees = [
    'qualification', 'qualification-inputs', 'qualification-observations',
    'qualification-reference-observations', 'qualification-v4-identity',
    'qualification-v4-allocations', 'qualification-v4-footprints',
    'matrix-inputs', 'matrix-observations', 'candidates', 'cdf-profile',
    'aslr-probe', 'guard-fresh-pilot', 'matrix-final-screen', 'outlined-identity',
    'outlined-screen', 'paired', 'screens', 'qualification-allocations',
    'qualification-footprints', 'qualification-pilot', 'qualification-screen',
    'qualification-v2-allocations', 'qualification-v2-identity',
    'qualification-v3-allocations', 'qualification-v3-identity',
    'qualification-v3-pilot', 'qualification-v3-screen',
    'qualification-v4-pilot', 'qualification-v4-screen',
    'qualification-v4-sibling-pilot',
]
trees += [x.name for x in P.glob('screen-*') if x.is_dir()]
trees += [x.name for x in P.glob('qualification-v*-*') if x.is_dir() and not x.name.endswith('-bin')]
trees += ['qualification-v8', 'qualification-final']
trees += [x.name for x in P.glob('packet-alias-*') if x.is_dir()]
files = {x for x in P.iterdir() if x.is_file()}
for name in trees:
    files.update(x for x in (P/name).rglob('*') if x.is_file())
for name in ['matrix-wrapper', 'control-wrapper', 'wrapper', 'src']:
    for x in (P/name).rglob('*'):
        if x.is_file() and 'target' not in x.relative_to(P/name).parts:
            files.add(x)
binary_roots = ['bin','final-bin','qualification-bin','qualification-v2-bin',
                'qualification-v3-bin','qualification-v4-bin','qualification-v5-bin','qualification-v6-bin','qualification-v7-bin','qualification-v8-bin','candidates']
binaries = {}
for name in binary_roots:
    for x in (P/name).glob('*'):
        if x.is_file():
            with x.open('rb') as f:
                elf = f.read(4) == b'\x7fELF'
            if elf:
                binaries[str(x.relative_to(P))] = dict(bytes=x.stat().st_size, sha256=hashlib.sha256(x.read_bytes()).hexdigest())
groups = {'qualification.tar.gz': [], 'diagnostics.tar.gz': []}
for x in sorted(files):
    if x.is_symlink():
        raise ValueError(f'Unexpected symlink: {x}')
    with x.open('rb') as f:
        if f.read(4) == b'\x7fELF':
            continue
    relative = x.relative_to(P)
    current = relative.parts[0] in trees[:6] or relative.parts[0] in ['qualification-v8','qualification-final','qualification-v8-identity','qualification-v8-auto-allocations','qualification-v8-static-allocations','qualification-v8-footprints']
    current |= len(relative.parts) == 1
    current |= relative.parts[0] in ['matrix-wrapper','control-wrapper','wrapper','src']
    groups['qualification.tar.gz' if current else 'diagnostics.tar.gz'].append((x, 'experiment/'+str(relative)))
# Pin/reference build receipts and notices only: never vendor reference source.
external = P.parent/'pr240-external-20261028'
for x in sorted(external.iterdir()):
    if x.is_file() and (x.suffix in ['.py','.c','.cpp','.json','.txt','.log']):
        groups['qualification.tar.gz'].append((x, 'references/'+x.name))
for x in sorted((external/'notices').rglob('*')):
    if x.is_file():
        groups['qualification.tar.gz'].append((x,'references/notices/'+str(x.relative_to(external/'notices'))))
original = P.parent/'pr240-local-20261028T102243Z'
for name in ['timed-input-bits.csv','timed-input-provenance.txt','rustc.txt','cargo.txt','os.txt','conditions.txt','reference-manifest.json']:
    groups['qualification.tar.gz'].append((original/name, 'original-inputs/'+name))


def member(archive, name, data):
    info = tarfile.TarInfo(name)
    info.size, info.mode = len(data), 0o644
    archive.addfile(info, io.BytesIO(data))


index = {}
for name, entries in groups.items():
    target = destination/name
    assert not target.exists(), f'Refuse to overwrite evidence: {target}'
    sums = []
    with tarfile.open(target, 'w:gz', compresslevel=6) as archive:
        for path, arcname in entries:
            data = path.read_bytes()
            sums.append(hashlib.sha256(data).hexdigest()+'  '+arcname)
            member(archive, arcname, data)
        binary_data = (json.dumps(binaries, indent=2)+'\n').encode()
        member(archive, 'binary-inventory.json', binary_data)
        sums.append(hashlib.sha256(binary_data).hexdigest()+'  binary-inventory.json')
        member(archive, 'SHA256SUMS', ('\n'.join(sums)+'\n').encode())
    assert target.stat().st_size < 95*1024*1024, 'Split oversized archive before committing'
    index[name] = dict(files=len(entries), bytes=target.stat().st_size, sha256=hashlib.sha256(target.read_bytes()).hexdigest())
(destination/'archives.json').write_text(json.dumps(index,indent=2)+'\n')
print(json.dumps(index,indent=2))
