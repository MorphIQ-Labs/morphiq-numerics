import ctypes as C, pathlib, json, csv, struct, sys, os, math
import numpy as np
import scipy, scipy.special.cython_special as cy
P=pathlib.Path(__file__).resolve().parent
BASE=P.parent/'pr240-local-20261028T102243Z'
D=C.POINTER(C.c_double)
LIBS={n:C.CDLL(str(P/'bin'/f'{n}.so')) for n in ('libnativebench','libcoreexp','libcerf','libboostbench')}
NATIVE=LIBS['libnativebench'];SLEEF=C.CDLL(str(P/'bin/libsleef.so.3'))
for name in ('measure1','measure2','measure_packet'):
 f=getattr(NATIVE,name);f.argtypes=[C.c_void_p,D,D,C.c_size_t,C.c_uint64];f.restype=C.c_uint64
CAP=C.pythonapi.PyCapsule_GetPointer;CAP.argtypes=[C.py_object,C.c_char_p];CAP.restype=C.c_void_p
GETNAME=C.pythonapi.PyCapsule_GetName;GETNAME.argtypes=[C.py_object];GETNAME.restype=C.c_char_p
F1=C.CFUNCTYPE(C.c_double,C.c_double);F2=C.CFUNCTYPE(C.c_double,C.c_double,C.c_int)
REG=[]
def add(name,primitive,kind,lib=None,symbol=None,capsule=None):
 if capsule:
  obj=cy.__pyx_capi__[capsule];sig=GETNAME(obj);assert sig==b'double (double, int __pyx_skip_dispatch)',sig
  ptr=CAP(obj,sig)
 else:ptr=C.cast(getattr(lib,symbol),C.c_void_p).value
 REG.append({'name':name,'primitive':primitive,'kind':kind,'ptr':ptr})
add('core_math_exp','exp','scalar',LIBS['libcoreexp'],'cr_exp')
add('sleef_exp_scalar_fma','exp','scalar',SLEEF,'Sleef_expd1_u10purecfma')
add('sleef_exp_avx2','exp','vector',NATIVE,'sleef_exp_avx2')
add('sleef_exp_avx512','exp','vector',NATIVE,'sleef_exp_avx512')
add('libcerf_erfcx','erfcx','scalar',LIBS['libcerf'],'erfcx')
add('scipy_erfcx','erfcx','scalar_capsule',capsule='__pyx_fuse_1erfcx')
add('scipy_ndtr','cdf','scalar_capsule',capsule='__pyx_fuse_1ndtr')
add('boost_cdf_default','cdf','scalar',LIBS['libboostbench'],'boost_cdf_default')
add('boost_cdf_binary64','cdf','scalar',LIBS['libboostbench'],'boost_cdf_binary64')
add('sleef_cdf_scalar_fma','cdf','scalar',NATIVE,'sleef_cdf_scalar')
add('sleef_cdf_avx2','cdf','vector',NATIVE,'sleef_cdf_avx2')
add('sleef_cdf_avx512','cdf','vector',NATIVE,'sleef_cdf_avx512')
PACKETS={f:[] for f in ('exp','erfcx','cdf')}
for row in csv.DictReader((BASE/'timed-input-bits.csv').open()):PACKETS[row['primitive']].append(struct.unpack('>d',bytes.fromhex(row['input_bits']))[0])
PACKETS={k:np.array(v,dtype=np.float64) for k,v in PACKETS.items()}
assert all(len(x)==52 for x in PACKETS.values())
def evaluate(entry,x):
 x=np.ascontiguousarray(x,dtype=np.float64);y=np.empty_like(x)
 if entry['kind']=='vector':
  fn=C.CFUNCTYPE(None,D,D,C.c_size_t)(entry['ptr']);fn(x.ctypes.data_as(D),y.ctypes.data_as(D),len(x))
 elif entry['kind']=='scalar_capsule':
  fn=F2(entry['ptr'])
  for i,v in enumerate(x):y[i]=fn(v,1)
 else:
  fn=F1(entry['ptr'])
  for i,v in enumerate(x):y[i]=fn(v)
 return y

def run(label):
 os.sched_setaffinity(0,{2})
 out=P/label;out.mkdir()
 if label=='calibration':counts={r['name']:10000 for r in REG}
 else:counts=json.loads((P/'external-counts.json').read_text())
 frozen={r['name']:(PACKETS[r['primitive']],np.empty(52,dtype=np.float64)) for r in REG}
 order=list(range(len(REG)))
 passes=[order] if label=='calibration' else [order,order[::-1],order,order[::-1]]
 rows=[]
 with (out/'samples.csv').open('w',buffering=1) as file:
  writer=csv.writer(file);writer.writerow(['reference','primitive','interface','round','iterations','elapsed_ns','ns_per_52'])
  for repeat,indices in enumerate(passes):
   for index in indices:
    r=REG[index];x,y=frozen[r['name']]
    method='measure_packet' if r['kind']=='vector' else 'measure2' if r['kind']=='scalar_capsule' else 'measure1'
    elapsed=getattr(NATIVE,method)(r['ptr'],x.ctypes.data_as(D),y.ctypes.data_as(D),52,counts[r['name']])
    assert elapsed>0 and np.isfinite(y).all()
    rows.append((r['name'],elapsed/counts[r['name']]))
    writer.writerow([r['name'],r['primitive'],r['kind'],repeat,counts[r['name']],elapsed,elapsed/counts[r['name']]])
 if label=='calibration':
  counts={name:math.ceil(300000000/ns/1000)*1000 for name,ns in rows}
  assert all(1<=v<=100000000 for v in counts.values())
  (P/'external-counts.json').write_text(json.dumps(counts,indent=2)+'\n')
 (out/'metadata.json').write_text(json.dumps({'scipy':scipy.__version__,'numpy':np.__version__,'affinity':sorted(os.sched_getaffinity(0)),'counts':counts},indent=2)+'\n')
if __name__=='__main__':run(sys.argv[1])
