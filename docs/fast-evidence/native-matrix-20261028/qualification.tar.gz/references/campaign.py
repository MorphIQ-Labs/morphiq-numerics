import pathlib,subprocess,os,json,csv,math,hashlib,datetime,time
P=pathlib.Path(__file__).resolve().parent;B=P.parent/'pr240-local-20261028T102243Z';binary=B/'bench-fast-primitives';python=P/'venv/bin/python'
os.sched_setaffinity(0,{0})
env={'PATH':'/usr/bin:/bin','LANG':'C','OPENBLAS_NUM_THREADS':'1','OMP_NUM_THREADS':'1','MKL_NUM_THREADS':'1'}
protocol={'scope':'Five fresh alternating process pairs, PR 240 versus pinned external references, exact original 52-value packets. Native scalar loops and explicit SLEEF vector packet adapters. Comparative measurements; does not replace #194 stability or full qualification matrix.','process_pairs':5,'within_process_samples':4,'pair_order':['morphiq,external','external,morphiq','morphiq,external','external,morphiq','morphiq,external'],'warmup':'one full excluded process per executable plus 100 packet evaluations before every timed sample','target_fastest_morphiq_sample_ns':300000000,'target_each_external_cell_sample_ns':300000000,'minimum_sample_ns':250000000,'external_counts':'one per reference cell, frozen after excluded 10000-iteration calibration','morphiq_count':'one common count, frozen after excluded 100000-iteration calibration','analysis':'All raw samples retained. Per-process arithmetic means; paired ratios to MorphIQ strong/fast appropriate interface. Overall means, medians, spread and exploratory process-pair bootstrap intervals. No outlier removal, pass-seeking retries or newly inferred parity threshold.','affinity':2,'idle_sibling':14,'layout':'ASLR disabled for all measured child processes; identical minimal environment plus frozen count for MorphIQ','binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'numerical':'Post-timing 256/512-bit mpmath agreement on timed inputs plus archived independent fixture comparisons. Scalar and vector references evaluated separately.','interfaces':'MorphIQ original Rust timing loop vs C timing loop for external native function pointers; native Cython capsule calls take extra dispatch int. No Python work inside timed regions. Boost wrappers compiled separately; default and promote_double=false both retained. SLEEF AVX512 packet has four scalar tail values; AVX2 has no tail at length 52.','unmatched_guarantees':'Contracts, ISA use and wrappers differ. CORE-MATH is a strong-exp reference; SLEEF/CDF composition, libcerf, SciPy, Boost are individually characterized, not assumed numerically interchangeable or externally parity-qualified.'}
(P/'protocol.json').write_text(json.dumps(protocol,indent=2)+'\n')
def snapshot(stem):
 with (P/(stem+'-host.json')).open('w') as out:subprocess.run(['/usr/bin/python3',str(B/'capture-host.py')],env={**env,'MORPHIQ_BENCH_CPU':'2'},stdout=out,check=True)
def run_morphiq(label,count):
 d=P/label;d.mkdir();snapshot(label+'-before')
 start=datetime.datetime.now(datetime.timezone.utc).isoformat()
 with (d/'samples.csv').open('w') as out,(d/'samples.stderr').open('w') as err:
  subprocess.run(['/usr/bin/taskset','-c','2','/usr/bin/setarch','x86_64','-R',str(binary)],env={**env,'MORPHIQ_FAST_BENCH_ITERATIONS':str(count)},stdout=out,stderr=err,check=True)
 (d/'metadata.json').write_text(json.dumps({'iterations':count,'start':start,'end':datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2)+'\n')
 snapshot(label+'-after');print(label,'complete',flush=True)
 return list(csv.reader((d/'samples.csv').open()))
def run_external(label):
 snapshot(label+'-before')
 with (P/(label+'.log')).open('w') as log:subprocess.run(['/usr/bin/taskset','-c','2','/usr/bin/setarch','x86_64','-R',str(python),str(P/'external.py'),label],env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
 snapshot(label+'-after');print(label,'complete',flush=True)
run_external('calibration')
rows=run_morphiq('morphiq-calibration',100000)
count=math.ceil(300000000/min(float(r[2]) for r in rows)/1000)*1000
assert 1<=count<=20000000
(P/'morphiq-count.txt').write_text(str(count)+'\n')
run_morphiq('morphiq-warmup',count);run_external('external-warmup')
for pair in range(1,6):
 for kind in (('morphiq','external') if pair%2 else ('external','morphiq')):
  if kind=='morphiq':run_morphiq(f'morphiq-{pair}',count)
  else:run_external(f'external-{pair}')
print('Timing complete; all five pairs retained.',flush=True)
