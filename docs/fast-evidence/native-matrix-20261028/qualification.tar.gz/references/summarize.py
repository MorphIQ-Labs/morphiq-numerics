import csv,json,pathlib,statistics as S,random
P=pathlib.Path(__file__).resolve().parent
m={}; e={}; elapsed=[]; short=[]
for i in range(1,6):
 for f,mode,t in csv.reader((P/f'morphiq-{i}/samples.csv').open()):m.setdefault((f,int(mode)),{}).setdefault(i,[]).append(float(t))
 for line in (P/f'morphiq-{i}/samples.stderr').read_text().splitlines():
  if ',elapsed_ns=' in line:elapsed.append(int(line.rsplit('=',1)[1]))
 for r in csv.DictReader((P/f'external-{i}/samples.csv').open()):
  e.setdefault((r['reference'],r['primitive'],r['interface']),{}).setdefault(i,[]).append(float(r['ns_per_52']))
  duration=int(r['elapsed_ns']);elapsed.append(duration)
  if duration<250000000:short.append(dict(process=i,**r))
rows=[];rng=random.Random(194240)
for (name,f,interface),processes in e.items():
 mode=3 if interface=='vector' else 1
 ref=[S.mean(processes[i]) for i in range(1,6)];ours=[S.mean(m[f,mode][i]) for i in range(1,6)]
 ratios=[a/b for a,b in zip(ours,ref)];boot=sorted(S.mean(rng.choices(ratios,k=5)) for _ in range(20000))
 samples=[t for v in processes.values() for t in v]
 rows.append(dict(reference=name,primitive=f,interface=interface,reference_mean_ns_per_52=S.mean(samples),reference_median_ns_per_52=S.median(samples),reference_sample_min=min(samples),reference_sample_max=max(samples),reference_process_means=ref,morphiq_fast_mean_ns_per_52=S.mean(ours),morphiq_process_means=ours,morphiq_over_reference_process_ratios=ratios,mean_paired_ratio=S.mean(ratios),exploratory_bootstrap95_mean_paired_ratio=[boot[500],boot[19499]],morphiq_strong_mean_ns_per_52=S.mean(t for v in m[f,mode-1].values() for t in v)))
out=dict(status='Descriptive comparison only: duration floor failed; full parity matrix and stability qualification remain open.',minimum_sample_ns=min(elapsed),short_samples=short,cells=rows,notes=['All five pairs and all raw samples retained; no outlier removal.','Ratios above 1 mean MorphIQ is slower. Five process pairs limit uncertainty inference.','Bootstrap resamples whole process pairs; descriptive and not a predeclared equivalence test.','Scalar and vector comparisons use different calling interfaces and ISA as detailed in protocol.json.','SciPy erfcx violates the MorphIQ active relative budget on timed inputs; it remains a diagnostic speed reference.'])
(P/'summary.json').write_text(json.dumps(out,indent=2)+'\n')
with (P/'summary.csv').open('w') as stream:
 keys=['reference','primitive','interface','reference_mean_ns_per_52','morphiq_fast_mean_ns_per_52','mean_paired_ratio']
 writer=csv.DictWriter(stream,fieldnames=keys,extrasaction='ignore');writer.writeheader();writer.writerows(rows)
print((P/'summary.csv').read_text());print('minimum',min(elapsed),'short samples',len(short))
