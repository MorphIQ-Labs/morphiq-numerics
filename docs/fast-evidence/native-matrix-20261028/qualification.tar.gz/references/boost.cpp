#include <boost/math/distributions/normal.hpp>
#include <boost/math/policies/policy.hpp>
#include <limits>
static const boost::math::normal_distribution<double> normal;
using Policy=boost::math::policies::policy<boost::math::policies::promote_double<false>>;
static const boost::math::normal_distribution<double,Policy> normal64;
static unsigned long errors=0;
extern "C" double boost_cdf_default(double x){try{return boost::math::cdf(normal,x);}catch(...){++errors;return std::numeric_limits<double>::quiet_NaN();}}
extern "C" double boost_cdf_binary64(double x){try{return boost::math::cdf(normal64,x);}catch(...){++errors;return std::numeric_limits<double>::quiet_NaN();}}
extern "C" unsigned long boost_errors(){return errors;}
