import pathlib,sys,json,math,struct,csv,subprocess,os
import mpmath as mp
import external as E
P=E.P;B=E.BASE
os.sched_setaffinity(0,{0})
mp.mp.prec=512
out=P/'accuracy';out.mkdir()
def bits(x):return struct.pack('>d',float(x)).hex()
def val(word):return struct.unpack('>d',bytes.fromhex(word))[0]
def reference(f,x,prec):
 with mp.workprec(prec):
  a=mp.mpf(float(x))
  y=mp.exp(a) if f=='exp' else mp.exp(a*a)*mp.erfc(a) if f=='erfcx' else mp.erfc(-a/mp.sqrt(2))/2
  return +y
truth={}
for f,xs in E.PACKETS.items():
 truth[f]=[reference(f,x,512) for x in xs]
 for x,y in zip(xs,truth[f]):
  y256=reference(f,x,256)
  assert bits(float(y))==bits(float(y256)) and abs(y-y256)<mp.mpf(2)**-200*max(1,abs(y))
(out/'packet-reference.json').write_text(json.dumps({f:[{'input':bits(x),'reference_512bit':mp.nstr(y,160)} for x,y in zip(E.PACKETS[f],ys)] for f,ys in truth.items()},indent=2)+'\n')
# Original executable's observation mode checks fast scalar/slice identity.
input_file=out/'packet-inputs.txt';input_file.write_text(''.join(f'{f} {bits(x)}\n' for f,xs in E.PACKETS.items() for x in xs))
with (out/'morphiq-packet.csv').open('w') as output:
 subprocess.run(['/usr/bin/taskset','-c','2',str(B/'bench-fast-primitives'),str(input_file)],stdout=output,check=True)
morph={f:[] for f in E.PACKETS}
for f,x,y in csv.reader((out/'morphiq-packet.csv').open()):morph[f].append(val(y))
packet_results=[]
def assess(name,f,ys):
 refs=truth[f];absolute=[abs(mp.mpf(float(y))-r) for y,r in zip(ys,refs)];relative=[e/abs(r) for e,r in zip(absolute,refs)]
 cap=mp.mpf(2)**(-49 if f=='cdf' else -51)
 error=absolute if f=='cdf' else relative
 row={'reference':name,'primitive':f,'cases':len(ys),'max_absolute_error':float(max(absolute)),'max_relative_error':float(max(relative)),'observed_morphiq_budget_pass':all(e<=cap for e in error),'budget_metric':'absolute' if f=='cdf' else 'relative','budget':float(cap),'max_ulp_from_independently_rounded_reference':max(abs(int(bits(y),16)-int(bits(float(r)),16)) for y,r in zip(ys,refs))}
 packet_results.append(row)
 with (out/(name+'-packet.csv')).open('w') as file:
  w=csv.writer(file);w.writerow(['primitive','input_bits','output_bits'])
  for x,y in zip(E.PACKETS[f],ys):w.writerow([f,bits(x),bits(y)])
for f,ys in morph.items():assess('morphiq_fast_'+f,f,ys)
fixture=json.loads((B/'observations/fast-reference-expected.json').read_text())
fixture_results=[]
for r in E.REG:
 f=r['primitive'];ys=E.evaluate(r,E.PACKETS[f]);assess(r['name'],f,ys)
 population=[(key.split()[1],word) for key,word in fixture.items() if key.startswith(f+' ')]
 xs=[val(x) for x,w in population];ys=E.evaluate(r,xs)
 result={'reference':r['name'],'primitive':f,'cases':len(xs),'finite_rounded_comparisons':0,'max_ulp_from_rounded_reference':0,'worst_ulp':None,'special_class_mismatches':[],'active_morphiq_domain':0,'active_error_upper_within_morphiq_budget':0,'active_error_lower_exceeds_morphiq_budget':0,'active_budget_uncertain_from_rounded_reference':0}
 with (out/(r['name']+'-fixtures.csv')).open('w') as file:
  writer=csv.writer(file);writer.writerow(['input_bits','reference_bits','output_bits'])
  for (xword,refword),x,y in zip(population,xs,ys):
   y=float(y);expected=val(refword);word=bits(y);writer.writerow([xword,refword,word])
   if not math.isfinite(expected):
    if not ((math.isnan(expected) and math.isnan(y)) or y==expected):result['special_class_mismatches'].append({'input':xword,'expected':refword,'actual':word})
   elif not math.isfinite(y):result['special_class_mismatches'].append({'input':xword,'expected':refword,'actual':word})
   else:
    ulp=abs(int(word,16)-int(refword,16));result['finite_rounded_comparisons']+=1
    if ulp>result['max_ulp_from_rounded_reference']:result['max_ulp_from_rounded_reference']=ulp;result['worst_ulp']={'input':xword,'expected':refword,'actual':word}
   active=(abs(x)<704 if f=='exp' else -.5<=x<16 and abs(x)>=2**-33 if f=='erfcx' else 2**-33<=abs(x)<=8)
   if active:
    result['active_morphiq_domain']+=1
    if not math.isfinite(y):result['active_error_lower_exceeds_morphiq_budget']+=1;continue
    uncertainty=max(math.nextafter(expected,math.inf)-expected,expected-math.nextafter(expected,-math.inf))/2
    delta=abs(y-expected);cap=2**-49 if f=='cdf' else abs(expected)*2**-51
    upper=math.nextafter(delta+uncertainty,math.inf);lower=max(0,math.nextafter(delta-uncertainty,0))
    if upper<=cap:result['active_error_upper_within_morphiq_budget']+=1
    elif lower>cap:result['active_error_lower_exceeds_morphiq_budget']+=1
    else:result['active_budget_uncertain_from_rounded_reference']+=1
 fixture_results.append(result)
(P/'accuracy-summary.json').write_text(json.dumps({'scope':'Independent numerical observations, not whole-domain proofs. Timed packet reference computed at 256/512 bits with agreement. Fixture error budgets use conservative uncertainty around archived rounded values; uncertain cases are not asserted to violate a bound. References are not assumed to promise MorphIQ contracts.','timed_packets':packet_results,'archived_fixtures':fixture_results},indent=2)+'\n')
assert all(r['observed_morphiq_budget_pass'] for r in packet_results if r['reference'].startswith('morphiq_fast'))
print('Accuracy observations completed. Timed-packet budget failures:',[r['reference'] for r in packet_results if not r['observed_morphiq_budget_pass']])
