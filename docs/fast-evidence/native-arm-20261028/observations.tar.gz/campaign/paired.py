import csv, json, math, pathlib, sys
import arm_external as E
P=pathlib.Path(__file__).resolve().parent
label=sys.argv[1];out=P/'paired'/label;out.mkdir(parents=True)
names=list(dict.fromkeys(n for pair in E.PAIRS for n in pair))
if label=='calibration':
    counts={};rows=[]
    for name in names:
        first=E.measure(name,10000)
        count=max(1,math.ceil(500000000/(first/10000)/1000)*1000)
        warm=E.measure(name,max(1,count//2));elapsed=E.measure(name,count)
        counts[name]=max(1,math.ceil(count*500000000/elapsed/1000)*1000)
        rows.append(dict(name=name,initial_ns=first,warmup_ns=warm,count=count,
                         elapsed_ns=elapsed,frozen_count=counts[name]))
    (P/'paired/counts.json').write_text(json.dumps(counts,indent=2)+'\n')
    (out/'samples.json').write_text(json.dumps(rows,indent=2)+'\n')
else:
    counts=json.loads((P/'paired/counts.json').read_text());process=int(label)
    with (out/'samples.csv').open('w',buffering=1) as f:
        w=csv.DictWriter(f,fieldnames=['process','pair','round','name','kind','iterations','elapsed_ns','ns_per_52']);w.writeheader()
        for round in range(4):
            order=list(enumerate(E.PAIRS));order=order if (process+round)%2==0 else order[::-1]
            for pair_index,pair in order:
                for name in pair if (process+round)%2==0 else pair[::-1]:
                    for kind,count in [('warmup',max(1,counts[name]//2)),('timed',counts[name])]:
                        elapsed=E.measure(name,count)
                        w.writerow(dict(process=process,pair=pair_index,round=round,name=name,kind=kind,
                                        iterations=count,elapsed_ns=elapsed,ns_per_52=elapsed/count))
    (out/'metadata.json').write_text(json.dumps(dict(affinity='unbound; macOS scheduling',
        qos='QOS_CLASS_USER_INITIATED',qos_result=E.QOS_RESULT,scipy=E.scipy.__version__,
        numpy=E.np.__version__,pairs=E.PAIRS,counts=counts),indent=2)+'\n')
