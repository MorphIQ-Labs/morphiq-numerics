import datetime,hashlib,json,os,pathlib,subprocess,sys,time
P=pathlib.Path(__file__).resolve().parent
ROOT=P.parents[2]
def run(args):
 p=subprocess.run(args,text=True,capture_output=True);return dict(command=args,returncode=p.returncode,stdout=p.stdout,stderr=p.stderr)
def capture():
 return dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),commands=[run(c) for c in [['sw_vers'],['uname','-a'],['sysctl','hw.model','machdep.cpu.brand_string','hw.physicalcpu','hw.logicalcpu','hw.memsize','hw.perflevel0.physicalcpu','hw.perflevel1.physicalcpu','vm.loadavg'],['pmset','-g','batt'],['pmset','-g','custom'],['pmset','-g','therm'],['ps','-eo','pid,pcpu,comm']]])
def save(name,obj): (P/name).write_text(json.dumps(obj,indent=2)+'\n')
if sys.argv[1:] == ['prepare']:
 save('host-before.json',capture())
 save('build-identity.json',dict(source=run(['git','rev-parse','HEAD']),status=run(['git','status','--porcelain']),tools=[run(c) for c in [['rustc','-vV'],['cargo','-V'],['clang','--version'],['cmake','--version'],[sys.executable,'-m','pip','freeze']]],hashes={str(p.relative_to(P)):hashlib.sha256(p.read_bytes()).hexdigest() for p in P.rglob('*') if p.is_file() and p.suffix in ['.py','.c','.toml','.rs','.dylib','.csv']}))
 sys.exit(0)
for label in ['calibration']+[str(i) for i in range(10)]:
 if label=='5':time.sleep(30)
 save('host-'+label+'-before.json',capture())
 print(datetime.datetime.now(datetime.timezone.utc).isoformat(), 'starting',label,flush=True)
 with (P/'logs'/('paired-'+label+'.log')).open('w') as f:
  subprocess.run([sys.executable,str(P/'paired.py'),label],cwd=P,stdout=f,stderr=subprocess.STDOUT,check=True)
 save('host-'+label+'-after.json',capture())
 print(datetime.datetime.now(datetime.timezone.utc).isoformat(), 'completed',label,flush=True)
subprocess.run([sys.executable,str(P/'summarize-paired.py')],cwd=P,check=True)
save('host-after.json',capture())
(P/'COMPLETE').write_text(datetime.datetime.now(datetime.timezone.utc).isoformat()+'\n')
