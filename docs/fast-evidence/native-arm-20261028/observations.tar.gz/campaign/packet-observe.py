import csv,json,struct
import mpmath as mp
import arm_external as E
mp.mp.prec=256
P=E.P
rows=[];summary={}
for name,entry in E.entries.items():
 primitive=entry['primitive'];xs=E.PACKETS[primitive];ys=E.evaluate(name,xs)
 errors=[]
 for x,y in zip(xs,ys):
  z=mp.mpf(float(x));ref=mp.exp(z) if primitive=='exp' else mp.exp(z*z)*mp.erfc(z) if primitive=='erfcx' else mp.erfc(-z/mp.sqrt(2))/2
  err=abs(mp.mpf(float(y))-ref);err=err/abs(ref) if primitive!='cdf' else err
  errors.append(err)
  rows.append(dict(name=name,input_bits=struct.pack('>d',x).hex(),output_bits=struct.pack('>d',y).hex(),reference=mp.nstr(ref,82),error=mp.nstr(err,30)))
 bound=mp.mpf(2)**(-49 if primitive=='cdf' else -51)
 summary[name]=dict(count=len(xs),max_error=str(max(errors)),metric='absolute' if primitive=='cdf' else 'relative',production_bound_pass=bool(max(errors)<=bound) if name.startswith('prod_') else None)
with (P/'packet-observations.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
(P/'packet-observations.json').write_text(json.dumps(summary,indent=2)+'\n')
assert all(x['production_bound_pass'] is not False for x in summary.values()),summary
for primitive,symbol in [('exp','exp'),('erfcx','erfcx'),('cdf','norm_cdf')]:
 a=E.evaluate('prod_'+symbol,E.PACKETS[primitive]);b=E.evaluate('prod_'+symbol+'_slice',E.PACKETS[primitive]);assert (a.view('uint64')==b.view('uint64')).all()
print('52 inputs per primitive: production accuracy and scalar/slice identity passed')
