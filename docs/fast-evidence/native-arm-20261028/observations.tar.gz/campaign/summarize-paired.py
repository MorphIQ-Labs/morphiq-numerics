from pathlib import Path
import csv,json,math,statistics
from scipy.stats import t
P=Path(__file__).resolve().parent
allrows=[]
for f in sorted((P/'paired').glob('[0-9]*/samples.csv')):
 for r in csv.DictReader(f.open()):
  for k in ['process','pair','round','iterations','elapsed_ns']:r[k]=int(r[k])
  r['ns_per_52']=float(r['ns_per_52']);allrows.append(r)
rows=[r for r in allrows if r['kind']=='timed']
assert len(rows)==560,len(rows)
assert sorted(set(r['process'] for r in rows))==list(range(10))
summary=[]
for pair in range(7):
 selected=[r for r in rows if r['pair']==pair]
 names=sorted(set(r['name'] for r in selected),key=lambda n: not n.startswith('prod_'))
 assert len(names)==2
 process_ratios=[];process_times={n:[] for n in names}
 for process in range(10):
  cells=[r for r in selected if r['process']==process]
  ratios=[]
  for round in range(4):
   a={r['name']:r['ns_per_52'] for r in cells if r['round']==round};assert set(a)==set(names)
   ratios.append(math.log(a[names[0]]/a[names[1]]))
  process_ratios.append(statistics.median(ratios))
  for n in names:process_times[n].append(statistics.median(r['ns_per_52'] for r in cells if r['name']==n))
 mean=statistics.mean(process_ratios);se=statistics.stdev(process_ratios)/math.sqrt(10)
 upper=math.exp(mean+t.ppf(.95,9)*se)
 times={}
 for n,v in process_times.items():
  med=statistics.median(v);b0=statistics.median(v[:5]);b1=statistics.median(v[5:])
  times[n]=dict(median_ns_per_52=med,min=min(v),max=max(v),range_fraction=(max(v)-min(v))/med,block_drift=abs(b1/b0-1),process_medians=v)
 summary.append(dict(pair=pair,names=names,ratio_geometric_mean=math.exp(mean),ratio_upper95=upper,meets_cost=upper<=1,times=times,minimum_duration_ns=min(r['elapsed_ns'] for r in selected),absolute_repeatability=all(v['range_fraction']<=.03 and v['block_drift']<=.03 for v in times.values())))
result=dict(scope='Frozen 52-value native ARM public-call campaign; broader #194 matrix not inferred',pairs=summary,duration_pass=all(r['elapsed_ns']>=250000000 for r in rows),all_cost_pass=all(r['meets_cost'] for r in summary),absolute_spread_is_diagnostic=True, all_absolute_repeatability_pass=all(r['absolute_repeatability'] for r in summary))
(P/'paired/summary.json').write_text(json.dumps(result,indent=2)+'\n')
for r in summary:print(r['names'],r['ratio_geometric_mean'],r['ratio_upper95'],r['absolute_repeatability'])
print('DURATION',result['duration_pass'],'COST',result['all_cost_pass'],'ABSOLUTE STABILITY',result['all_absolute_repeatability_pass'])
