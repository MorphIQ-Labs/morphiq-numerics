import csv,hashlib,json,pathlib,struct
import mpmath as mp
import numpy as np
import arm_external as E
mp.mp.prec=256
P=E.P;U=P.parent/'upstream-packet'
def bits(x):return struct.pack('>d',float(x)).hex()
def val(w):return struct.unpack('>d',bytes.fromhex(w))[0]
summary=[]
for primitive,name in [('exp','prod_exp'),('erfcx','prod_erfcx'),('cdf','prod_norm_cdf')]:
 source=U/(name+'-observations.csv');rows=list(csv.DictReader(source.open()));xs=np.array([val(r['input_bits']) for r in rows]);ys=E.evaluate(name,xs);zs=E.evaluate(name+'_slice',xs)
 bound=mp.mpf(2)**(-49 if primitive=='cdf' else -51);worst=mp.mpf(0);failures=[];cross=[];identity=[];witness=None
 with (P/(name+'-arm-observations.csv')).open('w') as out:
  w=csv.writer(out);w.writerow(['input_bits','arm_output_bits','x86_output_bits','reference_256bit','error'])
  for r,y,z in zip(rows,ys,zs):
   ref=mp.mpf(r['reference_256bit']);error=abs(mp.mpf(float(y))-ref)/(1 if primitive=='cdf' else abs(ref));yb=bits(y)
   w.writerow([r['input_bits'],yb,r['output_bits'],r['reference_256bit'],mp.nstr(error,30)])
   if error>worst:worst=error;witness=r['input_bits']
   if error>bound:failures.append(r['input_bits'])
   if yb!=r['output_bits']:cross.append(r['input_bits'])
   if yb!=bits(z):identity.append(r['input_bits'])
 # Boundary/remainder/special-value scalar/slice observations, outside timing.
 extra=[0.,-0.,float('inf'),-float('inf'),val('7ff8123456789abc'),val('fff8123456789abc')]
 for b in [-704.,-8.,-1.,-.5,-2**-33,2**-33,1.,8.,16.,704.]:
  extra.extend([np.nextafter(b,-np.inf),b,np.nextafter(b,np.inf)])
 sample=np.concatenate([np.array(extra),xs[:70],xs[-70:]])
 for n in list(range(66))+[len(sample)]:
  a=E.evaluate(name,sample[:n]);b=E.evaluate(name+'_slice',sample[:n])
  for i in np.flatnonzero(a.view('uint64')!=b.view('uint64')):identity.append(dict(length=n,input=bits(sample[i])))
 summary.append(dict(primitive=primitive,cases=len(rows),oracle_source=str(source.relative_to(P.parent)),oracle_source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),metric='absolute' if primitive=='cdf' else 'relative',bound=str(bound),max_error=str(worst),witness=witness,accuracy_failures=failures,x86_output_mismatches=cross,scalar_slice_mismatches=identity))
result=dict(scope='Replay of retained independently computed 256-bit mpmath references on native ARM; finite sampled evidence, not whole-domain proof or full determinism CI',cells=summary)
(P/'arm-accuracy-summary.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
assert not any(r[k] for r in summary for k in ['accuracy_failures','x86_output_mismatches','scalar_slice_mismatches'])
